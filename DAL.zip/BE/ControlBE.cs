﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BE
{
    public class ControlBE
    {
        public int ID_Idioma { get; set; }
        public string ID_Control { get; set; }
        public string Mensaje { get; set; }

        public ControlBE(){}
    }
}
