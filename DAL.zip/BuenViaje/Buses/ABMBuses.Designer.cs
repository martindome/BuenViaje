﻿namespace BuenViaje.Buses
{
    partial class ABMBuses
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ABMBusessBotton2 = new System.Windows.Forms.Button();
            this.ABMBusesBotton1 = new System.Windows.Forms.Button();
            this.ABMBusesLabel1 = new System.Windows.Forms.Label();
            this.ABMBusesTexto3 = new System.Windows.Forms.TextBox();
            this.ABMBusesLabel3 = new System.Windows.Forms.Label();
            this.ABMBusesTexto2 = new System.Windows.Forms.TextBox();
            this.ABMBusesTexto1 = new System.Windows.Forms.TextBox();
            this.ABMBusesLabel2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // ABMBusessBotton2
            // 
            this.ABMBusessBotton2.Location = new System.Drawing.Point(157, 127);
            this.ABMBusessBotton2.Margin = new System.Windows.Forms.Padding(2);
            this.ABMBusessBotton2.Name = "ABMBusessBotton2";
            this.ABMBusessBotton2.Size = new System.Drawing.Size(66, 21);
            this.ABMBusessBotton2.TabIndex = 32;
            this.ABMBusessBotton2.Text = "Cancelar";
            this.ABMBusessBotton2.UseVisualStyleBackColor = true;
            this.ABMBusessBotton2.Click += new System.EventHandler(this.ABMBusessBotton2_Click);
            // 
            // ABMBusesBotton1
            // 
            this.ABMBusesBotton1.Location = new System.Drawing.Point(11, 127);
            this.ABMBusesBotton1.Margin = new System.Windows.Forms.Padding(2);
            this.ABMBusesBotton1.Name = "ABMBusesBotton1";
            this.ABMBusesBotton1.Size = new System.Drawing.Size(66, 21);
            this.ABMBusesBotton1.TabIndex = 33;
            this.ABMBusesBotton1.Text = "Aplicar";
            this.ABMBusesBotton1.UseVisualStyleBackColor = true;
            this.ABMBusesBotton1.Click += new System.EventHandler(this.ABMBusesBotton1_Click);
            // 
            // ABMBusesLabel1
            // 
            this.ABMBusesLabel1.AutoSize = true;
            this.ABMBusesLabel1.Location = new System.Drawing.Point(8, 8);
            this.ABMBusesLabel1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.ABMBusesLabel1.Name = "ABMBusesLabel1";
            this.ABMBusesLabel1.Size = new System.Drawing.Size(44, 13);
            this.ABMBusesLabel1.TabIndex = 31;
            this.ABMBusesLabel1.Text = "Patente";
            // 
            // ABMBusesTexto3
            // 
            this.ABMBusesTexto3.Location = new System.Drawing.Point(11, 102);
            this.ABMBusesTexto3.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.ABMBusesTexto3.Name = "ABMBusesTexto3";
            this.ABMBusesTexto3.Size = new System.Drawing.Size(212, 20);
            this.ABMBusesTexto3.TabIndex = 30;
            this.ABMBusesTexto3.TextChanged += new System.EventHandler(this.ABMBusesTexto3_TextChanged);
            // 
            // ABMBusesLabel3
            // 
            this.ABMBusesLabel3.AutoSize = true;
            this.ABMBusesLabel3.Location = new System.Drawing.Point(8, 86);
            this.ABMBusesLabel3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.ABMBusesLabel3.Name = "ABMBusesLabel3";
            this.ABMBusesLabel3.Size = new System.Drawing.Size(47, 13);
            this.ABMBusesLabel3.TabIndex = 29;
            this.ABMBusesLabel3.Text = "Asientos";
            // 
            // ABMBusesTexto2
            // 
            this.ABMBusesTexto2.Location = new System.Drawing.Point(11, 63);
            this.ABMBusesTexto2.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.ABMBusesTexto2.Name = "ABMBusesTexto2";
            this.ABMBusesTexto2.Size = new System.Drawing.Size(212, 20);
            this.ABMBusesTexto2.TabIndex = 28;
            this.ABMBusesTexto2.TextChanged += new System.EventHandler(this.ABMBusesTexto2_TextChanged);
            // 
            // ABMBusesTexto1
            // 
            this.ABMBusesTexto1.Location = new System.Drawing.Point(11, 24);
            this.ABMBusesTexto1.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.ABMBusesTexto1.Name = "ABMBusesTexto1";
            this.ABMBusesTexto1.Size = new System.Drawing.Size(212, 20);
            this.ABMBusesTexto1.TabIndex = 27;
            this.ABMBusesTexto1.TextChanged += new System.EventHandler(this.ABMBusesTexto1_TextChanged);
            // 
            // ABMBusesLabel2
            // 
            this.ABMBusesLabel2.AutoSize = true;
            this.ABMBusesLabel2.Location = new System.Drawing.Point(8, 47);
            this.ABMBusesLabel2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.ABMBusesLabel2.Name = "ABMBusesLabel2";
            this.ABMBusesLabel2.Size = new System.Drawing.Size(37, 13);
            this.ABMBusesLabel2.TabIndex = 26;
            this.ABMBusesLabel2.Text = "Marca";
            // 
            // ABMBuses
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(240, 179);
            this.Controls.Add(this.ABMBusessBotton2);
            this.Controls.Add(this.ABMBusesBotton1);
            this.Controls.Add(this.ABMBusesLabel1);
            this.Controls.Add(this.ABMBusesTexto3);
            this.Controls.Add(this.ABMBusesLabel3);
            this.Controls.Add(this.ABMBusesTexto2);
            this.Controls.Add(this.ABMBusesTexto1);
            this.Controls.Add(this.ABMBusesLabel2);
            this.Name = "ABMBuses";
            this.Text = "ABMBuses";
            this.Load += new System.EventHandler(this.ABMBuses_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button ABMBusessBotton2;
        private System.Windows.Forms.Button ABMBusesBotton1;
        private System.Windows.Forms.Label ABMBusesLabel1;
        private System.Windows.Forms.TextBox ABMBusesTexto3;
        private System.Windows.Forms.Label ABMBusesLabel3;
        private System.Windows.Forms.TextBox ABMBusesTexto2;
        private System.Windows.Forms.TextBox ABMBusesTexto1;
        private System.Windows.Forms.Label ABMBusesLabel2;
    }
}