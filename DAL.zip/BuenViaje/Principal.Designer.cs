﻿namespace BuenViaje
{
    partial class Principal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.sesionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cambiarIdiomaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cambiarContraseñaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cerrarSesionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.administracionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bitacoraToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gestionarUsuariosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gestionarPermisosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.copiaDeSeguridadToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.restauracionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPagePasajes = new System.Windows.Forms.TabPage();
            this.pasajesPrincipalTextBox6 = new System.Windows.Forms.TextBox();
            this.pasajesPrincipalLabel8 = new System.Windows.Forms.Label();
            this.pasajesPrincipalButton3 = new System.Windows.Forms.Button();
            this.pasajesPrincipalGroupBox2 = new System.Windows.Forms.GroupBox();
            this.pasajesPrincipalDataGridViajes = new System.Windows.Forms.DataGridView();
            this.pasajesPrincipalTextBox4 = new System.Windows.Forms.TextBox();
            this.pasajesPrincipalButton2 = new System.Windows.Forms.Button();
            this.pasajesPrincipalTextBox5 = new System.Windows.Forms.TextBox();
            this.pasajeDateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.pasajesPrincipalLabel4 = new System.Windows.Forms.Label();
            this.pasajeDateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.pasajesPrincipalLabel5 = new System.Windows.Forms.Label();
            this.pasajesPrincipalLabel7 = new System.Windows.Forms.Label();
            this.pasajesPrincipalLabel6 = new System.Windows.Forms.Label();
            this.pasajesPrincipalGroupBox1 = new System.Windows.Forms.GroupBox();
            this.pasajesPrincipalDataGridClientes = new System.Windows.Forms.DataGridView();
            this.pasajesPrincipalTextBox1 = new System.Windows.Forms.TextBox();
            this.pasajesPrincipalTextBox2 = new System.Windows.Forms.TextBox();
            this.pasajesPrincipalButton1 = new System.Windows.Forms.Button();
            this.pasajesPrincipalTextBox3 = new System.Windows.Forms.TextBox();
            this.pasajesPrincipalLabel3 = new System.Windows.Forms.Label();
            this.pasajesPrincipalLabel1 = new System.Windows.Forms.Label();
            this.pasajesPrincipalLabel2 = new System.Windows.Forms.Label();
            this.pasajesPrincipalButton5 = new System.Windows.Forms.Button();
            this.pasajesPrincipalButton4 = new System.Windows.Forms.Button();
            this.tabPageClientes = new System.Windows.Forms.TabPage();
            this.ClientesGroupBox1 = new System.Windows.Forms.GroupBox();
            this.ClientesLabel4 = new System.Windows.Forms.Label();
            this.ClientesTextBox4 = new System.Windows.Forms.TextBox();
            this.ClientesLabel3 = new System.Windows.Forms.Label();
            this.ClientesTextBox3 = new System.Windows.Forms.TextBox();
            this.ClientesBotton6 = new System.Windows.Forms.Button();
            this.ClientesBotton5 = new System.Windows.Forms.Button();
            this.ClientesLabel2 = new System.Windows.Forms.Label();
            this.ClientesTextBox2 = new System.Windows.Forms.TextBox();
            this.ClientesLabel1 = new System.Windows.Forms.Label();
            this.ClientesTextBox1 = new System.Windows.Forms.TextBox();
            this.ClientesBotton4 = new System.Windows.Forms.Button();
            this.ClientesBotton3 = new System.Windows.Forms.Button();
            this.ClientesBotton2 = new System.Windows.Forms.Button();
            this.grillaClientes = new System.Windows.Forms.DataGridView();
            this.tabPageViajes = new System.Windows.Forms.TabPage();
            this.ViajesPrincipalButton7 = new System.Windows.Forms.Button();
            this.ViajePrincipalGroupBox1 = new System.Windows.Forms.GroupBox();
            this.ViajesPrincipalCheckBox = new System.Windows.Forms.CheckBox();
            this.ViajeDatePickerHastaHora = new System.Windows.Forms.DateTimePicker();
            this.ViajeDatePickerDesdeHora = new System.Windows.Forms.DateTimePicker();
            this.ViajePrincipalLabel4 = new System.Windows.Forms.Label();
            this.ViajePrincipalLabel3 = new System.Windows.Forms.Label();
            this.ViajeDatePickerHasta = new System.Windows.Forms.DateTimePicker();
            this.ViajeDatePickerDesde = new System.Windows.Forms.DateTimePicker();
            this.ViajesPrincipalButton6 = new System.Windows.Forms.Button();
            this.ViajesPrincipalButton5 = new System.Windows.Forms.Button();
            this.ViajePrincipalLabel2 = new System.Windows.Forms.Label();
            this.ViajesPrincipalText2 = new System.Windows.Forms.TextBox();
            this.ViajePrincipalLabel1 = new System.Windows.Forms.Label();
            this.ViajesPrincipalText1 = new System.Windows.Forms.TextBox();
            this.ViajesPrincipalButton4 = new System.Windows.Forms.Button();
            this.ViajesPrincipalButton3 = new System.Windows.Forms.Button();
            this.ViajesPrincipalButton2 = new System.Windows.Forms.Button();
            this.ViajesPrincipalButton1 = new System.Windows.Forms.Button();
            this.ViajesPrincipalDataGrid = new System.Windows.Forms.DataGridView();
            this.tabPageRutas = new System.Windows.Forms.TabPage();
            this.RutasGroupBox = new System.Windows.Forms.GroupBox();
            this.RutaLabel2 = new System.Windows.Forms.Label();
            this.RutasPrincipalText3 = new System.Windows.Forms.TextBox();
            this.RutasButton6 = new System.Windows.Forms.Button();
            this.RutasButton5 = new System.Windows.Forms.Button();
            this.RutaLabel1 = new System.Windows.Forms.Label();
            this.RutasPrincipalText2 = new System.Windows.Forms.TextBox();
            this.RutasButton4 = new System.Windows.Forms.Button();
            this.RutasButton3 = new System.Windows.Forms.Button();
            this.RutasButton2 = new System.Windows.Forms.Button();
            this.dataGridRutas = new System.Windows.Forms.DataGridView();
            this.tabPageLocalidades = new System.Windows.Forms.TabPage();
            this.LocalidadGroupBox = new System.Windows.Forms.GroupBox();
            this.LocalidadLabel3 = new System.Windows.Forms.Label();
            this.LocalidadPrincipalText3 = new System.Windows.Forms.TextBox();
            this.LocalidadBotton6 = new System.Windows.Forms.Button();
            this.LocalidadBotton5 = new System.Windows.Forms.Button();
            this.LocalidadLabel2 = new System.Windows.Forms.Label();
            this.LocalidadPrincipalText2 = new System.Windows.Forms.TextBox();
            this.LocalidadLabel1 = new System.Windows.Forms.Label();
            this.LocalidadPrincipalText1 = new System.Windows.Forms.TextBox();
            this.LocalidadBotton4 = new System.Windows.Forms.Button();
            this.LocalidadBotton3 = new System.Windows.Forms.Button();
            this.LocalidadBotton2 = new System.Windows.Forms.Button();
            this.grillaLocalidad = new System.Windows.Forms.DataGridView();
            this.tabPageBuses = new System.Windows.Forms.TabPage();
            this.busesButton7 = new System.Windows.Forms.Button();
            this.busesGroupBox1 = new System.Windows.Forms.GroupBox();
            this.busesLabel3 = new System.Windows.Forms.Label();
            this.busesText3 = new System.Windows.Forms.TextBox();
            this.busesButton6 = new System.Windows.Forms.Button();
            this.busesButton5 = new System.Windows.Forms.Button();
            this.busesLabel2 = new System.Windows.Forms.Label();
            this.busesText2 = new System.Windows.Forms.TextBox();
            this.busesLabel1 = new System.Windows.Forms.Label();
            this.busesText1 = new System.Windows.Forms.TextBox();
            this.busesButton4 = new System.Windows.Forms.Button();
            this.busesButton3 = new System.Windows.Forms.Button();
            this.busesButton2 = new System.Windows.Forms.Button();
            this.grillaBuses = new System.Windows.Forms.DataGridView();
            this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.menuStrip1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPagePasajes.SuspendLayout();
            this.pasajesPrincipalGroupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pasajesPrincipalDataGridViajes)).BeginInit();
            this.pasajesPrincipalGroupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pasajesPrincipalDataGridClientes)).BeginInit();
            this.tabPageClientes.SuspendLayout();
            this.ClientesGroupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grillaClientes)).BeginInit();
            this.tabPageViajes.SuspendLayout();
            this.ViajePrincipalGroupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ViajesPrincipalDataGrid)).BeginInit();
            this.tabPageRutas.SuspendLayout();
            this.RutasGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridRutas)).BeginInit();
            this.tabPageLocalidades.SuspendLayout();
            this.LocalidadGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grillaLocalidad)).BeginInit();
            this.tabPageBuses.SuspendLayout();
            this.busesGroupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grillaBuses)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.Azure;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sesionToolStripMenuItem,
            this.administracionToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1156, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // sesionToolStripMenuItem
            // 
            this.sesionToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cambiarIdiomaToolStripMenuItem,
            this.cambiarContraseñaToolStripMenuItem,
            this.cerrarSesionToolStripMenuItem});
            this.sesionToolStripMenuItem.Name = "sesionToolStripMenuItem";
            this.sesionToolStripMenuItem.Size = new System.Drawing.Size(53, 20);
            this.sesionToolStripMenuItem.Text = "Sesion";
            // 
            // cambiarIdiomaToolStripMenuItem
            // 
            this.cambiarIdiomaToolStripMenuItem.Name = "cambiarIdiomaToolStripMenuItem";
            this.cambiarIdiomaToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.cambiarIdiomaToolStripMenuItem.Text = "Cambiar Idioma";
            this.cambiarIdiomaToolStripMenuItem.Click += new System.EventHandler(this.cambiarIdiomaToolStripMenuItem_Click);
            // 
            // cambiarContraseñaToolStripMenuItem
            // 
            this.cambiarContraseñaToolStripMenuItem.Name = "cambiarContraseñaToolStripMenuItem";
            this.cambiarContraseñaToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.cambiarContraseñaToolStripMenuItem.Text = "Cambiar Contraseña";
            this.cambiarContraseñaToolStripMenuItem.Click += new System.EventHandler(this.cambiarContraseñaToolStripMenuItem_Click);
            // 
            // cerrarSesionToolStripMenuItem
            // 
            this.cerrarSesionToolStripMenuItem.Name = "cerrarSesionToolStripMenuItem";
            this.cerrarSesionToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.cerrarSesionToolStripMenuItem.Text = "Cerrar Sesion";
            this.cerrarSesionToolStripMenuItem.Click += new System.EventHandler(this.cerrarSesionToolStripMenuItem_Click);
            // 
            // administracionToolStripMenuItem
            // 
            this.administracionToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bitacoraToolStripMenuItem,
            this.gestionarUsuariosToolStripMenuItem,
            this.gestionarPermisosToolStripMenuItem,
            this.copiaDeSeguridadToolStripMenuItem,
            this.restauracionToolStripMenuItem});
            this.administracionToolStripMenuItem.Name = "administracionToolStripMenuItem";
            this.administracionToolStripMenuItem.Size = new System.Drawing.Size(100, 20);
            this.administracionToolStripMenuItem.Text = "Administracion";
            // 
            // bitacoraToolStripMenuItem
            // 
            this.bitacoraToolStripMenuItem.Name = "bitacoraToolStripMenuItem";
            this.bitacoraToolStripMenuItem.Size = new System.Drawing.Size(176, 22);
            this.bitacoraToolStripMenuItem.Text = "Bitacora";
            this.bitacoraToolStripMenuItem.Click += new System.EventHandler(this.bitacoraToolStripMenuItem_Click);
            // 
            // gestionarUsuariosToolStripMenuItem
            // 
            this.gestionarUsuariosToolStripMenuItem.Name = "gestionarUsuariosToolStripMenuItem";
            this.gestionarUsuariosToolStripMenuItem.Size = new System.Drawing.Size(176, 22);
            this.gestionarUsuariosToolStripMenuItem.Text = "Gestionar Usuarios";
            this.gestionarUsuariosToolStripMenuItem.Click += new System.EventHandler(this.gestionarUsuariosToolStripMenuItem_Click);
            // 
            // gestionarPermisosToolStripMenuItem
            // 
            this.gestionarPermisosToolStripMenuItem.Name = "gestionarPermisosToolStripMenuItem";
            this.gestionarPermisosToolStripMenuItem.Size = new System.Drawing.Size(176, 22);
            this.gestionarPermisosToolStripMenuItem.Text = "Gestionar Permisos";
            this.gestionarPermisosToolStripMenuItem.Click += new System.EventHandler(this.gestionarPermisosToolStripMenuItem_Click);
            // 
            // copiaDeSeguridadToolStripMenuItem
            // 
            this.copiaDeSeguridadToolStripMenuItem.Name = "copiaDeSeguridadToolStripMenuItem";
            this.copiaDeSeguridadToolStripMenuItem.Size = new System.Drawing.Size(176, 22);
            this.copiaDeSeguridadToolStripMenuItem.Text = "Copia de seguridad";
            this.copiaDeSeguridadToolStripMenuItem.Click += new System.EventHandler(this.copiaDeSeguridadToolStripMenuItem_Click);
            // 
            // restauracionToolStripMenuItem
            // 
            this.restauracionToolStripMenuItem.Name = "restauracionToolStripMenuItem";
            this.restauracionToolStripMenuItem.Size = new System.Drawing.Size(176, 22);
            this.restauracionToolStripMenuItem.Text = "Restauracion";
            this.restauracionToolStripMenuItem.Click += new System.EventHandler(this.restauracionToolStripMenuItem_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPagePasajes);
            this.tabControl1.Controls.Add(this.tabPageClientes);
            this.tabControl1.Controls.Add(this.tabPageViajes);
            this.tabControl1.Controls.Add(this.tabPageRutas);
            this.tabControl1.Controls.Add(this.tabPageLocalidades);
            this.tabControl1.Controls.Add(this.tabPageBuses);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.HotTrack = true;
            this.tabControl1.ItemSize = new System.Drawing.Size(159, 20);
            this.tabControl1.Location = new System.Drawing.Point(0, 24);
            this.tabControl1.Multiline = true;
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1156, 433);
            this.tabControl1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.tabControl1.TabIndex = 1;
            // 
            // tabPagePasajes
            // 
            this.tabPagePasajes.BackColor = System.Drawing.Color.SteelBlue;
            this.tabPagePasajes.Controls.Add(this.pasajesPrincipalTextBox6);
            this.tabPagePasajes.Controls.Add(this.pasajesPrincipalLabel8);
            this.tabPagePasajes.Controls.Add(this.pasajesPrincipalButton3);
            this.tabPagePasajes.Controls.Add(this.pasajesPrincipalGroupBox2);
            this.tabPagePasajes.Controls.Add(this.pasajesPrincipalGroupBox1);
            this.tabPagePasajes.Controls.Add(this.pasajesPrincipalButton5);
            this.tabPagePasajes.Controls.Add(this.pasajesPrincipalButton4);
            this.tabPagePasajes.Location = new System.Drawing.Point(4, 24);
            this.tabPagePasajes.Name = "tabPagePasajes";
            this.tabPagePasajes.Padding = new System.Windows.Forms.Padding(3);
            this.tabPagePasajes.Size = new System.Drawing.Size(1148, 405);
            this.tabPagePasajes.TabIndex = 0;
            this.tabPagePasajes.Text = "Pasajes";
            // 
            // pasajesPrincipalTextBox6
            // 
            this.pasajesPrincipalTextBox6.Location = new System.Drawing.Point(485, 301);
            this.pasajesPrincipalTextBox6.Name = "pasajesPrincipalTextBox6";
            this.pasajesPrincipalTextBox6.Size = new System.Drawing.Size(100, 20);
            this.pasajesPrincipalTextBox6.TabIndex = 58;
            this.pasajesPrincipalTextBox6.TextChanged += new System.EventHandler(this.pasajesPrincipalTextBox6_TextChanged);
            // 
            // pasajesPrincipalLabel8
            // 
            this.pasajesPrincipalLabel8.AutoSize = true;
            this.pasajesPrincipalLabel8.Location = new System.Drawing.Point(430, 304);
            this.pasajesPrincipalLabel8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.pasajesPrincipalLabel8.Name = "pasajesPrincipalLabel8";
            this.pasajesPrincipalLabel8.Size = new System.Drawing.Size(52, 13);
            this.pasajesPrincipalLabel8.TabIndex = 59;
            this.pasajesPrincipalLabel8.Text = "Cantidad:";
            // 
            // pasajesPrincipalButton3
            // 
            this.pasajesPrincipalButton3.Location = new System.Drawing.Point(8, 297);
            this.pasajesPrincipalButton3.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pasajesPrincipalButton3.Name = "pasajesPrincipalButton3";
            this.pasajesPrincipalButton3.Size = new System.Drawing.Size(153, 24);
            this.pasajesPrincipalButton3.TabIndex = 60;
            this.pasajesPrincipalButton3.Text = "Alta Cliente";
            this.pasajesPrincipalButton3.UseVisualStyleBackColor = true;
            this.pasajesPrincipalButton3.Click += new System.EventHandler(this.pasajesPrincipalButton3_Click);
            // 
            // pasajesPrincipalGroupBox2
            // 
            this.pasajesPrincipalGroupBox2.Controls.Add(this.pasajesPrincipalDataGridViajes);
            this.pasajesPrincipalGroupBox2.Controls.Add(this.pasajesPrincipalTextBox4);
            this.pasajesPrincipalGroupBox2.Controls.Add(this.pasajesPrincipalButton2);
            this.pasajesPrincipalGroupBox2.Controls.Add(this.pasajesPrincipalTextBox5);
            this.pasajesPrincipalGroupBox2.Controls.Add(this.pasajeDateTimePicker1);
            this.pasajesPrincipalGroupBox2.Controls.Add(this.pasajesPrincipalLabel4);
            this.pasajesPrincipalGroupBox2.Controls.Add(this.pasajeDateTimePicker2);
            this.pasajesPrincipalGroupBox2.Controls.Add(this.pasajesPrincipalLabel5);
            this.pasajesPrincipalGroupBox2.Controls.Add(this.pasajesPrincipalLabel7);
            this.pasajesPrincipalGroupBox2.Controls.Add(this.pasajesPrincipalLabel6);
            this.pasajesPrincipalGroupBox2.Location = new System.Drawing.Point(425, 6);
            this.pasajesPrincipalGroupBox2.Name = "pasajesPrincipalGroupBox2";
            this.pasajesPrincipalGroupBox2.Size = new System.Drawing.Size(715, 289);
            this.pasajesPrincipalGroupBox2.TabIndex = 59;
            this.pasajesPrincipalGroupBox2.TabStop = false;
            this.pasajesPrincipalGroupBox2.Text = "Viajes";
            // 
            // pasajesPrincipalDataGridViajes
            // 
            this.pasajesPrincipalDataGridViajes.BackgroundColor = System.Drawing.SystemColors.InactiveCaption;
            this.pasajesPrincipalDataGridViajes.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Sunken;
            this.pasajesPrincipalDataGridViajes.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            this.pasajesPrincipalDataGridViajes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.pasajesPrincipalDataGridViajes.Cursor = System.Windows.Forms.Cursors.Default;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.InactiveCaption;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.pasajesPrincipalDataGridViajes.DefaultCellStyle = dataGridViewCellStyle1;
            this.pasajesPrincipalDataGridViajes.GridColor = System.Drawing.SystemColors.ActiveCaption;
            this.pasajesPrincipalDataGridViajes.Location = new System.Drawing.Point(5, 58);
            this.pasajesPrincipalDataGridViajes.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pasajesPrincipalDataGridViajes.Name = "pasajesPrincipalDataGridViajes";
            this.pasajesPrincipalDataGridViajes.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.pasajesPrincipalDataGridViajes.RowHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.pasajesPrincipalDataGridViajes.RowHeadersWidth = 51;
            this.pasajesPrincipalDataGridViajes.RowTemplate.Height = 24;
            this.pasajesPrincipalDataGridViajes.Size = new System.Drawing.Size(703, 225);
            this.pasajesPrincipalDataGridViajes.TabIndex = 41;
            // 
            // pasajesPrincipalTextBox4
            // 
            this.pasajesPrincipalTextBox4.Location = new System.Drawing.Point(14, 33);
            this.pasajesPrincipalTextBox4.Name = "pasajesPrincipalTextBox4";
            this.pasajesPrincipalTextBox4.Size = new System.Drawing.Size(100, 20);
            this.pasajesPrincipalTextBox4.TabIndex = 44;
            // 
            // pasajesPrincipalButton2
            // 
            this.pasajesPrincipalButton2.Location = new System.Drawing.Point(630, 32);
            this.pasajesPrincipalButton2.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pasajesPrincipalButton2.Name = "pasajesPrincipalButton2";
            this.pasajesPrincipalButton2.Size = new System.Drawing.Size(78, 20);
            this.pasajesPrincipalButton2.TabIndex = 57;
            this.pasajesPrincipalButton2.Text = "Buscar";
            this.pasajesPrincipalButton2.UseVisualStyleBackColor = true;
            this.pasajesPrincipalButton2.Click += new System.EventHandler(this.pasajesPrincipalButton2_Click);
            // 
            // pasajesPrincipalTextBox5
            // 
            this.pasajesPrincipalTextBox5.Location = new System.Drawing.Point(120, 33);
            this.pasajesPrincipalTextBox5.Name = "pasajesPrincipalTextBox5";
            this.pasajesPrincipalTextBox5.Size = new System.Drawing.Size(100, 20);
            this.pasajesPrincipalTextBox5.TabIndex = 45;
            // 
            // pasajeDateTimePicker1
            // 
            this.pasajeDateTimePicker1.CustomFormat = "MM-dd-yy";
            this.pasajeDateTimePicker1.Location = new System.Drawing.Point(226, 33);
            this.pasajeDateTimePicker1.Name = "pasajeDateTimePicker1";
            this.pasajeDateTimePicker1.Size = new System.Drawing.Size(200, 20);
            this.pasajeDateTimePicker1.TabIndex = 46;
            // 
            // pasajesPrincipalLabel4
            // 
            this.pasajesPrincipalLabel4.AutoSize = true;
            this.pasajesPrincipalLabel4.Location = new System.Drawing.Point(11, 17);
            this.pasajesPrincipalLabel4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.pasajesPrincipalLabel4.Name = "pasajesPrincipalLabel4";
            this.pasajesPrincipalLabel4.Size = new System.Drawing.Size(38, 13);
            this.pasajesPrincipalLabel4.TabIndex = 51;
            this.pasajesPrincipalLabel4.Text = "Origen";
            // 
            // pasajeDateTimePicker2
            // 
            this.pasajeDateTimePicker2.CustomFormat = "MM-dd-yy";
            this.pasajeDateTimePicker2.Location = new System.Drawing.Point(432, 33);
            this.pasajeDateTimePicker2.Name = "pasajeDateTimePicker2";
            this.pasajeDateTimePicker2.Size = new System.Drawing.Size(193, 20);
            this.pasajeDateTimePicker2.TabIndex = 47;
            // 
            // pasajesPrincipalLabel5
            // 
            this.pasajesPrincipalLabel5.AutoSize = true;
            this.pasajesPrincipalLabel5.Location = new System.Drawing.Point(117, 17);
            this.pasajesPrincipalLabel5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.pasajesPrincipalLabel5.Name = "pasajesPrincipalLabel5";
            this.pasajesPrincipalLabel5.Size = new System.Drawing.Size(43, 13);
            this.pasajesPrincipalLabel5.TabIndex = 50;
            this.pasajesPrincipalLabel5.Text = "Destino";
            // 
            // pasajesPrincipalLabel7
            // 
            this.pasajesPrincipalLabel7.AutoSize = true;
            this.pasajesPrincipalLabel7.Location = new System.Drawing.Point(223, 17);
            this.pasajesPrincipalLabel7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.pasajesPrincipalLabel7.Name = "pasajesPrincipalLabel7";
            this.pasajesPrincipalLabel7.Size = new System.Drawing.Size(38, 13);
            this.pasajesPrincipalLabel7.TabIndex = 48;
            this.pasajesPrincipalLabel7.Text = "Desde";
            // 
            // pasajesPrincipalLabel6
            // 
            this.pasajesPrincipalLabel6.AutoSize = true;
            this.pasajesPrincipalLabel6.Location = new System.Drawing.Point(434, 17);
            this.pasajesPrincipalLabel6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.pasajesPrincipalLabel6.Name = "pasajesPrincipalLabel6";
            this.pasajesPrincipalLabel6.Size = new System.Drawing.Size(35, 13);
            this.pasajesPrincipalLabel6.TabIndex = 49;
            this.pasajesPrincipalLabel6.Text = "Hasta";
            // 
            // pasajesPrincipalGroupBox1
            // 
            this.pasajesPrincipalGroupBox1.Controls.Add(this.pasajesPrincipalDataGridClientes);
            this.pasajesPrincipalGroupBox1.Controls.Add(this.pasajesPrincipalTextBox1);
            this.pasajesPrincipalGroupBox1.Controls.Add(this.pasajesPrincipalTextBox2);
            this.pasajesPrincipalGroupBox1.Controls.Add(this.pasajesPrincipalButton1);
            this.pasajesPrincipalGroupBox1.Controls.Add(this.pasajesPrincipalTextBox3);
            this.pasajesPrincipalGroupBox1.Controls.Add(this.pasajesPrincipalLabel3);
            this.pasajesPrincipalGroupBox1.Controls.Add(this.pasajesPrincipalLabel1);
            this.pasajesPrincipalGroupBox1.Controls.Add(this.pasajesPrincipalLabel2);
            this.pasajesPrincipalGroupBox1.Location = new System.Drawing.Point(8, 6);
            this.pasajesPrincipalGroupBox1.Name = "pasajesPrincipalGroupBox1";
            this.pasajesPrincipalGroupBox1.Size = new System.Drawing.Size(414, 289);
            this.pasajesPrincipalGroupBox1.TabIndex = 58;
            this.pasajesPrincipalGroupBox1.TabStop = false;
            this.pasajesPrincipalGroupBox1.Text = "Clientes";
            // 
            // pasajesPrincipalDataGridClientes
            // 
            this.pasajesPrincipalDataGridClientes.BackgroundColor = System.Drawing.SystemColors.InactiveCaption;
            this.pasajesPrincipalDataGridClientes.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Sunken;
            this.pasajesPrincipalDataGridClientes.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            this.pasajesPrincipalDataGridClientes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.pasajesPrincipalDataGridClientes.Cursor = System.Windows.Forms.Cursors.Default;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.InactiveCaption;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.pasajesPrincipalDataGridClientes.DefaultCellStyle = dataGridViewCellStyle3;
            this.pasajesPrincipalDataGridClientes.GridColor = System.Drawing.SystemColors.ActiveCaption;
            this.pasajesPrincipalDataGridClientes.Location = new System.Drawing.Point(3, 59);
            this.pasajesPrincipalDataGridClientes.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pasajesPrincipalDataGridClientes.Name = "pasajesPrincipalDataGridClientes";
            this.pasajesPrincipalDataGridClientes.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.pasajesPrincipalDataGridClientes.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.pasajesPrincipalDataGridClientes.RowHeadersWidth = 51;
            this.pasajesPrincipalDataGridClientes.RowTemplate.Height = 24;
            this.pasajesPrincipalDataGridClientes.Size = new System.Drawing.Size(402, 224);
            this.pasajesPrincipalDataGridClientes.TabIndex = 36;
            // 
            // pasajesPrincipalTextBox1
            // 
            this.pasajesPrincipalTextBox1.Location = new System.Drawing.Point(10, 33);
            this.pasajesPrincipalTextBox1.Name = "pasajesPrincipalTextBox1";
            this.pasajesPrincipalTextBox1.Size = new System.Drawing.Size(100, 20);
            this.pasajesPrincipalTextBox1.TabIndex = 40;
            // 
            // pasajesPrincipalTextBox2
            // 
            this.pasajesPrincipalTextBox2.Location = new System.Drawing.Point(116, 33);
            this.pasajesPrincipalTextBox2.Name = "pasajesPrincipalTextBox2";
            this.pasajesPrincipalTextBox2.Size = new System.Drawing.Size(100, 20);
            this.pasajesPrincipalTextBox2.TabIndex = 42;
            // 
            // pasajesPrincipalButton1
            // 
            this.pasajesPrincipalButton1.Location = new System.Drawing.Point(327, 33);
            this.pasajesPrincipalButton1.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pasajesPrincipalButton1.Name = "pasajesPrincipalButton1";
            this.pasajesPrincipalButton1.Size = new System.Drawing.Size(78, 20);
            this.pasajesPrincipalButton1.TabIndex = 55;
            this.pasajesPrincipalButton1.Text = "Buscar";
            this.pasajesPrincipalButton1.UseVisualStyleBackColor = true;
            this.pasajesPrincipalButton1.Click += new System.EventHandler(this.pasajesPrincipalButton1_Click);
            // 
            // pasajesPrincipalTextBox3
            // 
            this.pasajesPrincipalTextBox3.Location = new System.Drawing.Point(222, 33);
            this.pasajesPrincipalTextBox3.Name = "pasajesPrincipalTextBox3";
            this.pasajesPrincipalTextBox3.Size = new System.Drawing.Size(100, 20);
            this.pasajesPrincipalTextBox3.TabIndex = 43;
            // 
            // pasajesPrincipalLabel3
            // 
            this.pasajesPrincipalLabel3.AutoSize = true;
            this.pasajesPrincipalLabel3.Location = new System.Drawing.Point(221, 17);
            this.pasajesPrincipalLabel3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.pasajesPrincipalLabel3.Name = "pasajesPrincipalLabel3";
            this.pasajesPrincipalLabel3.Size = new System.Drawing.Size(26, 13);
            this.pasajesPrincipalLabel3.TabIndex = 54;
            this.pasajesPrincipalLabel3.Text = "DNI";
            // 
            // pasajesPrincipalLabel1
            // 
            this.pasajesPrincipalLabel1.AutoSize = true;
            this.pasajesPrincipalLabel1.Location = new System.Drawing.Point(9, 17);
            this.pasajesPrincipalLabel1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.pasajesPrincipalLabel1.Name = "pasajesPrincipalLabel1";
            this.pasajesPrincipalLabel1.Size = new System.Drawing.Size(44, 13);
            this.pasajesPrincipalLabel1.TabIndex = 52;
            this.pasajesPrincipalLabel1.Text = "Nombre";
            // 
            // pasajesPrincipalLabel2
            // 
            this.pasajesPrincipalLabel2.AutoSize = true;
            this.pasajesPrincipalLabel2.Location = new System.Drawing.Point(113, 17);
            this.pasajesPrincipalLabel2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.pasajesPrincipalLabel2.Name = "pasajesPrincipalLabel2";
            this.pasajesPrincipalLabel2.Size = new System.Drawing.Size(44, 13);
            this.pasajesPrincipalLabel2.TabIndex = 53;
            this.pasajesPrincipalLabel2.Text = "Apellido";
            // 
            // pasajesPrincipalButton5
            // 
            this.pasajesPrincipalButton5.Location = new System.Drawing.Point(8, 327);
            this.pasajesPrincipalButton5.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pasajesPrincipalButton5.Name = "pasajesPrincipalButton5";
            this.pasajesPrincipalButton5.Size = new System.Drawing.Size(153, 23);
            this.pasajesPrincipalButton5.TabIndex = 38;
            this.pasajesPrincipalButton5.Text = "Devoluciones";
            this.pasajesPrincipalButton5.UseVisualStyleBackColor = true;
            this.pasajesPrincipalButton5.Click += new System.EventHandler(this.pasajesPrincipalButton5_Click);
            // 
            // pasajesPrincipalButton4
            // 
            this.pasajesPrincipalButton4.Location = new System.Drawing.Point(590, 297);
            this.pasajesPrincipalButton4.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pasajesPrincipalButton4.Name = "pasajesPrincipalButton4";
            this.pasajesPrincipalButton4.Size = new System.Drawing.Size(153, 27);
            this.pasajesPrincipalButton4.TabIndex = 37;
            this.pasajesPrincipalButton4.Text = "Vender Pasaje";
            this.pasajesPrincipalButton4.UseVisualStyleBackColor = true;
            this.pasajesPrincipalButton4.Click += new System.EventHandler(this.pasajesPrincipalButton4_Click);
            // 
            // tabPageClientes
            // 
            this.tabPageClientes.BackColor = System.Drawing.Color.SteelBlue;
            this.tabPageClientes.Controls.Add(this.ClientesGroupBox1);
            this.tabPageClientes.Controls.Add(this.ClientesBotton4);
            this.tabPageClientes.Controls.Add(this.ClientesBotton3);
            this.tabPageClientes.Controls.Add(this.ClientesBotton2);
            this.tabPageClientes.Controls.Add(this.grillaClientes);
            this.tabPageClientes.Location = new System.Drawing.Point(4, 24);
            this.tabPageClientes.Name = "tabPageClientes";
            this.tabPageClientes.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageClientes.Size = new System.Drawing.Size(1150, 405);
            this.tabPageClientes.TabIndex = 1;
            this.tabPageClientes.Text = "Clientes";
            this.tabPageClientes.Click += new System.EventHandler(this.tabPageClientes_Click);
            // 
            // ClientesGroupBox1
            // 
            this.ClientesGroupBox1.Controls.Add(this.ClientesLabel4);
            this.ClientesGroupBox1.Controls.Add(this.ClientesTextBox4);
            this.ClientesGroupBox1.Controls.Add(this.ClientesLabel3);
            this.ClientesGroupBox1.Controls.Add(this.ClientesTextBox3);
            this.ClientesGroupBox1.Controls.Add(this.ClientesBotton6);
            this.ClientesGroupBox1.Controls.Add(this.ClientesBotton5);
            this.ClientesGroupBox1.Controls.Add(this.ClientesLabel2);
            this.ClientesGroupBox1.Controls.Add(this.ClientesTextBox2);
            this.ClientesGroupBox1.Controls.Add(this.ClientesLabel1);
            this.ClientesGroupBox1.Controls.Add(this.ClientesTextBox1);
            this.ClientesGroupBox1.Location = new System.Drawing.Point(533, 8);
            this.ClientesGroupBox1.Name = "ClientesGroupBox1";
            this.ClientesGroupBox1.Size = new System.Drawing.Size(252, 287);
            this.ClientesGroupBox1.TabIndex = 29;
            this.ClientesGroupBox1.TabStop = false;
            this.ClientesGroupBox1.Text = "Filtros";
            // 
            // ClientesLabel4
            // 
            this.ClientesLabel4.AutoSize = true;
            this.ClientesLabel4.Location = new System.Drawing.Point(0, 172);
            this.ClientesLabel4.Name = "ClientesLabel4";
            this.ClientesLabel4.Size = new System.Drawing.Size(32, 13);
            this.ClientesLabel4.TabIndex = 23;
            this.ClientesLabel4.Text = "Email";
            // 
            // ClientesTextBox4
            // 
            this.ClientesTextBox4.Location = new System.Drawing.Point(0, 188);
            this.ClientesTextBox4.Name = "ClientesTextBox4";
            this.ClientesTextBox4.Size = new System.Drawing.Size(240, 20);
            this.ClientesTextBox4.TabIndex = 22;
            // 
            // ClientesLabel3
            // 
            this.ClientesLabel3.AutoSize = true;
            this.ClientesLabel3.Location = new System.Drawing.Point(0, 119);
            this.ClientesLabel3.Name = "ClientesLabel3";
            this.ClientesLabel3.Size = new System.Drawing.Size(26, 13);
            this.ClientesLabel3.TabIndex = 21;
            this.ClientesLabel3.Text = "DNI";
            // 
            // ClientesTextBox3
            // 
            this.ClientesTextBox3.Location = new System.Drawing.Point(0, 135);
            this.ClientesTextBox3.Name = "ClientesTextBox3";
            this.ClientesTextBox3.Size = new System.Drawing.Size(240, 20);
            this.ClientesTextBox3.TabIndex = 20;
            // 
            // ClientesBotton6
            // 
            this.ClientesBotton6.Location = new System.Drawing.Point(176, 249);
            this.ClientesBotton6.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.ClientesBotton6.Name = "ClientesBotton6";
            this.ClientesBotton6.Size = new System.Drawing.Size(71, 27);
            this.ClientesBotton6.TabIndex = 19;
            this.ClientesBotton6.Text = "Limpiar";
            this.ClientesBotton6.UseVisualStyleBackColor = true;
            this.ClientesBotton6.Click += new System.EventHandler(this.ClientesBotton6_Click);
            // 
            // ClientesBotton5
            // 
            this.ClientesBotton5.Location = new System.Drawing.Point(5, 249);
            this.ClientesBotton5.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.ClientesBotton5.Name = "ClientesBotton5";
            this.ClientesBotton5.Size = new System.Drawing.Size(71, 27);
            this.ClientesBotton5.TabIndex = 18;
            this.ClientesBotton5.Text = "Aplicar";
            this.ClientesBotton5.UseVisualStyleBackColor = true;
            this.ClientesBotton5.Click += new System.EventHandler(this.ClientesBotton5_Click);
            // 
            // ClientesLabel2
            // 
            this.ClientesLabel2.AutoSize = true;
            this.ClientesLabel2.Location = new System.Drawing.Point(0, 66);
            this.ClientesLabel2.Name = "ClientesLabel2";
            this.ClientesLabel2.Size = new System.Drawing.Size(44, 13);
            this.ClientesLabel2.TabIndex = 11;
            this.ClientesLabel2.Text = "Apellido";
            // 
            // ClientesTextBox2
            // 
            this.ClientesTextBox2.Location = new System.Drawing.Point(0, 82);
            this.ClientesTextBox2.Name = "ClientesTextBox2";
            this.ClientesTextBox2.Size = new System.Drawing.Size(240, 20);
            this.ClientesTextBox2.TabIndex = 10;
            // 
            // ClientesLabel1
            // 
            this.ClientesLabel1.AutoSize = true;
            this.ClientesLabel1.Location = new System.Drawing.Point(0, 17);
            this.ClientesLabel1.Name = "ClientesLabel1";
            this.ClientesLabel1.Size = new System.Drawing.Size(44, 13);
            this.ClientesLabel1.TabIndex = 9;
            this.ClientesLabel1.Text = "Nombre";
            // 
            // ClientesTextBox1
            // 
            this.ClientesTextBox1.Location = new System.Drawing.Point(0, 33);
            this.ClientesTextBox1.Name = "ClientesTextBox1";
            this.ClientesTextBox1.Size = new System.Drawing.Size(240, 20);
            this.ClientesTextBox1.TabIndex = 7;
            // 
            // ClientesBotton4
            // 
            this.ClientesBotton4.Location = new System.Drawing.Point(157, 301);
            this.ClientesBotton4.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.ClientesBotton4.Name = "ClientesBotton4";
            this.ClientesBotton4.Size = new System.Drawing.Size(71, 27);
            this.ClientesBotton4.TabIndex = 28;
            this.ClientesBotton4.Text = "Baja";
            this.ClientesBotton4.UseVisualStyleBackColor = true;
            this.ClientesBotton4.Click += new System.EventHandler(this.ClientesBotton4_Click);
            // 
            // ClientesBotton3
            // 
            this.ClientesBotton3.Location = new System.Drawing.Point(82, 301);
            this.ClientesBotton3.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.ClientesBotton3.Name = "ClientesBotton3";
            this.ClientesBotton3.Size = new System.Drawing.Size(71, 27);
            this.ClientesBotton3.TabIndex = 27;
            this.ClientesBotton3.Text = "Modificar";
            this.ClientesBotton3.UseVisualStyleBackColor = true;
            this.ClientesBotton3.Click += new System.EventHandler(this.ClientesBotton3_Click);
            // 
            // ClientesBotton2
            // 
            this.ClientesBotton2.Location = new System.Drawing.Point(7, 301);
            this.ClientesBotton2.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.ClientesBotton2.Name = "ClientesBotton2";
            this.ClientesBotton2.Size = new System.Drawing.Size(71, 27);
            this.ClientesBotton2.TabIndex = 26;
            this.ClientesBotton2.Text = "Alta";
            this.ClientesBotton2.UseVisualStyleBackColor = true;
            this.ClientesBotton2.Click += new System.EventHandler(this.ClientesBotton2_Click);
            // 
            // grillaClientes
            // 
            this.grillaClientes.BackgroundColor = System.Drawing.SystemColors.InactiveCaption;
            this.grillaClientes.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Sunken;
            this.grillaClientes.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            this.grillaClientes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grillaClientes.Cursor = System.Windows.Forms.Cursors.Default;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.InactiveCaption;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.grillaClientes.DefaultCellStyle = dataGridViewCellStyle5;
            this.grillaClientes.GridColor = System.Drawing.SystemColors.ActiveCaption;
            this.grillaClientes.Location = new System.Drawing.Point(7, 6);
            this.grillaClientes.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.grillaClientes.Name = "grillaClientes";
            this.grillaClientes.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grillaClientes.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.grillaClientes.RowHeadersWidth = 51;
            this.grillaClientes.RowTemplate.Height = 24;
            this.grillaClientes.Size = new System.Drawing.Size(521, 289);
            this.grillaClientes.TabIndex = 24;
            // 
            // tabPageViajes
            // 
            this.tabPageViajes.BackColor = System.Drawing.Color.SteelBlue;
            this.tabPageViajes.Controls.Add(this.ViajesPrincipalButton7);
            this.tabPageViajes.Controls.Add(this.ViajePrincipalGroupBox1);
            this.tabPageViajes.Controls.Add(this.ViajesPrincipalButton4);
            this.tabPageViajes.Controls.Add(this.ViajesPrincipalButton3);
            this.tabPageViajes.Controls.Add(this.ViajesPrincipalButton2);
            this.tabPageViajes.Controls.Add(this.ViajesPrincipalButton1);
            this.tabPageViajes.Controls.Add(this.ViajesPrincipalDataGrid);
            this.tabPageViajes.Location = new System.Drawing.Point(4, 24);
            this.tabPageViajes.Name = "tabPageViajes";
            this.tabPageViajes.Size = new System.Drawing.Size(1150, 405);
            this.tabPageViajes.TabIndex = 2;
            this.tabPageViajes.Text = "Viajes";
            // 
            // ViajesPrincipalButton7
            // 
            this.ViajesPrincipalButton7.Location = new System.Drawing.Point(533, 323);
            this.ViajesPrincipalButton7.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.ViajesPrincipalButton7.Name = "ViajesPrincipalButton7";
            this.ViajesPrincipalButton7.Size = new System.Drawing.Size(71, 27);
            this.ViajesPrincipalButton7.TabIndex = 36;
            this.ViajesPrincipalButton7.Text = "Reporte";
            this.ViajesPrincipalButton7.UseVisualStyleBackColor = true;
            this.ViajesPrincipalButton7.Click += new System.EventHandler(this.ViajesPrincipalButton7_Click);
            // 
            // ViajePrincipalGroupBox1
            // 
            this.ViajePrincipalGroupBox1.Controls.Add(this.ViajesPrincipalCheckBox);
            this.ViajePrincipalGroupBox1.Controls.Add(this.ViajeDatePickerHastaHora);
            this.ViajePrincipalGroupBox1.Controls.Add(this.ViajeDatePickerDesdeHora);
            this.ViajePrincipalGroupBox1.Controls.Add(this.ViajePrincipalLabel4);
            this.ViajePrincipalGroupBox1.Controls.Add(this.ViajePrincipalLabel3);
            this.ViajePrincipalGroupBox1.Controls.Add(this.ViajeDatePickerHasta);
            this.ViajePrincipalGroupBox1.Controls.Add(this.ViajeDatePickerDesde);
            this.ViajePrincipalGroupBox1.Controls.Add(this.ViajesPrincipalButton6);
            this.ViajePrincipalGroupBox1.Controls.Add(this.ViajesPrincipalButton5);
            this.ViajePrincipalGroupBox1.Controls.Add(this.ViajePrincipalLabel2);
            this.ViajePrincipalGroupBox1.Controls.Add(this.ViajesPrincipalText2);
            this.ViajePrincipalGroupBox1.Controls.Add(this.ViajePrincipalLabel1);
            this.ViajePrincipalGroupBox1.Controls.Add(this.ViajesPrincipalText1);
            this.ViajePrincipalGroupBox1.Location = new System.Drawing.Point(533, 5);
            this.ViajePrincipalGroupBox1.Name = "ViajePrincipalGroupBox1";
            this.ViajePrincipalGroupBox1.Size = new System.Drawing.Size(323, 312);
            this.ViajePrincipalGroupBox1.TabIndex = 35;
            this.ViajePrincipalGroupBox1.TabStop = false;
            this.ViajePrincipalGroupBox1.Text = "Filtros";
            // 
            // ViajesPrincipalCheckBox
            // 
            this.ViajesPrincipalCheckBox.AutoSize = true;
            this.ViajesPrincipalCheckBox.Location = new System.Drawing.Point(3, 118);
            this.ViajesPrincipalCheckBox.Name = "ViajesPrincipalCheckBox";
            this.ViajesPrincipalCheckBox.Size = new System.Drawing.Size(77, 17);
            this.ViajesPrincipalCheckBox.TabIndex = 32;
            this.ViajesPrincipalCheckBox.Text = "Cancelado";
            this.ViajesPrincipalCheckBox.UseVisualStyleBackColor = true;
            // 
            // ViajeDatePickerHastaHora
            // 
            this.ViajeDatePickerHastaHora.CustomFormat = "H:mm:ss";
            this.ViajeDatePickerHastaHora.Location = new System.Drawing.Point(212, 217);
            this.ViajeDatePickerHastaHora.Name = "ViajeDatePickerHastaHora";
            this.ViajeDatePickerHastaHora.Size = new System.Drawing.Size(98, 20);
            this.ViajeDatePickerHastaHora.TabIndex = 31;
            // 
            // ViajeDatePickerDesdeHora
            // 
            this.ViajeDatePickerDesdeHora.CustomFormat = "H:mm:ss";
            this.ViajeDatePickerDesdeHora.Location = new System.Drawing.Point(212, 163);
            this.ViajeDatePickerDesdeHora.Name = "ViajeDatePickerDesdeHora";
            this.ViajeDatePickerDesdeHora.Size = new System.Drawing.Size(98, 20);
            this.ViajeDatePickerDesdeHora.TabIndex = 30;
            // 
            // ViajePrincipalLabel4
            // 
            this.ViajePrincipalLabel4.AutoSize = true;
            this.ViajePrincipalLabel4.Location = new System.Drawing.Point(5, 201);
            this.ViajePrincipalLabel4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.ViajePrincipalLabel4.Name = "ViajePrincipalLabel4";
            this.ViajePrincipalLabel4.Size = new System.Drawing.Size(35, 13);
            this.ViajePrincipalLabel4.TabIndex = 29;
            this.ViajePrincipalLabel4.Text = "Hasta";
            // 
            // ViajePrincipalLabel3
            // 
            this.ViajePrincipalLabel3.AutoSize = true;
            this.ViajePrincipalLabel3.Location = new System.Drawing.Point(2, 147);
            this.ViajePrincipalLabel3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.ViajePrincipalLabel3.Name = "ViajePrincipalLabel3";
            this.ViajePrincipalLabel3.Size = new System.Drawing.Size(38, 13);
            this.ViajePrincipalLabel3.TabIndex = 28;
            this.ViajePrincipalLabel3.Text = "Desde";
            // 
            // ViajeDatePickerHasta
            // 
            this.ViajeDatePickerHasta.CustomFormat = "MM-dd-yy";
            this.ViajeDatePickerHasta.Location = new System.Drawing.Point(3, 217);
            this.ViajeDatePickerHasta.Name = "ViajeDatePickerHasta";
            this.ViajeDatePickerHasta.Size = new System.Drawing.Size(200, 20);
            this.ViajeDatePickerHasta.TabIndex = 27;
            // 
            // ViajeDatePickerDesde
            // 
            this.ViajeDatePickerDesde.CustomFormat = "MM-dd-yy";
            this.ViajeDatePickerDesde.Location = new System.Drawing.Point(3, 163);
            this.ViajeDatePickerDesde.Name = "ViajeDatePickerDesde";
            this.ViajeDatePickerDesde.Size = new System.Drawing.Size(200, 20);
            this.ViajeDatePickerDesde.TabIndex = 26;
            // 
            // ViajesPrincipalButton6
            // 
            this.ViajesPrincipalButton6.Location = new System.Drawing.Point(172, 262);
            this.ViajesPrincipalButton6.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.ViajesPrincipalButton6.Name = "ViajesPrincipalButton6";
            this.ViajesPrincipalButton6.Size = new System.Drawing.Size(71, 27);
            this.ViajesPrincipalButton6.TabIndex = 19;
            this.ViajesPrincipalButton6.Text = "Limpiar";
            this.ViajesPrincipalButton6.UseVisualStyleBackColor = true;
            this.ViajesPrincipalButton6.Click += new System.EventHandler(this.ViajesPrincipalButton6_Click);
            // 
            // ViajesPrincipalButton5
            // 
            this.ViajesPrincipalButton5.Location = new System.Drawing.Point(8, 262);
            this.ViajesPrincipalButton5.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.ViajesPrincipalButton5.Name = "ViajesPrincipalButton5";
            this.ViajesPrincipalButton5.Size = new System.Drawing.Size(71, 27);
            this.ViajesPrincipalButton5.TabIndex = 18;
            this.ViajesPrincipalButton5.Text = "Aplicar";
            this.ViajesPrincipalButton5.UseVisualStyleBackColor = true;
            this.ViajesPrincipalButton5.Click += new System.EventHandler(this.ViajesPrincipalButton5_Click);
            // 
            // ViajePrincipalLabel2
            // 
            this.ViajePrincipalLabel2.AutoSize = true;
            this.ViajePrincipalLabel2.Location = new System.Drawing.Point(0, 66);
            this.ViajePrincipalLabel2.Name = "ViajePrincipalLabel2";
            this.ViajePrincipalLabel2.Size = new System.Drawing.Size(30, 13);
            this.ViajePrincipalLabel2.TabIndex = 11;
            this.ViajePrincipalLabel2.Text = "Ruta";
            // 
            // ViajesPrincipalText2
            // 
            this.ViajesPrincipalText2.Location = new System.Drawing.Point(3, 82);
            this.ViajesPrincipalText2.Name = "ViajesPrincipalText2";
            this.ViajesPrincipalText2.Size = new System.Drawing.Size(240, 20);
            this.ViajesPrincipalText2.TabIndex = 10;
            // 
            // ViajePrincipalLabel1
            // 
            this.ViajePrincipalLabel1.AutoSize = true;
            this.ViajePrincipalLabel1.Location = new System.Drawing.Point(0, 17);
            this.ViajePrincipalLabel1.Name = "ViajePrincipalLabel1";
            this.ViajePrincipalLabel1.Size = new System.Drawing.Size(25, 13);
            this.ViajePrincipalLabel1.TabIndex = 9;
            this.ViajePrincipalLabel1.Text = "Bus";
            // 
            // ViajesPrincipalText1
            // 
            this.ViajesPrincipalText1.Location = new System.Drawing.Point(3, 33);
            this.ViajesPrincipalText1.Name = "ViajesPrincipalText1";
            this.ViajesPrincipalText1.Size = new System.Drawing.Size(240, 20);
            this.ViajesPrincipalText1.TabIndex = 7;
            // 
            // ViajesPrincipalButton4
            // 
            this.ViajesPrincipalButton4.Location = new System.Drawing.Point(232, 323);
            this.ViajesPrincipalButton4.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.ViajesPrincipalButton4.Name = "ViajesPrincipalButton4";
            this.ViajesPrincipalButton4.Size = new System.Drawing.Size(71, 27);
            this.ViajesPrincipalButton4.TabIndex = 34;
            this.ViajesPrincipalButton4.Text = "Baja";
            this.ViajesPrincipalButton4.UseVisualStyleBackColor = true;
            this.ViajesPrincipalButton4.Click += new System.EventHandler(this.ViajesPrincipalButton4_Click);
            // 
            // ViajesPrincipalButton3
            // 
            this.ViajesPrincipalButton3.Location = new System.Drawing.Point(157, 323);
            this.ViajesPrincipalButton3.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.ViajesPrincipalButton3.Name = "ViajesPrincipalButton3";
            this.ViajesPrincipalButton3.Size = new System.Drawing.Size(71, 27);
            this.ViajesPrincipalButton3.TabIndex = 33;
            this.ViajesPrincipalButton3.Text = "Modificar";
            this.ViajesPrincipalButton3.UseVisualStyleBackColor = true;
            this.ViajesPrincipalButton3.Click += new System.EventHandler(this.ViajesPrincipalButton3_Click);
            // 
            // ViajesPrincipalButton2
            // 
            this.ViajesPrincipalButton2.Location = new System.Drawing.Point(82, 323);
            this.ViajesPrincipalButton2.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.ViajesPrincipalButton2.Name = "ViajesPrincipalButton2";
            this.ViajesPrincipalButton2.Size = new System.Drawing.Size(71, 27);
            this.ViajesPrincipalButton2.TabIndex = 32;
            this.ViajesPrincipalButton2.Text = "Alta";
            this.ViajesPrincipalButton2.UseVisualStyleBackColor = true;
            this.ViajesPrincipalButton2.Click += new System.EventHandler(this.ViajesPrincipalButton2_Click);
            // 
            // ViajesPrincipalButton1
            // 
            this.ViajesPrincipalButton1.Location = new System.Drawing.Point(7, 323);
            this.ViajesPrincipalButton1.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.ViajesPrincipalButton1.Name = "ViajesPrincipalButton1";
            this.ViajesPrincipalButton1.Size = new System.Drawing.Size(71, 27);
            this.ViajesPrincipalButton1.TabIndex = 31;
            this.ViajesPrincipalButton1.Text = "Ver";
            this.ViajesPrincipalButton1.UseVisualStyleBackColor = true;
            this.ViajesPrincipalButton1.Click += new System.EventHandler(this.ViajesPrincipalButton1_Click);
            // 
            // ViajesPrincipalDataGrid
            // 
            this.ViajesPrincipalDataGrid.BackgroundColor = System.Drawing.SystemColors.InactiveCaption;
            this.ViajesPrincipalDataGrid.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Sunken;
            this.ViajesPrincipalDataGrid.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            this.ViajesPrincipalDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ViajesPrincipalDataGrid.Cursor = System.Windows.Forms.Cursors.Default;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.InactiveCaption;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.ViajesPrincipalDataGrid.DefaultCellStyle = dataGridViewCellStyle7;
            this.ViajesPrincipalDataGrid.GridColor = System.Drawing.SystemColors.ActiveCaption;
            this.ViajesPrincipalDataGrid.Location = new System.Drawing.Point(7, 3);
            this.ViajesPrincipalDataGrid.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.ViajesPrincipalDataGrid.Name = "ViajesPrincipalDataGrid";
            this.ViajesPrincipalDataGrid.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.ViajesPrincipalDataGrid.RowHeadersDefaultCellStyle = dataGridViewCellStyle8;
            this.ViajesPrincipalDataGrid.RowHeadersWidth = 51;
            this.ViajesPrincipalDataGrid.RowTemplate.Height = 24;
            this.ViajesPrincipalDataGrid.Size = new System.Drawing.Size(521, 314);
            this.ViajesPrincipalDataGrid.TabIndex = 30;
            // 
            // tabPageRutas
            // 
            this.tabPageRutas.BackColor = System.Drawing.Color.SteelBlue;
            this.tabPageRutas.Controls.Add(this.RutasGroupBox);
            this.tabPageRutas.Controls.Add(this.RutasButton4);
            this.tabPageRutas.Controls.Add(this.RutasButton3);
            this.tabPageRutas.Controls.Add(this.RutasButton2);
            this.tabPageRutas.Controls.Add(this.dataGridRutas);
            this.tabPageRutas.Location = new System.Drawing.Point(4, 24);
            this.tabPageRutas.Name = "tabPageRutas";
            this.tabPageRutas.Size = new System.Drawing.Size(1150, 405);
            this.tabPageRutas.TabIndex = 3;
            this.tabPageRutas.Text = "Rutas";
            // 
            // RutasGroupBox
            // 
            this.RutasGroupBox.Controls.Add(this.RutaLabel2);
            this.RutasGroupBox.Controls.Add(this.RutasPrincipalText3);
            this.RutasGroupBox.Controls.Add(this.RutasButton6);
            this.RutasGroupBox.Controls.Add(this.RutasButton5);
            this.RutasGroupBox.Controls.Add(this.RutaLabel1);
            this.RutasGroupBox.Controls.Add(this.RutasPrincipalText2);
            this.RutasGroupBox.Location = new System.Drawing.Point(533, 5);
            this.RutasGroupBox.Name = "RutasGroupBox";
            this.RutasGroupBox.Size = new System.Drawing.Size(259, 162);
            this.RutasGroupBox.TabIndex = 29;
            this.RutasGroupBox.TabStop = false;
            this.RutasGroupBox.Text = "Filtros";
            // 
            // RutaLabel2
            // 
            this.RutaLabel2.AutoSize = true;
            this.RutaLabel2.Location = new System.Drawing.Point(5, 73);
            this.RutaLabel2.Name = "RutaLabel2";
            this.RutaLabel2.Size = new System.Drawing.Size(43, 13);
            this.RutaLabel2.TabIndex = 21;
            this.RutaLabel2.Text = "Destino";
            // 
            // RutasPrincipalText3
            // 
            this.RutasPrincipalText3.Location = new System.Drawing.Point(5, 89);
            this.RutasPrincipalText3.Name = "RutasPrincipalText3";
            this.RutasPrincipalText3.Size = new System.Drawing.Size(240, 20);
            this.RutasPrincipalText3.TabIndex = 20;
            // 
            // RutasButton6
            // 
            this.RutasButton6.Location = new System.Drawing.Point(181, 115);
            this.RutasButton6.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.RutasButton6.Name = "RutasButton6";
            this.RutasButton6.Size = new System.Drawing.Size(71, 27);
            this.RutasButton6.TabIndex = 19;
            this.RutasButton6.Text = "Limpiar";
            this.RutasButton6.UseVisualStyleBackColor = true;
            this.RutasButton6.Click += new System.EventHandler(this.RutasButton6_Click);
            // 
            // RutasButton5
            // 
            this.RutasButton5.Location = new System.Drawing.Point(8, 115);
            this.RutasButton5.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.RutasButton5.Name = "RutasButton5";
            this.RutasButton5.Size = new System.Drawing.Size(71, 27);
            this.RutasButton5.TabIndex = 18;
            this.RutasButton5.Text = "Aplicar";
            this.RutasButton5.UseVisualStyleBackColor = true;
            this.RutasButton5.Click += new System.EventHandler(this.RutasButton5_Click);
            // 
            // RutaLabel1
            // 
            this.RutaLabel1.AutoSize = true;
            this.RutaLabel1.Location = new System.Drawing.Point(5, 20);
            this.RutaLabel1.Name = "RutaLabel1";
            this.RutaLabel1.Size = new System.Drawing.Size(38, 13);
            this.RutaLabel1.TabIndex = 11;
            this.RutaLabel1.Text = "Origen";
            // 
            // RutasPrincipalText2
            // 
            this.RutasPrincipalText2.Location = new System.Drawing.Point(5, 36);
            this.RutasPrincipalText2.Name = "RutasPrincipalText2";
            this.RutasPrincipalText2.Size = new System.Drawing.Size(240, 20);
            this.RutasPrincipalText2.TabIndex = 10;
            // 
            // RutasButton4
            // 
            this.RutasButton4.Location = new System.Drawing.Point(157, 298);
            this.RutasButton4.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.RutasButton4.Name = "RutasButton4";
            this.RutasButton4.Size = new System.Drawing.Size(71, 27);
            this.RutasButton4.TabIndex = 28;
            this.RutasButton4.Text = "Baja";
            this.RutasButton4.UseVisualStyleBackColor = true;
            this.RutasButton4.Click += new System.EventHandler(this.RutasButton4_Click);
            // 
            // RutasButton3
            // 
            this.RutasButton3.Location = new System.Drawing.Point(82, 298);
            this.RutasButton3.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.RutasButton3.Name = "RutasButton3";
            this.RutasButton3.Size = new System.Drawing.Size(71, 27);
            this.RutasButton3.TabIndex = 27;
            this.RutasButton3.Text = "Modificar";
            this.RutasButton3.UseVisualStyleBackColor = true;
            this.RutasButton3.Click += new System.EventHandler(this.RutasButton3_Click);
            // 
            // RutasButton2
            // 
            this.RutasButton2.Location = new System.Drawing.Point(7, 298);
            this.RutasButton2.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.RutasButton2.Name = "RutasButton2";
            this.RutasButton2.Size = new System.Drawing.Size(71, 27);
            this.RutasButton2.TabIndex = 26;
            this.RutasButton2.Text = "Alta";
            this.RutasButton2.UseVisualStyleBackColor = true;
            this.RutasButton2.Click += new System.EventHandler(this.RutasButton2_Click);
            // 
            // dataGridRutas
            // 
            this.dataGridRutas.BackgroundColor = System.Drawing.SystemColors.InactiveCaption;
            this.dataGridRutas.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Sunken;
            this.dataGridRutas.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            this.dataGridRutas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridRutas.Cursor = System.Windows.Forms.Cursors.Default;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.InactiveCaption;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridRutas.DefaultCellStyle = dataGridViewCellStyle9;
            this.dataGridRutas.GridColor = System.Drawing.SystemColors.ActiveCaption;
            this.dataGridRutas.Location = new System.Drawing.Point(7, 3);
            this.dataGridRutas.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.dataGridRutas.Name = "dataGridRutas";
            this.dataGridRutas.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridRutas.RowHeadersDefaultCellStyle = dataGridViewCellStyle10;
            this.dataGridRutas.RowHeadersWidth = 51;
            this.dataGridRutas.RowTemplate.Height = 24;
            this.dataGridRutas.Size = new System.Drawing.Size(521, 289);
            this.dataGridRutas.TabIndex = 24;
            // 
            // tabPageLocalidades
            // 
            this.tabPageLocalidades.BackColor = System.Drawing.Color.SteelBlue;
            this.tabPageLocalidades.Controls.Add(this.LocalidadGroupBox);
            this.tabPageLocalidades.Controls.Add(this.LocalidadBotton4);
            this.tabPageLocalidades.Controls.Add(this.LocalidadBotton3);
            this.tabPageLocalidades.Controls.Add(this.LocalidadBotton2);
            this.tabPageLocalidades.Controls.Add(this.grillaLocalidad);
            this.tabPageLocalidades.Location = new System.Drawing.Point(4, 24);
            this.tabPageLocalidades.Name = "tabPageLocalidades";
            this.tabPageLocalidades.Size = new System.Drawing.Size(1150, 405);
            this.tabPageLocalidades.TabIndex = 4;
            this.tabPageLocalidades.Text = "Localidades";
            this.tabPageLocalidades.Click += new System.EventHandler(this.tabPageLocalidades_Click);
            // 
            // LocalidadGroupBox
            // 
            this.LocalidadGroupBox.Controls.Add(this.LocalidadLabel3);
            this.LocalidadGroupBox.Controls.Add(this.LocalidadPrincipalText3);
            this.LocalidadGroupBox.Controls.Add(this.LocalidadBotton6);
            this.LocalidadGroupBox.Controls.Add(this.LocalidadBotton5);
            this.LocalidadGroupBox.Controls.Add(this.LocalidadLabel2);
            this.LocalidadGroupBox.Controls.Add(this.LocalidadPrincipalText2);
            this.LocalidadGroupBox.Controls.Add(this.LocalidadLabel1);
            this.LocalidadGroupBox.Controls.Add(this.LocalidadPrincipalText1);
            this.LocalidadGroupBox.Location = new System.Drawing.Point(533, 5);
            this.LocalidadGroupBox.Name = "LocalidadGroupBox";
            this.LocalidadGroupBox.Size = new System.Drawing.Size(252, 237);
            this.LocalidadGroupBox.TabIndex = 23;
            this.LocalidadGroupBox.TabStop = false;
            this.LocalidadGroupBox.Text = "Filtros";
            // 
            // LocalidadLabel3
            // 
            this.LocalidadLabel3.AutoSize = true;
            this.LocalidadLabel3.Location = new System.Drawing.Point(0, 119);
            this.LocalidadLabel3.Name = "LocalidadLabel3";
            this.LocalidadLabel3.Size = new System.Drawing.Size(27, 13);
            this.LocalidadLabel3.TabIndex = 21;
            this.LocalidadLabel3.Text = "Pais";
            // 
            // LocalidadPrincipalText3
            // 
            this.LocalidadPrincipalText3.Location = new System.Drawing.Point(0, 135);
            this.LocalidadPrincipalText3.Name = "LocalidadPrincipalText3";
            this.LocalidadPrincipalText3.Size = new System.Drawing.Size(240, 20);
            this.LocalidadPrincipalText3.TabIndex = 20;
            // 
            // LocalidadBotton6
            // 
            this.LocalidadBotton6.Location = new System.Drawing.Point(176, 161);
            this.LocalidadBotton6.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.LocalidadBotton6.Name = "LocalidadBotton6";
            this.LocalidadBotton6.Size = new System.Drawing.Size(71, 27);
            this.LocalidadBotton6.TabIndex = 19;
            this.LocalidadBotton6.Text = "Limpiar";
            this.LocalidadBotton6.UseVisualStyleBackColor = true;
            this.LocalidadBotton6.Click += new System.EventHandler(this.LocalidadBotton6_Click);
            // 
            // LocalidadBotton5
            // 
            this.LocalidadBotton5.Location = new System.Drawing.Point(3, 161);
            this.LocalidadBotton5.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.LocalidadBotton5.Name = "LocalidadBotton5";
            this.LocalidadBotton5.Size = new System.Drawing.Size(71, 27);
            this.LocalidadBotton5.TabIndex = 18;
            this.LocalidadBotton5.Text = "Aplicar";
            this.LocalidadBotton5.UseVisualStyleBackColor = true;
            this.LocalidadBotton5.Click += new System.EventHandler(this.LocalidadBotton5_Click);
            // 
            // LocalidadLabel2
            // 
            this.LocalidadLabel2.AutoSize = true;
            this.LocalidadLabel2.Location = new System.Drawing.Point(0, 66);
            this.LocalidadLabel2.Name = "LocalidadLabel2";
            this.LocalidadLabel2.Size = new System.Drawing.Size(51, 13);
            this.LocalidadLabel2.TabIndex = 11;
            this.LocalidadLabel2.Text = "Provincia";
            // 
            // LocalidadPrincipalText2
            // 
            this.LocalidadPrincipalText2.Location = new System.Drawing.Point(0, 82);
            this.LocalidadPrincipalText2.Name = "LocalidadPrincipalText2";
            this.LocalidadPrincipalText2.Size = new System.Drawing.Size(240, 20);
            this.LocalidadPrincipalText2.TabIndex = 10;
            // 
            // LocalidadLabel1
            // 
            this.LocalidadLabel1.AutoSize = true;
            this.LocalidadLabel1.Location = new System.Drawing.Point(0, 17);
            this.LocalidadLabel1.Name = "LocalidadLabel1";
            this.LocalidadLabel1.Size = new System.Drawing.Size(44, 13);
            this.LocalidadLabel1.TabIndex = 9;
            this.LocalidadLabel1.Text = "Nombre";
            // 
            // LocalidadPrincipalText1
            // 
            this.LocalidadPrincipalText1.Location = new System.Drawing.Point(0, 33);
            this.LocalidadPrincipalText1.Name = "LocalidadPrincipalText1";
            this.LocalidadPrincipalText1.Size = new System.Drawing.Size(240, 20);
            this.LocalidadPrincipalText1.TabIndex = 7;
            // 
            // LocalidadBotton4
            // 
            this.LocalidadBotton4.Location = new System.Drawing.Point(157, 298);
            this.LocalidadBotton4.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.LocalidadBotton4.Name = "LocalidadBotton4";
            this.LocalidadBotton4.Size = new System.Drawing.Size(71, 27);
            this.LocalidadBotton4.TabIndex = 22;
            this.LocalidadBotton4.Text = "Baja";
            this.LocalidadBotton4.UseVisualStyleBackColor = true;
            this.LocalidadBotton4.Click += new System.EventHandler(this.LocalidadBotton4_Click);
            // 
            // LocalidadBotton3
            // 
            this.LocalidadBotton3.Location = new System.Drawing.Point(82, 298);
            this.LocalidadBotton3.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.LocalidadBotton3.Name = "LocalidadBotton3";
            this.LocalidadBotton3.Size = new System.Drawing.Size(71, 27);
            this.LocalidadBotton3.TabIndex = 21;
            this.LocalidadBotton3.Text = "Modificar";
            this.LocalidadBotton3.UseVisualStyleBackColor = true;
            this.LocalidadBotton3.Click += new System.EventHandler(this.LocalidadBotton3_Click);
            // 
            // LocalidadBotton2
            // 
            this.LocalidadBotton2.Location = new System.Drawing.Point(7, 298);
            this.LocalidadBotton2.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.LocalidadBotton2.Name = "LocalidadBotton2";
            this.LocalidadBotton2.Size = new System.Drawing.Size(71, 27);
            this.LocalidadBotton2.TabIndex = 20;
            this.LocalidadBotton2.Text = "Alta";
            this.LocalidadBotton2.UseVisualStyleBackColor = true;
            this.LocalidadBotton2.Click += new System.EventHandler(this.LocalidadBotton2_Click);
            // 
            // grillaLocalidad
            // 
            this.grillaLocalidad.BackgroundColor = System.Drawing.SystemColors.InactiveCaption;
            this.grillaLocalidad.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Sunken;
            this.grillaLocalidad.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            this.grillaLocalidad.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grillaLocalidad.Cursor = System.Windows.Forms.Cursors.Default;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.InactiveCaption;
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.grillaLocalidad.DefaultCellStyle = dataGridViewCellStyle11;
            this.grillaLocalidad.GridColor = System.Drawing.SystemColors.ActiveCaption;
            this.grillaLocalidad.Location = new System.Drawing.Point(7, 3);
            this.grillaLocalidad.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.grillaLocalidad.Name = "grillaLocalidad";
            this.grillaLocalidad.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle12.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grillaLocalidad.RowHeadersDefaultCellStyle = dataGridViewCellStyle12;
            this.grillaLocalidad.RowHeadersWidth = 51;
            this.grillaLocalidad.RowTemplate.Height = 24;
            this.grillaLocalidad.Size = new System.Drawing.Size(521, 289);
            this.grillaLocalidad.TabIndex = 18;
            // 
            // tabPageBuses
            // 
            this.tabPageBuses.BackColor = System.Drawing.Color.SteelBlue;
            this.tabPageBuses.Controls.Add(this.busesButton7);
            this.tabPageBuses.Controls.Add(this.busesGroupBox1);
            this.tabPageBuses.Controls.Add(this.busesButton4);
            this.tabPageBuses.Controls.Add(this.busesButton3);
            this.tabPageBuses.Controls.Add(this.busesButton2);
            this.tabPageBuses.Controls.Add(this.grillaBuses);
            this.tabPageBuses.Location = new System.Drawing.Point(4, 24);
            this.tabPageBuses.Name = "tabPageBuses";
            this.tabPageBuses.Size = new System.Drawing.Size(1150, 405);
            this.tabPageBuses.TabIndex = 6;
            this.tabPageBuses.Text = "Buses";
            // 
            // busesButton7
            // 
            this.busesButton7.Location = new System.Drawing.Point(536, 218);
            this.busesButton7.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.busesButton7.Name = "busesButton7";
            this.busesButton7.Size = new System.Drawing.Size(71, 27);
            this.busesButton7.TabIndex = 22;
            this.busesButton7.Text = "Reporte";
            this.busesButton7.UseVisualStyleBackColor = true;
            this.busesButton7.Click += new System.EventHandler(this.busesButton7_Click);
            // 
            // busesGroupBox1
            // 
            this.busesGroupBox1.Controls.Add(this.busesLabel3);
            this.busesGroupBox1.Controls.Add(this.busesText3);
            this.busesGroupBox1.Controls.Add(this.busesButton6);
            this.busesGroupBox1.Controls.Add(this.busesButton5);
            this.busesGroupBox1.Controls.Add(this.busesLabel2);
            this.busesGroupBox1.Controls.Add(this.busesText2);
            this.busesGroupBox1.Controls.Add(this.busesLabel1);
            this.busesGroupBox1.Controls.Add(this.busesText1);
            this.busesGroupBox1.Location = new System.Drawing.Point(533, 5);
            this.busesGroupBox1.Name = "busesGroupBox1";
            this.busesGroupBox1.Size = new System.Drawing.Size(252, 207);
            this.busesGroupBox1.TabIndex = 29;
            this.busesGroupBox1.TabStop = false;
            this.busesGroupBox1.Text = "Filtros";
            // 
            // busesLabel3
            // 
            this.busesLabel3.AutoSize = true;
            this.busesLabel3.Location = new System.Drawing.Point(0, 119);
            this.busesLabel3.Name = "busesLabel3";
            this.busesLabel3.Size = new System.Drawing.Size(47, 13);
            this.busesLabel3.TabIndex = 21;
            this.busesLabel3.Text = "Asientos";
            // 
            // busesText3
            // 
            this.busesText3.Location = new System.Drawing.Point(0, 135);
            this.busesText3.Name = "busesText3";
            this.busesText3.Size = new System.Drawing.Size(240, 20);
            this.busesText3.TabIndex = 20;
            // 
            // busesButton6
            // 
            this.busesButton6.Location = new System.Drawing.Point(176, 161);
            this.busesButton6.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.busesButton6.Name = "busesButton6";
            this.busesButton6.Size = new System.Drawing.Size(71, 27);
            this.busesButton6.TabIndex = 19;
            this.busesButton6.Text = "Limpiar";
            this.busesButton6.UseVisualStyleBackColor = true;
            this.busesButton6.Click += new System.EventHandler(this.busesButton6_Click);
            // 
            // busesButton5
            // 
            this.busesButton5.Location = new System.Drawing.Point(3, 161);
            this.busesButton5.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.busesButton5.Name = "busesButton5";
            this.busesButton5.Size = new System.Drawing.Size(71, 27);
            this.busesButton5.TabIndex = 18;
            this.busesButton5.Text = "Aplicar";
            this.busesButton5.UseVisualStyleBackColor = true;
            this.busesButton5.Click += new System.EventHandler(this.busesButton5_Click);
            // 
            // busesLabel2
            // 
            this.busesLabel2.AutoSize = true;
            this.busesLabel2.Location = new System.Drawing.Point(0, 66);
            this.busesLabel2.Name = "busesLabel2";
            this.busesLabel2.Size = new System.Drawing.Size(37, 13);
            this.busesLabel2.TabIndex = 11;
            this.busesLabel2.Text = "Marca";
            // 
            // busesText2
            // 
            this.busesText2.Location = new System.Drawing.Point(0, 82);
            this.busesText2.Name = "busesText2";
            this.busesText2.Size = new System.Drawing.Size(240, 20);
            this.busesText2.TabIndex = 10;
            // 
            // busesLabel1
            // 
            this.busesLabel1.AutoSize = true;
            this.busesLabel1.Location = new System.Drawing.Point(0, 17);
            this.busesLabel1.Name = "busesLabel1";
            this.busesLabel1.Size = new System.Drawing.Size(44, 13);
            this.busesLabel1.TabIndex = 9;
            this.busesLabel1.Text = "Patente";
            // 
            // busesText1
            // 
            this.busesText1.Location = new System.Drawing.Point(0, 33);
            this.busesText1.Name = "busesText1";
            this.busesText1.Size = new System.Drawing.Size(240, 20);
            this.busesText1.TabIndex = 7;
            // 
            // busesButton4
            // 
            this.busesButton4.Location = new System.Drawing.Point(157, 298);
            this.busesButton4.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.busesButton4.Name = "busesButton4";
            this.busesButton4.Size = new System.Drawing.Size(71, 27);
            this.busesButton4.TabIndex = 28;
            this.busesButton4.Text = "Baja";
            this.busesButton4.UseVisualStyleBackColor = true;
            this.busesButton4.Click += new System.EventHandler(this.busesButton4_Click);
            // 
            // busesButton3
            // 
            this.busesButton3.Location = new System.Drawing.Point(82, 298);
            this.busesButton3.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.busesButton3.Name = "busesButton3";
            this.busesButton3.Size = new System.Drawing.Size(71, 27);
            this.busesButton3.TabIndex = 27;
            this.busesButton3.Text = "Modificar";
            this.busesButton3.UseVisualStyleBackColor = true;
            this.busesButton3.Click += new System.EventHandler(this.busesButton3_Click);
            // 
            // busesButton2
            // 
            this.busesButton2.Location = new System.Drawing.Point(7, 298);
            this.busesButton2.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.busesButton2.Name = "busesButton2";
            this.busesButton2.Size = new System.Drawing.Size(71, 27);
            this.busesButton2.TabIndex = 26;
            this.busesButton2.Text = "Alta";
            this.busesButton2.UseVisualStyleBackColor = true;
            this.busesButton2.Click += new System.EventHandler(this.busesButton2_Click);
            // 
            // grillaBuses
            // 
            this.grillaBuses.BackgroundColor = System.Drawing.SystemColors.InactiveCaption;
            this.grillaBuses.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Sunken;
            this.grillaBuses.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            this.grillaBuses.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grillaBuses.Cursor = System.Windows.Forms.Cursors.Default;
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle13.BackColor = System.Drawing.SystemColors.InactiveCaption;
            dataGridViewCellStyle13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle13.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle13.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle13.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.grillaBuses.DefaultCellStyle = dataGridViewCellStyle13;
            this.grillaBuses.GridColor = System.Drawing.SystemColors.ActiveCaption;
            this.grillaBuses.Location = new System.Drawing.Point(7, 3);
            this.grillaBuses.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.grillaBuses.Name = "grillaBuses";
            this.grillaBuses.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle14.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle14.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grillaBuses.RowHeadersDefaultCellStyle = dataGridViewCellStyle14;
            this.grillaBuses.RowHeadersWidth = 51;
            this.grillaBuses.RowTemplate.Height = 24;
            this.grillaBuses.Size = new System.Drawing.Size(521, 289);
            this.grillaBuses.TabIndex = 24;
            // 
            // Principal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSteelBlue;
            this.ClientSize = new System.Drawing.Size(1156, 457);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.Name = "Principal";
            this.Text = "Principal";
            this.Load += new System.EventHandler(this.Principal_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPagePasajes.ResumeLayout(false);
            this.tabPagePasajes.PerformLayout();
            this.pasajesPrincipalGroupBox2.ResumeLayout(false);
            this.pasajesPrincipalGroupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pasajesPrincipalDataGridViajes)).EndInit();
            this.pasajesPrincipalGroupBox1.ResumeLayout(false);
            this.pasajesPrincipalGroupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pasajesPrincipalDataGridClientes)).EndInit();
            this.tabPageClientes.ResumeLayout(false);
            this.ClientesGroupBox1.ResumeLayout(false);
            this.ClientesGroupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grillaClientes)).EndInit();
            this.tabPageViajes.ResumeLayout(false);
            this.ViajePrincipalGroupBox1.ResumeLayout(false);
            this.ViajePrincipalGroupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ViajesPrincipalDataGrid)).EndInit();
            this.tabPageRutas.ResumeLayout(false);
            this.RutasGroupBox.ResumeLayout(false);
            this.RutasGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridRutas)).EndInit();
            this.tabPageLocalidades.ResumeLayout(false);
            this.LocalidadGroupBox.ResumeLayout(false);
            this.LocalidadGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grillaLocalidad)).EndInit();
            this.tabPageBuses.ResumeLayout(false);
            this.busesGroupBox1.ResumeLayout(false);
            this.busesGroupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grillaBuses)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem sesionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem administracionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cerrarSesionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cambiarIdiomaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bitacoraToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gestionarUsuariosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gestionarPermisosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem copiaDeSeguridadToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem restauracionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cambiarContraseñaToolStripMenuItem;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPagePasajes;
        private System.Windows.Forms.TabPage tabPageClientes;
        private System.Windows.Forms.TabPage tabPageViajes;
        private System.Windows.Forms.TabPage tabPageRutas;
        private System.Windows.Forms.TabPage tabPageLocalidades;
        private System.Windows.Forms.GroupBox LocalidadGroupBox;
        private System.Windows.Forms.Button LocalidadBotton6;
        private System.Windows.Forms.Button LocalidadBotton5;
        private System.Windows.Forms.Label LocalidadLabel2;
        private System.Windows.Forms.TextBox LocalidadPrincipalText2;
        private System.Windows.Forms.Label LocalidadLabel1;
        private System.Windows.Forms.TextBox LocalidadPrincipalText1;
        private System.Windows.Forms.Button LocalidadBotton4;
        private System.Windows.Forms.Button LocalidadBotton3;
        private System.Windows.Forms.Button LocalidadBotton2;
        private System.Windows.Forms.DataGridView grillaLocalidad;
        private System.Windows.Forms.Label LocalidadLabel3;
        private System.Windows.Forms.TextBox LocalidadPrincipalText3;
        private System.Windows.Forms.TabPage tabPageBuses;
        private System.Windows.Forms.GroupBox busesGroupBox1;
        private System.Windows.Forms.Label busesLabel3;
        private System.Windows.Forms.TextBox busesText3;
        private System.Windows.Forms.Button busesButton6;
        private System.Windows.Forms.Button busesButton5;
        private System.Windows.Forms.Label busesLabel2;
        private System.Windows.Forms.TextBox busesText2;
        private System.Windows.Forms.Label busesLabel1;
        private System.Windows.Forms.TextBox busesText1;
        private System.Windows.Forms.Button busesButton4;
        private System.Windows.Forms.Button busesButton3;
        private System.Windows.Forms.Button busesButton2;
        private System.Windows.Forms.DataGridView grillaBuses;
        private System.Windows.Forms.GroupBox ClientesGroupBox1;
        private System.Windows.Forms.Label ClientesLabel4;
        private System.Windows.Forms.TextBox ClientesTextBox4;
        private System.Windows.Forms.Label ClientesLabel3;
        private System.Windows.Forms.TextBox ClientesTextBox3;
        private System.Windows.Forms.Button ClientesBotton6;
        private System.Windows.Forms.Button ClientesBotton5;
        private System.Windows.Forms.Label ClientesLabel2;
        private System.Windows.Forms.TextBox ClientesTextBox2;
        private System.Windows.Forms.Label ClientesLabel1;
        private System.Windows.Forms.TextBox ClientesTextBox1;
        private System.Windows.Forms.Button ClientesBotton4;
        private System.Windows.Forms.Button ClientesBotton3;
        private System.Windows.Forms.Button ClientesBotton2;
        private System.Windows.Forms.DataGridView grillaClientes;
        private System.Windows.Forms.GroupBox RutasGroupBox;
        private System.Windows.Forms.Label RutaLabel2;
        private System.Windows.Forms.TextBox RutasPrincipalText3;
        private System.Windows.Forms.Button RutasButton6;
        private System.Windows.Forms.Button RutasButton5;
        private System.Windows.Forms.Label RutaLabel1;
        private System.Windows.Forms.TextBox RutasPrincipalText2;
        private System.Windows.Forms.Button RutasButton4;
        private System.Windows.Forms.Button RutasButton3;
        private System.Windows.Forms.Button RutasButton2;
        private System.Windows.Forms.DataGridView dataGridRutas;
        private System.Windows.Forms.GroupBox ViajePrincipalGroupBox1;
        private System.Windows.Forms.Button ViajesPrincipalButton6;
        private System.Windows.Forms.Button ViajesPrincipalButton5;
        private System.Windows.Forms.Label ViajePrincipalLabel2;
        private System.Windows.Forms.TextBox ViajesPrincipalText2;
        private System.Windows.Forms.Label ViajePrincipalLabel1;
        private System.Windows.Forms.TextBox ViajesPrincipalText1;
        private System.Windows.Forms.Button ViajesPrincipalButton4;
        private System.Windows.Forms.Button ViajesPrincipalButton3;
        private System.Windows.Forms.Button ViajesPrincipalButton2;
        private System.Windows.Forms.Button ViajesPrincipalButton1;
        private System.Windows.Forms.DataGridView ViajesPrincipalDataGrid;
        private System.Windows.Forms.DateTimePicker ViajeDatePickerHastaHora;
        private System.Windows.Forms.DateTimePicker ViajeDatePickerDesdeHora;
        private System.Windows.Forms.Label ViajePrincipalLabel4;
        private System.Windows.Forms.Label ViajePrincipalLabel3;
        private System.Windows.Forms.DateTimePicker ViajeDatePickerHasta;
        private System.Windows.Forms.DateTimePicker ViajeDatePickerDesde;
        private System.Windows.Forms.CheckBox ViajesPrincipalCheckBox;
        private System.Windows.Forms.Button pasajesPrincipalButton5;
        private System.Windows.Forms.Button pasajesPrincipalButton4;
        private System.Windows.Forms.DataGridView pasajesPrincipalDataGridClientes;
        private System.Windows.Forms.BindingSource bindingSource1;
        private System.Windows.Forms.TextBox pasajesPrincipalTextBox5;
        private System.Windows.Forms.TextBox pasajesPrincipalTextBox4;
        private System.Windows.Forms.TextBox pasajesPrincipalTextBox3;
        private System.Windows.Forms.TextBox pasajesPrincipalTextBox2;
        private System.Windows.Forms.DataGridView pasajesPrincipalDataGridViajes;
        private System.Windows.Forms.TextBox pasajesPrincipalTextBox1;
        private System.Windows.Forms.Label pasajesPrincipalLabel6;
        private System.Windows.Forms.Label pasajesPrincipalLabel7;
        private System.Windows.Forms.DateTimePicker pasajeDateTimePicker2;
        private System.Windows.Forms.DateTimePicker pasajeDateTimePicker1;
        private System.Windows.Forms.Button pasajesPrincipalButton1;
        private System.Windows.Forms.Label pasajesPrincipalLabel3;
        private System.Windows.Forms.Label pasajesPrincipalLabel2;
        private System.Windows.Forms.Label pasajesPrincipalLabel1;
        private System.Windows.Forms.Label pasajesPrincipalLabel4;
        private System.Windows.Forms.Label pasajesPrincipalLabel5;
        private System.Windows.Forms.GroupBox pasajesPrincipalGroupBox2;
        private System.Windows.Forms.Button pasajesPrincipalButton2;
        private System.Windows.Forms.GroupBox pasajesPrincipalGroupBox1;
        private System.Windows.Forms.TextBox pasajesPrincipalTextBox6;
        private System.Windows.Forms.Label pasajesPrincipalLabel8;
        private System.Windows.Forms.Button pasajesPrincipalButton3;
        private System.Windows.Forms.Button busesButton7;
        private System.Windows.Forms.Button ViajesPrincipalButton7;
    }
}