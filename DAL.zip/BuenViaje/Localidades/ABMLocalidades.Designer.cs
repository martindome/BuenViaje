﻿namespace BuenViaje.Localidades
{
    partial class ABMLocalidades
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ABMLocalidadesTexto3 = new System.Windows.Forms.TextBox();
            this.ABMLocalidadesLabel3 = new System.Windows.Forms.Label();
            this.ABMLocalidadesTexto2 = new System.Windows.Forms.TextBox();
            this.ABMLocalidadesTexto1 = new System.Windows.Forms.TextBox();
            this.ABMLocalidadesLabel2 = new System.Windows.Forms.Label();
            this.ABMLocalidadesLabel1 = new System.Windows.Forms.Label();
            this.ABMLocalidadesBotton2 = new System.Windows.Forms.Button();
            this.ABMLocalidadesBotton1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // ABMLocalidadesTexto3
            // 
            this.ABMLocalidadesTexto3.Location = new System.Drawing.Point(25, 106);
            this.ABMLocalidadesTexto3.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.ABMLocalidadesTexto3.Name = "ABMLocalidadesTexto3";
            this.ABMLocalidadesTexto3.Size = new System.Drawing.Size(212, 20);
            this.ABMLocalidadesTexto3.TabIndex = 22;
            this.ABMLocalidadesTexto3.TextChanged += new System.EventHandler(this.ABMLocalidadesTexto3_TextChanged);
            // 
            // ABMLocalidadesLabel3
            // 
            this.ABMLocalidadesLabel3.AutoSize = true;
            this.ABMLocalidadesLabel3.Location = new System.Drawing.Point(22, 90);
            this.ABMLocalidadesLabel3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.ABMLocalidadesLabel3.Name = "ABMLocalidadesLabel3";
            this.ABMLocalidadesLabel3.Size = new System.Drawing.Size(27, 13);
            this.ABMLocalidadesLabel3.TabIndex = 21;
            this.ABMLocalidadesLabel3.Text = "Pais";
            // 
            // ABMLocalidadesTexto2
            // 
            this.ABMLocalidadesTexto2.Location = new System.Drawing.Point(25, 67);
            this.ABMLocalidadesTexto2.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.ABMLocalidadesTexto2.Name = "ABMLocalidadesTexto2";
            this.ABMLocalidadesTexto2.Size = new System.Drawing.Size(212, 20);
            this.ABMLocalidadesTexto2.TabIndex = 16;
            this.ABMLocalidadesTexto2.TextChanged += new System.EventHandler(this.ABMLocalidadesTexto2_TextChanged);
            // 
            // ABMLocalidadesTexto1
            // 
            this.ABMLocalidadesTexto1.Location = new System.Drawing.Point(25, 28);
            this.ABMLocalidadesTexto1.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.ABMLocalidadesTexto1.Name = "ABMLocalidadesTexto1";
            this.ABMLocalidadesTexto1.Size = new System.Drawing.Size(212, 20);
            this.ABMLocalidadesTexto1.TabIndex = 15;
            this.ABMLocalidadesTexto1.TextChanged += new System.EventHandler(this.ABMLocalidadesTexto1_TextChanged);
            // 
            // ABMLocalidadesLabel2
            // 
            this.ABMLocalidadesLabel2.AutoSize = true;
            this.ABMLocalidadesLabel2.Location = new System.Drawing.Point(22, 51);
            this.ABMLocalidadesLabel2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.ABMLocalidadesLabel2.Name = "ABMLocalidadesLabel2";
            this.ABMLocalidadesLabel2.Size = new System.Drawing.Size(51, 13);
            this.ABMLocalidadesLabel2.TabIndex = 14;
            this.ABMLocalidadesLabel2.Text = "Provincia";
            // 
            // ABMLocalidadesLabel1
            // 
            this.ABMLocalidadesLabel1.AutoSize = true;
            this.ABMLocalidadesLabel1.Location = new System.Drawing.Point(22, 12);
            this.ABMLocalidadesLabel1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.ABMLocalidadesLabel1.Name = "ABMLocalidadesLabel1";
            this.ABMLocalidadesLabel1.Size = new System.Drawing.Size(44, 13);
            this.ABMLocalidadesLabel1.TabIndex = 23;
            this.ABMLocalidadesLabel1.Text = "Nombre";
            // 
            // ABMLocalidadesBotton2
            // 
            this.ABMLocalidadesBotton2.Location = new System.Drawing.Point(171, 131);
            this.ABMLocalidadesBotton2.Margin = new System.Windows.Forms.Padding(2);
            this.ABMLocalidadesBotton2.Name = "ABMLocalidadesBotton2";
            this.ABMLocalidadesBotton2.Size = new System.Drawing.Size(66, 21);
            this.ABMLocalidadesBotton2.TabIndex = 24;
            this.ABMLocalidadesBotton2.Text = "Cancelar";
            this.ABMLocalidadesBotton2.UseVisualStyleBackColor = true;
            this.ABMLocalidadesBotton2.Click += new System.EventHandler(this.ABMLocalidadesBotton2_Click);
            // 
            // ABMLocalidadesBotton1
            // 
            this.ABMLocalidadesBotton1.Location = new System.Drawing.Point(25, 131);
            this.ABMLocalidadesBotton1.Margin = new System.Windows.Forms.Padding(2);
            this.ABMLocalidadesBotton1.Name = "ABMLocalidadesBotton1";
            this.ABMLocalidadesBotton1.Size = new System.Drawing.Size(66, 21);
            this.ABMLocalidadesBotton1.TabIndex = 25;
            this.ABMLocalidadesBotton1.Text = "Aplicar";
            this.ABMLocalidadesBotton1.UseVisualStyleBackColor = true;
            this.ABMLocalidadesBotton1.Click += new System.EventHandler(this.ABMLocalidadesBotton1_Click);
            // 
            // ABMLocalidades
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(281, 176);
            this.Controls.Add(this.ABMLocalidadesBotton2);
            this.Controls.Add(this.ABMLocalidadesBotton1);
            this.Controls.Add(this.ABMLocalidadesLabel1);
            this.Controls.Add(this.ABMLocalidadesTexto3);
            this.Controls.Add(this.ABMLocalidadesLabel3);
            this.Controls.Add(this.ABMLocalidadesTexto2);
            this.Controls.Add(this.ABMLocalidadesTexto1);
            this.Controls.Add(this.ABMLocalidadesLabel2);
            this.Name = "ABMLocalidades";
            this.Text = "ABMLocalidades";
            this.Load += new System.EventHandler(this.ABMLocalidades_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox ABMLocalidadesTexto3;
        private System.Windows.Forms.Label ABMLocalidadesLabel3;
        private System.Windows.Forms.TextBox ABMLocalidadesTexto2;
        private System.Windows.Forms.TextBox ABMLocalidadesTexto1;
        private System.Windows.Forms.Label ABMLocalidadesLabel2;
        private System.Windows.Forms.Label ABMLocalidadesLabel1;
        private System.Windows.Forms.Button ABMLocalidadesBotton2;
        private System.Windows.Forms.Button ABMLocalidadesBotton1;
    }
}