﻿namespace BuenViaje.Sesion
{
    partial class CambiarContraseña
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CambiarContraseniaTextBox1 = new System.Windows.Forms.TextBox();
            this.CambiarContraseniaLabel1 = new System.Windows.Forms.Label();
            this.CambiarContraseniaLabel2 = new System.Windows.Forms.Label();
            this.CambiarContraseniaTextBox2 = new System.Windows.Forms.TextBox();
            this.CambiarContraseniaLabel3 = new System.Windows.Forms.Label();
            this.CambiarContraseniaTextBox3 = new System.Windows.Forms.TextBox();
            this.CambiarContraseniaButton1 = new System.Windows.Forms.Button();
            this.CambiarContraseniaButton2 = new System.Windows.Forms.Button();
            this.CambiarContraseniaLabel4 = new System.Windows.Forms.Label();
            this.CambiarContraseniaLabel7 = new System.Windows.Forms.Label();
            this.CambiarContraseniaLabel6 = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // CambiarContraseniaTextBox1
            // 
            this.CambiarContraseniaTextBox1.Location = new System.Drawing.Point(12, 30);
            this.CambiarContraseniaTextBox1.Name = "CambiarContraseniaTextBox1";
            this.CambiarContraseniaTextBox1.PasswordChar = '*';
            this.CambiarContraseniaTextBox1.Size = new System.Drawing.Size(212, 20);
            this.CambiarContraseniaTextBox1.TabIndex = 0;
            this.CambiarContraseniaTextBox1.TextChanged += new System.EventHandler(this.CambiarContraseniaTextBox1_TextChanged);
            // 
            // CambiarContraseniaLabel1
            // 
            this.CambiarContraseniaLabel1.AutoSize = true;
            this.CambiarContraseniaLabel1.Location = new System.Drawing.Point(9, 14);
            this.CambiarContraseniaLabel1.Name = "CambiarContraseniaLabel1";
            this.CambiarContraseniaLabel1.Size = new System.Drawing.Size(100, 13);
            this.CambiarContraseniaLabel1.TabIndex = 2;
            this.CambiarContraseniaLabel1.Text = "Contraseña Actual: ";
            // 
            // CambiarContraseniaLabel2
            // 
            this.CambiarContraseniaLabel2.AutoSize = true;
            this.CambiarContraseniaLabel2.Location = new System.Drawing.Point(9, 53);
            this.CambiarContraseniaLabel2.Name = "CambiarContraseniaLabel2";
            this.CambiarContraseniaLabel2.Size = new System.Drawing.Size(102, 13);
            this.CambiarContraseniaLabel2.TabIndex = 4;
            this.CambiarContraseniaLabel2.Text = "Nueva Contraseña: ";
            // 
            // CambiarContraseniaTextBox2
            // 
            this.CambiarContraseniaTextBox2.Location = new System.Drawing.Point(12, 72);
            this.CambiarContraseniaTextBox2.Name = "CambiarContraseniaTextBox2";
            this.CambiarContraseniaTextBox2.PasswordChar = '*';
            this.CambiarContraseniaTextBox2.Size = new System.Drawing.Size(212, 20);
            this.CambiarContraseniaTextBox2.TabIndex = 3;
            this.CambiarContraseniaTextBox2.TextChanged += new System.EventHandler(this.CambiarContraseniaTextBox2_TextChanged);
            // 
            // CambiarContraseniaLabel3
            // 
            this.CambiarContraseniaLabel3.AutoSize = true;
            this.CambiarContraseniaLabel3.Location = new System.Drawing.Point(12, 95);
            this.CambiarContraseniaLabel3.Name = "CambiarContraseniaLabel3";
            this.CambiarContraseniaLabel3.Size = new System.Drawing.Size(114, 13);
            this.CambiarContraseniaLabel3.TabIndex = 6;
            this.CambiarContraseniaLabel3.Text = "Confirmar Contraseña: ";
            // 
            // CambiarContraseniaTextBox3
            // 
            this.CambiarContraseniaTextBox3.Location = new System.Drawing.Point(12, 111);
            this.CambiarContraseniaTextBox3.Name = "CambiarContraseniaTextBox3";
            this.CambiarContraseniaTextBox3.PasswordChar = '*';
            this.CambiarContraseniaTextBox3.Size = new System.Drawing.Size(212, 20);
            this.CambiarContraseniaTextBox3.TabIndex = 5;
            this.CambiarContraseniaTextBox3.TextChanged += new System.EventHandler(this.CambiarContraseniaTextBox3_TextChanged);
            // 
            // CambiarContraseniaButton1
            // 
            this.CambiarContraseniaButton1.Location = new System.Drawing.Point(12, 137);
            this.CambiarContraseniaButton1.Name = "CambiarContraseniaButton1";
            this.CambiarContraseniaButton1.Size = new System.Drawing.Size(75, 23);
            this.CambiarContraseniaButton1.TabIndex = 7;
            this.CambiarContraseniaButton1.Text = "Confirmar";
            this.CambiarContraseniaButton1.UseVisualStyleBackColor = true;
            this.CambiarContraseniaButton1.Click += new System.EventHandler(this.CambiarContraseniaButton1_Click);
            // 
            // CambiarContraseniaButton2
            // 
            this.CambiarContraseniaButton2.Location = new System.Drawing.Point(93, 137);
            this.CambiarContraseniaButton2.Name = "CambiarContraseniaButton2";
            this.CambiarContraseniaButton2.Size = new System.Drawing.Size(75, 23);
            this.CambiarContraseniaButton2.TabIndex = 8;
            this.CambiarContraseniaButton2.Text = "Cancelar";
            this.CambiarContraseniaButton2.UseVisualStyleBackColor = true;
            this.CambiarContraseniaButton2.Click += new System.EventHandler(this.CambiarContraseniaButton2_Click);
            // 
            // CambiarContraseniaLabel4
            // 
            this.CambiarContraseniaLabel4.AutoSize = true;
            this.CambiarContraseniaLabel4.ForeColor = System.Drawing.Color.Red;
            this.CambiarContraseniaLabel4.Location = new System.Drawing.Point(17, 228);
            this.CambiarContraseniaLabel4.Name = "CambiarContraseniaLabel4";
            this.CambiarContraseniaLabel4.Size = new System.Drawing.Size(149, 13);
            this.CambiarContraseniaLabel4.TabIndex = 9;
            this.CambiarContraseniaLabel4.Text = "Las contraseñas no coinciden";
            // 
            // CambiarContraseniaLabel7
            // 
            this.CambiarContraseniaLabel7.AutoSize = true;
            this.CambiarContraseniaLabel7.ForeColor = System.Drawing.Color.Red;
            this.CambiarContraseniaLabel7.Location = new System.Drawing.Point(17, 215);
            this.CambiarContraseniaLabel7.Name = "CambiarContraseniaLabel7";
            this.CambiarContraseniaLabel7.Size = new System.Drawing.Size(35, 13);
            this.CambiarContraseniaLabel7.TabIndex = 12;
            this.CambiarContraseniaLabel7.Text = "label1";
            // 
            // CambiarContraseniaLabel6
            // 
            this.CambiarContraseniaLabel6.Location = new System.Drawing.Point(12, 166);
            this.CambiarContraseniaLabel6.Name = "CambiarContraseniaLabel6";
            this.CambiarContraseniaLabel6.Size = new System.Drawing.Size(212, 46);
            this.CambiarContraseniaLabel6.TabIndex = 13;
            this.CambiarContraseniaLabel6.Text = "";
            // 
            // CambiarContraseña
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(236, 278);
            this.Controls.Add(this.CambiarContraseniaLabel6);
            this.Controls.Add(this.CambiarContraseniaLabel7);
            this.Controls.Add(this.CambiarContraseniaLabel4);
            this.Controls.Add(this.CambiarContraseniaButton2);
            this.Controls.Add(this.CambiarContraseniaButton1);
            this.Controls.Add(this.CambiarContraseniaLabel3);
            this.Controls.Add(this.CambiarContraseniaTextBox3);
            this.Controls.Add(this.CambiarContraseniaLabel2);
            this.Controls.Add(this.CambiarContraseniaTextBox2);
            this.Controls.Add(this.CambiarContraseniaLabel1);
            this.Controls.Add(this.CambiarContraseniaTextBox1);
            this.Name = "CambiarContraseña";
            this.Text = "CambiarContraseña";
            this.Load += new System.EventHandler(this.CambiarContraseña_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox CambiarContraseniaTextBox1;
        private System.Windows.Forms.Label CambiarContraseniaLabel1;
        private System.Windows.Forms.Label CambiarContraseniaLabel2;
        private System.Windows.Forms.TextBox CambiarContraseniaTextBox2;
        private System.Windows.Forms.Label CambiarContraseniaLabel3;
        private System.Windows.Forms.TextBox CambiarContraseniaTextBox3;
        private System.Windows.Forms.Button CambiarContraseniaButton1;
        private System.Windows.Forms.Button CambiarContraseniaButton2;
        private System.Windows.Forms.Label CambiarContraseniaLabel4;
        private System.Windows.Forms.Label CambiarContraseniaLabel7;
        private System.Windows.Forms.RichTextBox CambiarContraseniaLabel6;
    }
}