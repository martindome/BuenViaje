﻿namespace BuenViaje.Administracion.Usuarios
{
    partial class ABMUsuarios
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            this.ABMUsuarioGroupboxUsuario = new System.Windows.Forms.GroupBox();
            this.ABMUsuariosTextoUsuario = new System.Windows.Forms.TextBox();
            this.ABMUsuariosLabel3 = new System.Windows.Forms.Label();
            this.ABMUsuariosComboIdioma = new System.Windows.Forms.ComboBox();
            this.ABMUsuariosLabel5 = new System.Windows.Forms.Label();
            this.ABMUsuariosLabel4 = new System.Windows.Forms.Label();
            this.ABMUsuariosTextoClave = new System.Windows.Forms.TextBox();
            this.ABMUsuariosTextoApellido = new System.Windows.Forms.TextBox();
            this.ABMUsuariosTextoNombre = new System.Windows.Forms.TextBox();
            this.ABMUsuariosLabel2 = new System.Windows.Forms.Label();
            this.ABMUsuariosLabel1 = new System.Windows.Forms.Label();
            this.ABMUsuarioGroupboxPermisos = new System.Windows.Forms.GroupBox();
            this.ABMUsuarioGroupboxPatentes = new System.Windows.Forms.GroupBox();
            this.ABMUsuariosLabel9 = new System.Windows.Forms.Label();
            this.ABMUsuariosLabel8 = new System.Windows.Forms.Label();
            this.ABMUsuariosGrillaPatente2 = new System.Windows.Forms.DataGridView();
            this.ABMUsuariosBotton6 = new System.Windows.Forms.Button();
            this.ABMUsuariosBotton5 = new System.Windows.Forms.Button();
            this.ABMUsuariosGrillaPatente1 = new System.Windows.Forms.DataGridView();
            this.ABMUsuarioGroupboxFamilia = new System.Windows.Forms.GroupBox();
            this.ABMUsuariosLabel7 = new System.Windows.Forms.Label();
            this.ABMUsuariosLabel6 = new System.Windows.Forms.Label();
            this.ABMUsuariosGrillaFamilia2 = new System.Windows.Forms.DataGridView();
            this.ABMUsuariosBotton4 = new System.Windows.Forms.Button();
            this.ABMUsuariosBotton3 = new System.Windows.Forms.Button();
            this.ABMUsuariosGrillaFamilia1 = new System.Windows.Forms.DataGridView();
            this.ABMUsuariosBotton1 = new System.Windows.Forms.Button();
            this.ABMUsuariosBotton2 = new System.Windows.Forms.Button();
            this.ABMUsuarioGroupboxUsuario.SuspendLayout();
            this.ABMUsuarioGroupboxPermisos.SuspendLayout();
            this.ABMUsuarioGroupboxPatentes.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ABMUsuariosGrillaPatente2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ABMUsuariosGrillaPatente1)).BeginInit();
            this.ABMUsuarioGroupboxFamilia.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ABMUsuariosGrillaFamilia2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ABMUsuariosGrillaFamilia1)).BeginInit();
            this.SuspendLayout();
            // 
            // ABMUsuarioGroupboxUsuario
            // 
            this.ABMUsuarioGroupboxUsuario.Controls.Add(this.ABMUsuariosTextoUsuario);
            this.ABMUsuarioGroupboxUsuario.Controls.Add(this.ABMUsuariosLabel3);
            this.ABMUsuarioGroupboxUsuario.Controls.Add(this.ABMUsuariosComboIdioma);
            this.ABMUsuarioGroupboxUsuario.Controls.Add(this.ABMUsuariosLabel5);
            this.ABMUsuarioGroupboxUsuario.Controls.Add(this.ABMUsuariosLabel4);
            this.ABMUsuarioGroupboxUsuario.Controls.Add(this.ABMUsuariosTextoClave);
            this.ABMUsuarioGroupboxUsuario.Controls.Add(this.ABMUsuariosTextoApellido);
            this.ABMUsuarioGroupboxUsuario.Controls.Add(this.ABMUsuariosTextoNombre);
            this.ABMUsuarioGroupboxUsuario.Controls.Add(this.ABMUsuariosLabel2);
            this.ABMUsuarioGroupboxUsuario.Controls.Add(this.ABMUsuariosLabel1);
            this.ABMUsuarioGroupboxUsuario.Location = new System.Drawing.Point(11, 12);
            this.ABMUsuarioGroupboxUsuario.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.ABMUsuarioGroupboxUsuario.Name = "ABMUsuarioGroupboxUsuario";
            this.ABMUsuarioGroupboxUsuario.Padding = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.ABMUsuarioGroupboxUsuario.Size = new System.Drawing.Size(239, 244);
            this.ABMUsuarioGroupboxUsuario.TabIndex = 1;
            this.ABMUsuarioGroupboxUsuario.TabStop = false;
            this.ABMUsuarioGroupboxUsuario.Text = "Usuario";
            // 
            // ABMUsuariosTextoUsuario
            // 
            this.ABMUsuariosTextoUsuario.Location = new System.Drawing.Point(12, 110);
            this.ABMUsuariosTextoUsuario.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.ABMUsuariosTextoUsuario.Name = "ABMUsuariosTextoUsuario";
            this.ABMUsuariosTextoUsuario.Size = new System.Drawing.Size(212, 20);
            this.ABMUsuariosTextoUsuario.TabIndex = 13;
            this.ABMUsuariosTextoUsuario.TextChanged += new System.EventHandler(this.ABMUsuariosTextoUsuario_TextChanged);
            // 
            // ABMUsuariosLabel3
            // 
            this.ABMUsuariosLabel3.AutoSize = true;
            this.ABMUsuariosLabel3.Location = new System.Drawing.Point(9, 94);
            this.ABMUsuariosLabel3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.ABMUsuariosLabel3.Name = "ABMUsuariosLabel3";
            this.ABMUsuariosLabel3.Size = new System.Drawing.Size(43, 13);
            this.ABMUsuariosLabel3.TabIndex = 12;
            this.ABMUsuariosLabel3.Text = "Usuario";
            // 
            // ABMUsuariosComboIdioma
            // 
            this.ABMUsuariosComboIdioma.FormattingEnabled = true;
            this.ABMUsuariosComboIdioma.Location = new System.Drawing.Point(12, 187);
            this.ABMUsuariosComboIdioma.Margin = new System.Windows.Forms.Padding(2);
            this.ABMUsuariosComboIdioma.Name = "ABMUsuariosComboIdioma";
            this.ABMUsuariosComboIdioma.Size = new System.Drawing.Size(212, 21);
            this.ABMUsuariosComboIdioma.TabIndex = 11;
            this.ABMUsuariosComboIdioma.SelectedIndexChanged += new System.EventHandler(this.ABMUsuariosComboIdioma_SelectedIndexChanged);
            // 
            // ABMUsuariosLabel5
            // 
            this.ABMUsuariosLabel5.AutoSize = true;
            this.ABMUsuariosLabel5.Location = new System.Drawing.Point(9, 172);
            this.ABMUsuariosLabel5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.ABMUsuariosLabel5.Name = "ABMUsuariosLabel5";
            this.ABMUsuariosLabel5.Size = new System.Drawing.Size(38, 13);
            this.ABMUsuariosLabel5.TabIndex = 10;
            this.ABMUsuariosLabel5.Text = "Idioma";
            // 
            // ABMUsuariosLabel4
            // 
            this.ABMUsuariosLabel4.AutoSize = true;
            this.ABMUsuariosLabel4.Location = new System.Drawing.Point(9, 133);
            this.ABMUsuariosLabel4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.ABMUsuariosLabel4.Name = "ABMUsuariosLabel4";
            this.ABMUsuariosLabel4.Size = new System.Drawing.Size(61, 13);
            this.ABMUsuariosLabel4.TabIndex = 8;
            this.ABMUsuariosLabel4.Text = "Contraseña";
            // 
            // ABMUsuariosTextoClave
            // 
            this.ABMUsuariosTextoClave.Location = new System.Drawing.Point(12, 149);
            this.ABMUsuariosTextoClave.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.ABMUsuariosTextoClave.Name = "ABMUsuariosTextoClave";
            this.ABMUsuariosTextoClave.PasswordChar = '*';
            this.ABMUsuariosTextoClave.Size = new System.Drawing.Size(212, 20);
            this.ABMUsuariosTextoClave.TabIndex = 7;
            this.ABMUsuariosTextoClave.TextChanged += new System.EventHandler(this.ABMUsuariosTextoClave_TextChanged);
            // 
            // ABMUsuariosTextoApellido
            // 
            this.ABMUsuariosTextoApellido.Location = new System.Drawing.Point(12, 71);
            this.ABMUsuariosTextoApellido.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.ABMUsuariosTextoApellido.Name = "ABMUsuariosTextoApellido";
            this.ABMUsuariosTextoApellido.Size = new System.Drawing.Size(212, 20);
            this.ABMUsuariosTextoApellido.TabIndex = 5;
            this.ABMUsuariosTextoApellido.TextChanged += new System.EventHandler(this.ABMUsuariosTextoApellido_TextChanged);
            // 
            // ABMUsuariosTextoNombre
            // 
            this.ABMUsuariosTextoNombre.Location = new System.Drawing.Point(12, 32);
            this.ABMUsuariosTextoNombre.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.ABMUsuariosTextoNombre.Name = "ABMUsuariosTextoNombre";
            this.ABMUsuariosTextoNombre.Size = new System.Drawing.Size(212, 20);
            this.ABMUsuariosTextoNombre.TabIndex = 4;
            this.ABMUsuariosTextoNombre.TextChanged += new System.EventHandler(this.ABMUsuariosTextoNombre_TextChanged);
            // 
            // ABMUsuariosLabel2
            // 
            this.ABMUsuariosLabel2.AutoSize = true;
            this.ABMUsuariosLabel2.Location = new System.Drawing.Point(9, 55);
            this.ABMUsuariosLabel2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.ABMUsuariosLabel2.Name = "ABMUsuariosLabel2";
            this.ABMUsuariosLabel2.Size = new System.Drawing.Size(44, 13);
            this.ABMUsuariosLabel2.TabIndex = 1;
            this.ABMUsuariosLabel2.Text = "Apellido";
            // 
            // ABMUsuariosLabel1
            // 
            this.ABMUsuariosLabel1.AutoSize = true;
            this.ABMUsuariosLabel1.Location = new System.Drawing.Point(9, 16);
            this.ABMUsuariosLabel1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.ABMUsuariosLabel1.Name = "ABMUsuariosLabel1";
            this.ABMUsuariosLabel1.Size = new System.Drawing.Size(44, 13);
            this.ABMUsuariosLabel1.TabIndex = 0;
            this.ABMUsuariosLabel1.Text = "Nombre";
            // 
            // ABMUsuarioGroupboxPermisos
            // 
            this.ABMUsuarioGroupboxPermisos.Controls.Add(this.ABMUsuarioGroupboxPatentes);
            this.ABMUsuarioGroupboxPermisos.Controls.Add(this.ABMUsuarioGroupboxFamilia);
            this.ABMUsuarioGroupboxPermisos.Location = new System.Drawing.Point(255, 12);
            this.ABMUsuarioGroupboxPermisos.Name = "ABMUsuarioGroupboxPermisos";
            this.ABMUsuarioGroupboxPermisos.Size = new System.Drawing.Size(800, 244);
            this.ABMUsuarioGroupboxPermisos.TabIndex = 2;
            this.ABMUsuarioGroupboxPermisos.TabStop = false;
            this.ABMUsuarioGroupboxPermisos.Text = "Permisos";
            // 
            // ABMUsuarioGroupboxPatentes
            // 
            this.ABMUsuarioGroupboxPatentes.Controls.Add(this.ABMUsuariosLabel9);
            this.ABMUsuarioGroupboxPatentes.Controls.Add(this.ABMUsuariosLabel8);
            this.ABMUsuarioGroupboxPatentes.Controls.Add(this.ABMUsuariosGrillaPatente2);
            this.ABMUsuarioGroupboxPatentes.Controls.Add(this.ABMUsuariosBotton6);
            this.ABMUsuarioGroupboxPatentes.Controls.Add(this.ABMUsuariosBotton5);
            this.ABMUsuarioGroupboxPatentes.Controls.Add(this.ABMUsuariosGrillaPatente1);
            this.ABMUsuarioGroupboxPatentes.Location = new System.Drawing.Point(392, 18);
            this.ABMUsuarioGroupboxPatentes.Margin = new System.Windows.Forms.Padding(2);
            this.ABMUsuarioGroupboxPatentes.Name = "ABMUsuarioGroupboxPatentes";
            this.ABMUsuarioGroupboxPatentes.Padding = new System.Windows.Forms.Padding(2);
            this.ABMUsuarioGroupboxPatentes.Size = new System.Drawing.Size(384, 220);
            this.ABMUsuarioGroupboxPatentes.TabIndex = 8;
            this.ABMUsuarioGroupboxPatentes.TabStop = false;
            this.ABMUsuarioGroupboxPatentes.Text = "Patente";
            // 
            // ABMUsuariosLabel9
            // 
            this.ABMUsuariosLabel9.AutoSize = true;
            this.ABMUsuariosLabel9.Location = new System.Drawing.Point(192, 22);
            this.ABMUsuariosLabel9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.ABMUsuariosLabel9.Name = "ABMUsuariosLabel9";
            this.ABMUsuariosLabel9.Size = new System.Drawing.Size(44, 13);
            this.ABMUsuariosLabel9.TabIndex = 17;
            this.ABMUsuariosLabel9.Text = "Nombre";
            // 
            // ABMUsuariosLabel8
            // 
            this.ABMUsuariosLabel8.AutoSize = true;
            this.ABMUsuariosLabel8.Location = new System.Drawing.Point(4, 22);
            this.ABMUsuariosLabel8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.ABMUsuariosLabel8.Name = "ABMUsuariosLabel8";
            this.ABMUsuariosLabel8.Size = new System.Drawing.Size(44, 13);
            this.ABMUsuariosLabel8.TabIndex = 16;
            this.ABMUsuariosLabel8.Text = "Nombre";
            // 
            // ABMUsuariosGrillaPatente2
            // 
            this.ABMUsuariosGrillaPatente2.BackgroundColor = System.Drawing.SystemColors.InactiveCaption;
            this.ABMUsuariosGrillaPatente2.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Sunken;
            this.ABMUsuariosGrillaPatente2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle17.BackColor = System.Drawing.SystemColors.InactiveCaption;
            dataGridViewCellStyle17.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle17.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle17.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle17.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle17.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.ABMUsuariosGrillaPatente2.DefaultCellStyle = dataGridViewCellStyle17;
            this.ABMUsuariosGrillaPatente2.GridColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ABMUsuariosGrillaPatente2.Location = new System.Drawing.Point(192, 37);
            this.ABMUsuariosGrillaPatente2.Margin = new System.Windows.Forms.Padding(2);
            this.ABMUsuariosGrillaPatente2.Name = "ABMUsuariosGrillaPatente2";
            this.ABMUsuariosGrillaPatente2.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            this.ABMUsuariosGrillaPatente2.RowHeadersWidth = 82;
            this.ABMUsuariosGrillaPatente2.RowTemplate.Height = 33;
            this.ABMUsuariosGrillaPatente2.Size = new System.Drawing.Size(184, 139);
            this.ABMUsuariosGrillaPatente2.TabIndex = 14;
            // 
            // ABMUsuariosBotton6
            // 
            this.ABMUsuariosBotton6.Location = new System.Drawing.Point(310, 181);
            this.ABMUsuariosBotton6.Margin = new System.Windows.Forms.Padding(2);
            this.ABMUsuariosBotton6.Name = "ABMUsuariosBotton6";
            this.ABMUsuariosBotton6.Size = new System.Drawing.Size(66, 21);
            this.ABMUsuariosBotton6.TabIndex = 4;
            this.ABMUsuariosBotton6.Text = "Quitar";
            this.ABMUsuariosBotton6.UseVisualStyleBackColor = true;
            this.ABMUsuariosBotton6.Click += new System.EventHandler(this.ABMUsuariosBotton6_Click);
            // 
            // ABMUsuariosBotton5
            // 
            this.ABMUsuariosBotton5.Location = new System.Drawing.Point(4, 180);
            this.ABMUsuariosBotton5.Margin = new System.Windows.Forms.Padding(2);
            this.ABMUsuariosBotton5.Name = "ABMUsuariosBotton5";
            this.ABMUsuariosBotton5.Size = new System.Drawing.Size(66, 21);
            this.ABMUsuariosBotton5.TabIndex = 3;
            this.ABMUsuariosBotton5.Text = "Agregar";
            this.ABMUsuariosBotton5.UseVisualStyleBackColor = true;
            this.ABMUsuariosBotton5.Click += new System.EventHandler(this.ABMUsuariosBotton5_Click);
            // 
            // ABMUsuariosGrillaPatente1
            // 
            this.ABMUsuariosGrillaPatente1.BackgroundColor = System.Drawing.SystemColors.InactiveCaption;
            this.ABMUsuariosGrillaPatente1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            this.ABMUsuariosGrillaPatente1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle18.BackColor = System.Drawing.SystemColors.InactiveCaption;
            dataGridViewCellStyle18.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle18.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle18.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle18.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.ABMUsuariosGrillaPatente1.DefaultCellStyle = dataGridViewCellStyle18;
            this.ABMUsuariosGrillaPatente1.GridColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ABMUsuariosGrillaPatente1.Location = new System.Drawing.Point(4, 37);
            this.ABMUsuariosGrillaPatente1.Margin = new System.Windows.Forms.Padding(2);
            this.ABMUsuariosGrillaPatente1.Name = "ABMUsuariosGrillaPatente1";
            this.ABMUsuariosGrillaPatente1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            this.ABMUsuariosGrillaPatente1.RowHeadersWidth = 82;
            this.ABMUsuariosGrillaPatente1.RowTemplate.Height = 33;
            this.ABMUsuariosGrillaPatente1.Size = new System.Drawing.Size(184, 139);
            this.ABMUsuariosGrillaPatente1.TabIndex = 0;
            // 
            // ABMUsuarioGroupboxFamilia
            // 
            this.ABMUsuarioGroupboxFamilia.Controls.Add(this.ABMUsuariosLabel7);
            this.ABMUsuarioGroupboxFamilia.Controls.Add(this.ABMUsuariosLabel6);
            this.ABMUsuarioGroupboxFamilia.Controls.Add(this.ABMUsuariosGrillaFamilia2);
            this.ABMUsuarioGroupboxFamilia.Controls.Add(this.ABMUsuariosBotton4);
            this.ABMUsuarioGroupboxFamilia.Controls.Add(this.ABMUsuariosBotton3);
            this.ABMUsuarioGroupboxFamilia.Controls.Add(this.ABMUsuariosGrillaFamilia1);
            this.ABMUsuarioGroupboxFamilia.Location = new System.Drawing.Point(5, 18);
            this.ABMUsuarioGroupboxFamilia.Margin = new System.Windows.Forms.Padding(2);
            this.ABMUsuarioGroupboxFamilia.Name = "ABMUsuarioGroupboxFamilia";
            this.ABMUsuarioGroupboxFamilia.Padding = new System.Windows.Forms.Padding(2);
            this.ABMUsuarioGroupboxFamilia.Size = new System.Drawing.Size(383, 220);
            this.ABMUsuarioGroupboxFamilia.TabIndex = 7;
            this.ABMUsuarioGroupboxFamilia.TabStop = false;
            this.ABMUsuarioGroupboxFamilia.Text = "Familias";
            // 
            // ABMUsuariosLabel7
            // 
            this.ABMUsuariosLabel7.AutoSize = true;
            this.ABMUsuariosLabel7.Location = new System.Drawing.Point(189, 22);
            this.ABMUsuariosLabel7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.ABMUsuariosLabel7.Name = "ABMUsuariosLabel7";
            this.ABMUsuariosLabel7.Size = new System.Drawing.Size(44, 13);
            this.ABMUsuariosLabel7.TabIndex = 15;
            this.ABMUsuariosLabel7.Text = "Nombre";
            // 
            // ABMUsuariosLabel6
            // 
            this.ABMUsuariosLabel6.AutoSize = true;
            this.ABMUsuariosLabel6.Location = new System.Drawing.Point(4, 22);
            this.ABMUsuariosLabel6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.ABMUsuariosLabel6.Name = "ABMUsuariosLabel6";
            this.ABMUsuariosLabel6.Size = new System.Drawing.Size(44, 13);
            this.ABMUsuariosLabel6.TabIndex = 14;
            this.ABMUsuariosLabel6.Text = "Nombre";
            // 
            // ABMUsuariosGrillaFamilia2
            // 
            this.ABMUsuariosGrillaFamilia2.BackgroundColor = System.Drawing.SystemColors.InactiveCaption;
            this.ABMUsuariosGrillaFamilia2.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Sunken;
            dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle19.BackColor = System.Drawing.SystemColors.InactiveCaption;
            dataGridViewCellStyle19.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle19.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle19.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle19.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle19.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.ABMUsuariosGrillaFamilia2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle19;
            this.ABMUsuariosGrillaFamilia2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ABMUsuariosGrillaFamilia2.GridColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ABMUsuariosGrillaFamilia2.Location = new System.Drawing.Point(192, 37);
            this.ABMUsuariosGrillaFamilia2.Margin = new System.Windows.Forms.Padding(2);
            this.ABMUsuariosGrillaFamilia2.Name = "ABMUsuariosGrillaFamilia2";
            this.ABMUsuariosGrillaFamilia2.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            this.ABMUsuariosGrillaFamilia2.RowHeadersWidth = 82;
            this.ABMUsuariosGrillaFamilia2.RowTemplate.Height = 33;
            this.ABMUsuariosGrillaFamilia2.Size = new System.Drawing.Size(184, 139);
            this.ABMUsuariosGrillaFamilia2.TabIndex = 13;
            // 
            // ABMUsuariosBotton4
            // 
            this.ABMUsuariosBotton4.Location = new System.Drawing.Point(310, 181);
            this.ABMUsuariosBotton4.Margin = new System.Windows.Forms.Padding(2);
            this.ABMUsuariosBotton4.Name = "ABMUsuariosBotton4";
            this.ABMUsuariosBotton4.Size = new System.Drawing.Size(66, 21);
            this.ABMUsuariosBotton4.TabIndex = 4;
            this.ABMUsuariosBotton4.Text = "Quitar";
            this.ABMUsuariosBotton4.UseVisualStyleBackColor = true;
            this.ABMUsuariosBotton4.Click += new System.EventHandler(this.ABMUsuariosBotton4_Click);
            // 
            // ABMUsuariosBotton3
            // 
            this.ABMUsuariosBotton3.Location = new System.Drawing.Point(4, 180);
            this.ABMUsuariosBotton3.Margin = new System.Windows.Forms.Padding(2);
            this.ABMUsuariosBotton3.Name = "ABMUsuariosBotton3";
            this.ABMUsuariosBotton3.Size = new System.Drawing.Size(66, 21);
            this.ABMUsuariosBotton3.TabIndex = 3;
            this.ABMUsuariosBotton3.Text = "Agregar";
            this.ABMUsuariosBotton3.UseVisualStyleBackColor = true;
            this.ABMUsuariosBotton3.Click += new System.EventHandler(this.ABMUsuariosBotton3_Click);
            // 
            // ABMUsuariosGrillaFamilia1
            // 
            this.ABMUsuariosGrillaFamilia1.BackgroundColor = System.Drawing.SystemColors.InactiveCaption;
            this.ABMUsuariosGrillaFamilia1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Sunken;
            this.ABMUsuariosGrillaFamilia1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle20.BackColor = System.Drawing.SystemColors.InactiveCaption;
            dataGridViewCellStyle20.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle20.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle20.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle20.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle20.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.ABMUsuariosGrillaFamilia1.DefaultCellStyle = dataGridViewCellStyle20;
            this.ABMUsuariosGrillaFamilia1.GridColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ABMUsuariosGrillaFamilia1.Location = new System.Drawing.Point(4, 37);
            this.ABMUsuariosGrillaFamilia1.Margin = new System.Windows.Forms.Padding(2);
            this.ABMUsuariosGrillaFamilia1.Name = "ABMUsuariosGrillaFamilia1";
            this.ABMUsuariosGrillaFamilia1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            this.ABMUsuariosGrillaFamilia1.RowHeadersWidth = 82;
            this.ABMUsuariosGrillaFamilia1.RowTemplate.Height = 33;
            this.ABMUsuariosGrillaFamilia1.Size = new System.Drawing.Size(184, 139);
            this.ABMUsuariosGrillaFamilia1.TabIndex = 0;
            // 
            // ABMUsuariosBotton1
            // 
            this.ABMUsuariosBotton1.Location = new System.Drawing.Point(32, 261);
            this.ABMUsuariosBotton1.Margin = new System.Windows.Forms.Padding(2);
            this.ABMUsuariosBotton1.Name = "ABMUsuariosBotton1";
            this.ABMUsuariosBotton1.Size = new System.Drawing.Size(66, 21);
            this.ABMUsuariosBotton1.TabIndex = 13;
            this.ABMUsuariosBotton1.Text = "Aplicar";
            this.ABMUsuariosBotton1.UseVisualStyleBackColor = true;
            this.ABMUsuariosBotton1.Click += new System.EventHandler(this.ABMUsuariosBotton1_Click);
            // 
            // ABMUsuariosBotton2
            // 
            this.ABMUsuariosBotton2.Location = new System.Drawing.Point(169, 261);
            this.ABMUsuariosBotton2.Margin = new System.Windows.Forms.Padding(2);
            this.ABMUsuariosBotton2.Name = "ABMUsuariosBotton2";
            this.ABMUsuariosBotton2.Size = new System.Drawing.Size(66, 21);
            this.ABMUsuariosBotton2.TabIndex = 13;
            this.ABMUsuariosBotton2.Text = "Cancelar";
            this.ABMUsuariosBotton2.UseVisualStyleBackColor = true;
            this.ABMUsuariosBotton2.Click += new System.EventHandler(this.ABMUsuariosBotton2_Click);
            // 
            // ABMUsuarios
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1067, 302);
            this.Controls.Add(this.ABMUsuariosBotton2);
            this.Controls.Add(this.ABMUsuariosBotton1);
            this.Controls.Add(this.ABMUsuarioGroupboxPermisos);
            this.Controls.Add(this.ABMUsuarioGroupboxUsuario);
            this.Name = "ABMUsuarios";
            this.Text = "ABMUsuarios";
            this.Load += new System.EventHandler(this.ABMUsuarios_Load);
            this.ABMUsuarioGroupboxUsuario.ResumeLayout(false);
            this.ABMUsuarioGroupboxUsuario.PerformLayout();
            this.ABMUsuarioGroupboxPermisos.ResumeLayout(false);
            this.ABMUsuarioGroupboxPatentes.ResumeLayout(false);
            this.ABMUsuarioGroupboxPatentes.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ABMUsuariosGrillaPatente2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ABMUsuariosGrillaPatente1)).EndInit();
            this.ABMUsuarioGroupboxFamilia.ResumeLayout(false);
            this.ABMUsuarioGroupboxFamilia.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ABMUsuariosGrillaFamilia2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ABMUsuariosGrillaFamilia1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox ABMUsuarioGroupboxUsuario;
        private System.Windows.Forms.TextBox ABMUsuariosTextoUsuario;
        private System.Windows.Forms.Label ABMUsuariosLabel3;
        private System.Windows.Forms.ComboBox ABMUsuariosComboIdioma;
        private System.Windows.Forms.Label ABMUsuariosLabel5;
        private System.Windows.Forms.Label ABMUsuariosLabel4;
        private System.Windows.Forms.TextBox ABMUsuariosTextoClave;
        private System.Windows.Forms.TextBox ABMUsuariosTextoApellido;
        private System.Windows.Forms.TextBox ABMUsuariosTextoNombre;
        private System.Windows.Forms.Label ABMUsuariosLabel2;
        private System.Windows.Forms.Label ABMUsuariosLabel1;
        private System.Windows.Forms.GroupBox ABMUsuarioGroupboxPermisos;
        private System.Windows.Forms.GroupBox ABMUsuarioGroupboxPatentes;
        private System.Windows.Forms.Button ABMUsuariosBotton6;
        private System.Windows.Forms.Button ABMUsuariosBotton5;
        private System.Windows.Forms.DataGridView ABMUsuariosGrillaPatente1;
        private System.Windows.Forms.GroupBox ABMUsuarioGroupboxFamilia;
        private System.Windows.Forms.Button ABMUsuariosBotton4;
        private System.Windows.Forms.Button ABMUsuariosBotton3;
        private System.Windows.Forms.DataGridView ABMUsuariosGrillaFamilia1;
        private System.Windows.Forms.Button ABMUsuariosBotton1;
        private System.Windows.Forms.Button ABMUsuariosBotton2;
        private System.Windows.Forms.DataGridView ABMUsuariosGrillaPatente2;
        private System.Windows.Forms.DataGridView ABMUsuariosGrillaFamilia2;
        private System.Windows.Forms.Label ABMUsuariosLabel9;
        private System.Windows.Forms.Label ABMUsuariosLabel8;
        private System.Windows.Forms.Label ABMUsuariosLabel7;
        private System.Windows.Forms.Label ABMUsuariosLabel6;
    }
}