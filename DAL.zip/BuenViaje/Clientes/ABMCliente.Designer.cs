﻿namespace BuenViaje.Clientes
{
    partial class ABMCliente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ABMClientesBotton2 = new System.Windows.Forms.Button();
            this.ABMClientesBotton1 = new System.Windows.Forms.Button();
            this.ABMClientesLabel1 = new System.Windows.Forms.Label();
            this.ABMClientesTexto3 = new System.Windows.Forms.TextBox();
            this.ABMClientesLabel3 = new System.Windows.Forms.Label();
            this.ABMClientesTexto2 = new System.Windows.Forms.TextBox();
            this.ABMClientesTexto1 = new System.Windows.Forms.TextBox();
            this.ABMClientesLabel2 = new System.Windows.Forms.Label();
            this.ABMClientesTexto4 = new System.Windows.Forms.TextBox();
            this.ABMClientesLabel4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // ABMClientesBotton2
            // 
            this.ABMClientesBotton2.Location = new System.Drawing.Point(157, 167);
            this.ABMClientesBotton2.Margin = new System.Windows.Forms.Padding(2);
            this.ABMClientesBotton2.Name = "ABMClientesBotton2";
            this.ABMClientesBotton2.Size = new System.Drawing.Size(66, 21);
            this.ABMClientesBotton2.TabIndex = 40;
            this.ABMClientesBotton2.Text = "Cancelar";
            this.ABMClientesBotton2.UseVisualStyleBackColor = true;
            this.ABMClientesBotton2.Click += new System.EventHandler(this.ABMClientesBotton2_Click);
            // 
            // ABMClientesBotton1
            // 
            this.ABMClientesBotton1.Location = new System.Drawing.Point(11, 167);
            this.ABMClientesBotton1.Margin = new System.Windows.Forms.Padding(2);
            this.ABMClientesBotton1.Name = "ABMClientesBotton1";
            this.ABMClientesBotton1.Size = new System.Drawing.Size(66, 21);
            this.ABMClientesBotton1.TabIndex = 41;
            this.ABMClientesBotton1.Text = "Aplicar";
            this.ABMClientesBotton1.UseVisualStyleBackColor = true;
            this.ABMClientesBotton1.Click += new System.EventHandler(this.ABMClientesBotton1_Click);
            // 
            // ABMClientesLabel1
            // 
            this.ABMClientesLabel1.AutoSize = true;
            this.ABMClientesLabel1.Location = new System.Drawing.Point(8, 6);
            this.ABMClientesLabel1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.ABMClientesLabel1.Name = "ABMClientesLabel1";
            this.ABMClientesLabel1.Size = new System.Drawing.Size(44, 13);
            this.ABMClientesLabel1.TabIndex = 39;
            this.ABMClientesLabel1.Text = "Nombre";
            // 
            // ABMClientesTexto3
            // 
            this.ABMClientesTexto3.Location = new System.Drawing.Point(11, 100);
            this.ABMClientesTexto3.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.ABMClientesTexto3.Name = "ABMClientesTexto3";
            this.ABMClientesTexto3.Size = new System.Drawing.Size(212, 20);
            this.ABMClientesTexto3.TabIndex = 38;
            this.ABMClientesTexto3.TextChanged += new System.EventHandler(this.ABMClientesTexto3_TextChanged);
            // 
            // ABMClientesLabel3
            // 
            this.ABMClientesLabel3.AutoSize = true;
            this.ABMClientesLabel3.Location = new System.Drawing.Point(8, 84);
            this.ABMClientesLabel3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.ABMClientesLabel3.Name = "ABMClientesLabel3";
            this.ABMClientesLabel3.Size = new System.Drawing.Size(26, 13);
            this.ABMClientesLabel3.TabIndex = 37;
            this.ABMClientesLabel3.Text = "DNI";
            // 
            // ABMClientesTexto2
            // 
            this.ABMClientesTexto2.Location = new System.Drawing.Point(11, 61);
            this.ABMClientesTexto2.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.ABMClientesTexto2.Name = "ABMClientesTexto2";
            this.ABMClientesTexto2.Size = new System.Drawing.Size(212, 20);
            this.ABMClientesTexto2.TabIndex = 36;
            this.ABMClientesTexto2.TextChanged += new System.EventHandler(this.ABMClientesTexto2_TextChanged);
            // 
            // ABMClientesTexto1
            // 
            this.ABMClientesTexto1.Location = new System.Drawing.Point(11, 22);
            this.ABMClientesTexto1.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.ABMClientesTexto1.Name = "ABMClientesTexto1";
            this.ABMClientesTexto1.Size = new System.Drawing.Size(212, 20);
            this.ABMClientesTexto1.TabIndex = 35;
            this.ABMClientesTexto1.TextChanged += new System.EventHandler(this.ABMClientesTexto1_TextChanged);
            // 
            // ABMClientesLabel2
            // 
            this.ABMClientesLabel2.AutoSize = true;
            this.ABMClientesLabel2.Location = new System.Drawing.Point(8, 45);
            this.ABMClientesLabel2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.ABMClientesLabel2.Name = "ABMClientesLabel2";
            this.ABMClientesLabel2.Size = new System.Drawing.Size(44, 13);
            this.ABMClientesLabel2.TabIndex = 34;
            this.ABMClientesLabel2.Text = "Apellido";
            // 
            // ABMClientesTexto4
            // 
            this.ABMClientesTexto4.Location = new System.Drawing.Point(11, 142);
            this.ABMClientesTexto4.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.ABMClientesTexto4.Name = "ABMClientesTexto4";
            this.ABMClientesTexto4.Size = new System.Drawing.Size(212, 20);
            this.ABMClientesTexto4.TabIndex = 43;
            this.ABMClientesTexto4.TextChanged += new System.EventHandler(this.ABMClientesTexto4_TextChanged);
            // 
            // ABMClientesLabel4
            // 
            this.ABMClientesLabel4.AutoSize = true;
            this.ABMClientesLabel4.Location = new System.Drawing.Point(8, 126);
            this.ABMClientesLabel4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.ABMClientesLabel4.Name = "ABMClientesLabel4";
            this.ABMClientesLabel4.Size = new System.Drawing.Size(32, 13);
            this.ABMClientesLabel4.TabIndex = 42;
            this.ABMClientesLabel4.Text = "Email";
            // 
            // ABMCliente
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(240, 205);
            this.Controls.Add(this.ABMClientesTexto4);
            this.Controls.Add(this.ABMClientesLabel4);
            this.Controls.Add(this.ABMClientesBotton2);
            this.Controls.Add(this.ABMClientesBotton1);
            this.Controls.Add(this.ABMClientesLabel1);
            this.Controls.Add(this.ABMClientesTexto3);
            this.Controls.Add(this.ABMClientesLabel3);
            this.Controls.Add(this.ABMClientesTexto2);
            this.Controls.Add(this.ABMClientesTexto1);
            this.Controls.Add(this.ABMClientesLabel2);
            this.Name = "ABMCliente";
            this.Text = "Cliente";
            this.Load += new System.EventHandler(this.ABMCliente_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button ABMClientesBotton2;
        private System.Windows.Forms.Button ABMClientesBotton1;
        private System.Windows.Forms.Label ABMClientesLabel1;
        private System.Windows.Forms.TextBox ABMClientesTexto3;
        private System.Windows.Forms.Label ABMClientesLabel3;
        private System.Windows.Forms.TextBox ABMClientesTexto2;
        private System.Windows.Forms.TextBox ABMClientesTexto1;
        private System.Windows.Forms.Label ABMClientesLabel2;
        private System.Windows.Forms.TextBox ABMClientesTexto4;
        private System.Windows.Forms.Label ABMClientesLabel4;
    }
}