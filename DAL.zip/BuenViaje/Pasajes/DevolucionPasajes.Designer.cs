﻿namespace BuenViaje.Pasajes
{
    partial class DevolucionPasajes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pasajesPrincipalGroupBox2 = new System.Windows.Forms.GroupBox();
            this.pasajesDevolucionDataGridViajes = new System.Windows.Forms.DataGridView();
            this.pasajesPrincipalTextBox4 = new System.Windows.Forms.TextBox();
            this.pasajesPrincipalButton2 = new System.Windows.Forms.Button();
            this.pasajesPrincipalTextBox5 = new System.Windows.Forms.TextBox();
            this.pasajeDateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.pasajesPrincipalLabel4 = new System.Windows.Forms.Label();
            this.pasajeDateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.pasajesPrincipalLabel5 = new System.Windows.Forms.Label();
            this.pasajesPrincipalLabel7 = new System.Windows.Forms.Label();
            this.pasajesPrincipalLabe7 = new System.Windows.Forms.Label();
            this.DevolucionText1 = new System.Windows.Forms.Button();
            this.DevolucionText2 = new System.Windows.Forms.Button();
            this.pasajesPrincipalGroupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pasajesDevolucionDataGridViajes)).BeginInit();
            this.SuspendLayout();
            // 
            // pasajesPrincipalGroupBox2
            // 
            this.pasajesPrincipalGroupBox2.Controls.Add(this.pasajesDevolucionDataGridViajes);
            this.pasajesPrincipalGroupBox2.Controls.Add(this.pasajesPrincipalTextBox4);
            this.pasajesPrincipalGroupBox2.Controls.Add(this.pasajesPrincipalButton2);
            this.pasajesPrincipalGroupBox2.Controls.Add(this.pasajesPrincipalTextBox5);
            this.pasajesPrincipalGroupBox2.Controls.Add(this.pasajeDateTimePicker1);
            this.pasajesPrincipalGroupBox2.Controls.Add(this.pasajesPrincipalLabel4);
            this.pasajesPrincipalGroupBox2.Controls.Add(this.pasajeDateTimePicker2);
            this.pasajesPrincipalGroupBox2.Controls.Add(this.pasajesPrincipalLabel5);
            this.pasajesPrincipalGroupBox2.Controls.Add(this.pasajesPrincipalLabel7);
            this.pasajesPrincipalGroupBox2.Controls.Add(this.pasajesPrincipalLabe7);
            this.pasajesPrincipalGroupBox2.Location = new System.Drawing.Point(12, 12);
            this.pasajesPrincipalGroupBox2.Name = "pasajesPrincipalGroupBox2";
            this.pasajesPrincipalGroupBox2.Size = new System.Drawing.Size(715, 289);
            this.pasajesPrincipalGroupBox2.TabIndex = 60;
            this.pasajesPrincipalGroupBox2.TabStop = false;
            this.pasajesPrincipalGroupBox2.Text = "Viajes";
            // 
            // pasajesDevolucionDataGridViajes
            // 
            this.pasajesDevolucionDataGridViajes.BackgroundColor = System.Drawing.SystemColors.InactiveCaption;
            this.pasajesDevolucionDataGridViajes.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Sunken;
            this.pasajesDevolucionDataGridViajes.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            this.pasajesDevolucionDataGridViajes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.pasajesDevolucionDataGridViajes.Cursor = System.Windows.Forms.Cursors.Default;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.InactiveCaption;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.pasajesDevolucionDataGridViajes.DefaultCellStyle = dataGridViewCellStyle3;
            this.pasajesDevolucionDataGridViajes.GridColor = System.Drawing.SystemColors.ActiveCaption;
            this.pasajesDevolucionDataGridViajes.Location = new System.Drawing.Point(7, 58);
            this.pasajesDevolucionDataGridViajes.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pasajesDevolucionDataGridViajes.Name = "pasajesDevolucionDataGridViajes";
            this.pasajesDevolucionDataGridViajes.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.pasajesDevolucionDataGridViajes.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.pasajesDevolucionDataGridViajes.RowHeadersWidth = 51;
            this.pasajesDevolucionDataGridViajes.RowTemplate.Height = 24;
            this.pasajesDevolucionDataGridViajes.Size = new System.Drawing.Size(703, 225);
            this.pasajesDevolucionDataGridViajes.TabIndex = 41;
            // 
            // pasajesPrincipalTextBox4
            // 
            this.pasajesPrincipalTextBox4.Location = new System.Drawing.Point(14, 33);
            this.pasajesPrincipalTextBox4.Name = "pasajesPrincipalTextBox4";
            this.pasajesPrincipalTextBox4.Size = new System.Drawing.Size(100, 20);
            this.pasajesPrincipalTextBox4.TabIndex = 44;
            // 
            // pasajesPrincipalButton2
            // 
            this.pasajesPrincipalButton2.Location = new System.Drawing.Point(630, 32);
            this.pasajesPrincipalButton2.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pasajesPrincipalButton2.Name = "pasajesPrincipalButton2";
            this.pasajesPrincipalButton2.Size = new System.Drawing.Size(78, 20);
            this.pasajesPrincipalButton2.TabIndex = 57;
            this.pasajesPrincipalButton2.Text = "Buscar";
            this.pasajesPrincipalButton2.UseVisualStyleBackColor = true;
            this.pasajesPrincipalButton2.Click += new System.EventHandler(this.pasajesPrincipalButton2_Click);
            // 
            // pasajesPrincipalTextBox5
            // 
            this.pasajesPrincipalTextBox5.Location = new System.Drawing.Point(120, 33);
            this.pasajesPrincipalTextBox5.Name = "pasajesPrincipalTextBox5";
            this.pasajesPrincipalTextBox5.Size = new System.Drawing.Size(100, 20);
            this.pasajesPrincipalTextBox5.TabIndex = 45;
            // 
            // pasajeDateTimePicker1
            // 
            this.pasajeDateTimePicker1.CustomFormat = "MM-dd-yy";
            this.pasajeDateTimePicker1.Location = new System.Drawing.Point(226, 33);
            this.pasajeDateTimePicker1.Name = "pasajeDateTimePicker1";
            this.pasajeDateTimePicker1.Size = new System.Drawing.Size(200, 20);
            this.pasajeDateTimePicker1.TabIndex = 46;
            // 
            // pasajesPrincipalLabel4
            // 
            this.pasajesPrincipalLabel4.AutoSize = true;
            this.pasajesPrincipalLabel4.Location = new System.Drawing.Point(11, 17);
            this.pasajesPrincipalLabel4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.pasajesPrincipalLabel4.Name = "pasajesPrincipalLabel4";
            this.pasajesPrincipalLabel4.Size = new System.Drawing.Size(38, 13);
            this.pasajesPrincipalLabel4.TabIndex = 51;
            this.pasajesPrincipalLabel4.Text = "Origen";
            // 
            // pasajeDateTimePicker2
            // 
            this.pasajeDateTimePicker2.CustomFormat = "MM-dd-yy";
            this.pasajeDateTimePicker2.Location = new System.Drawing.Point(432, 33);
            this.pasajeDateTimePicker2.Name = "pasajeDateTimePicker2";
            this.pasajeDateTimePicker2.Size = new System.Drawing.Size(193, 20);
            this.pasajeDateTimePicker2.TabIndex = 47;
            // 
            // pasajesPrincipalLabel5
            // 
            this.pasajesPrincipalLabel5.AutoSize = true;
            this.pasajesPrincipalLabel5.Location = new System.Drawing.Point(117, 17);
            this.pasajesPrincipalLabel5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.pasajesPrincipalLabel5.Name = "pasajesPrincipalLabel5";
            this.pasajesPrincipalLabel5.Size = new System.Drawing.Size(43, 13);
            this.pasajesPrincipalLabel5.TabIndex = 50;
            this.pasajesPrincipalLabel5.Text = "Destino";
            // 
            // pasajesPrincipalLabel7
            // 
            this.pasajesPrincipalLabel7.AutoSize = true;
            this.pasajesPrincipalLabel7.Location = new System.Drawing.Point(223, 17);
            this.pasajesPrincipalLabel7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.pasajesPrincipalLabel7.Name = "pasajesPrincipalLabel7";
            this.pasajesPrincipalLabel7.Size = new System.Drawing.Size(38, 13);
            this.pasajesPrincipalLabel7.TabIndex = 48;
            this.pasajesPrincipalLabel7.Text = "Desde";
            // 
            // pasajesPrincipalLabe7
            // 
            this.pasajesPrincipalLabe7.AutoSize = true;
            this.pasajesPrincipalLabe7.Location = new System.Drawing.Point(434, 17);
            this.pasajesPrincipalLabe7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.pasajesPrincipalLabe7.Name = "pasajesPrincipalLabe7";
            this.pasajesPrincipalLabe7.Size = new System.Drawing.Size(35, 13);
            this.pasajesPrincipalLabe7.TabIndex = 49;
            this.pasajesPrincipalLabe7.Text = "Hasta";
            // 
            // DevolucionText1
            // 
            this.DevolucionText1.Location = new System.Drawing.Point(19, 307);
            this.DevolucionText1.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.DevolucionText1.Name = "DevolucionText1";
            this.DevolucionText1.Size = new System.Drawing.Size(78, 20);
            this.DevolucionText1.TabIndex = 58;
            this.DevolucionText1.Text = "Devolver";
            this.DevolucionText1.UseVisualStyleBackColor = true;
            this.DevolucionText1.Click += new System.EventHandler(this.DevolucionText1_Click);
            // 
            // DevolucionText2
            // 
            this.DevolucionText2.Location = new System.Drawing.Point(101, 307);
            this.DevolucionText2.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.DevolucionText2.Name = "DevolucionText2";
            this.DevolucionText2.Size = new System.Drawing.Size(78, 20);
            this.DevolucionText2.TabIndex = 61;
            this.DevolucionText2.Text = "Salir";
            this.DevolucionText2.UseVisualStyleBackColor = true;
            this.DevolucionText2.Click += new System.EventHandler(this.DevolucionText2_Click);
            // 
            // DevolucionPasajes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(800, 335);
            this.Controls.Add(this.DevolucionText2);
            this.Controls.Add(this.DevolucionText1);
            this.Controls.Add(this.pasajesPrincipalGroupBox2);
            this.Name = "DevolucionPasajes";
            this.Text = "DevolucionPasajes";
            this.Load += new System.EventHandler(this.DevolucionPasajes_Load);
            this.pasajesPrincipalGroupBox2.ResumeLayout(false);
            this.pasajesPrincipalGroupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pasajesDevolucionDataGridViajes)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox pasajesPrincipalGroupBox2;
        private System.Windows.Forms.DataGridView pasajesDevolucionDataGridViajes;
        private System.Windows.Forms.TextBox pasajesPrincipalTextBox4;
        private System.Windows.Forms.Button pasajesPrincipalButton2;
        private System.Windows.Forms.TextBox pasajesPrincipalTextBox5;
        private System.Windows.Forms.DateTimePicker pasajeDateTimePicker1;
        private System.Windows.Forms.Label pasajesPrincipalLabel4;
        private System.Windows.Forms.DateTimePicker pasajeDateTimePicker2;
        private System.Windows.Forms.Label pasajesPrincipalLabel5;
        private System.Windows.Forms.Label pasajesPrincipalLabel7;
        private System.Windows.Forms.Label pasajesPrincipalLabe7;
        private System.Windows.Forms.Button DevolucionText1;
        private System.Windows.Forms.Button DevolucionText2;
    }
}