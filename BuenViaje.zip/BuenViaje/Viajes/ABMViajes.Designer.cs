﻿namespace BuenViaje.Viajes
{
    partial class ABMViajes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ViajeABMCombo1 = new System.Windows.Forms.ComboBox();
            this.ViajeABMButton2 = new System.Windows.Forms.Button();
            this.ViajeABMButton1 = new System.Windows.Forms.Button();
            this.ViajeABMLabel1 = new System.Windows.Forms.Label();
            this.ViajeABMLabel4 = new System.Windows.Forms.Label();
            this.ViajeABMDatePickerDesdeHora = new System.Windows.Forms.DateTimePicker();
            this.ViajeABMDatePickerDesde = new System.Windows.Forms.DateTimePicker();
            this.ViajeABMCheckBox1 = new System.Windows.Forms.CheckBox();
            this.ViajeABMCombo2 = new System.Windows.Forms.ComboBox();
            this.ViajeABMLabel2 = new System.Windows.Forms.Label();
            this.ViajeABMCombo3 = new System.Windows.Forms.ComboBox();
            this.ViajeABMLabel3 = new System.Windows.Forms.Label();
            this.ViajeABMDatePickerHasta = new System.Windows.Forms.DateTimePicker();
            this.ViajeABMLabel5 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // ViajeABMCombo1
            // 
            this.ViajeABMCombo1.FormattingEnabled = true;
            this.ViajeABMCombo1.Location = new System.Drawing.Point(12, 25);
            this.ViajeABMCombo1.Name = "ViajeABMCombo1";
            this.ViajeABMCombo1.Size = new System.Drawing.Size(212, 21);
            this.ViajeABMCombo1.TabIndex = 52;
            this.ViajeABMCombo1.SelectedIndexChanged += new System.EventHandler(this.ViajeABMCombo1_SelectedIndexChanged);
            // 
            // ViajeABMButton2
            // 
            this.ViajeABMButton2.Location = new System.Drawing.Point(83, 218);
            this.ViajeABMButton2.Margin = new System.Windows.Forms.Padding(2);
            this.ViajeABMButton2.Name = "ViajeABMButton2";
            this.ViajeABMButton2.Size = new System.Drawing.Size(66, 21);
            this.ViajeABMButton2.TabIndex = 50;
            this.ViajeABMButton2.Text = "Cancelar";
            this.ViajeABMButton2.UseVisualStyleBackColor = true;
            this.ViajeABMButton2.Click += new System.EventHandler(this.ViajeABMButton2_Click);
            // 
            // ViajeABMButton1
            // 
            this.ViajeABMButton1.Location = new System.Drawing.Point(13, 218);
            this.ViajeABMButton1.Margin = new System.Windows.Forms.Padding(2);
            this.ViajeABMButton1.Name = "ViajeABMButton1";
            this.ViajeABMButton1.Size = new System.Drawing.Size(66, 21);
            this.ViajeABMButton1.TabIndex = 51;
            this.ViajeABMButton1.Text = "Aplicar";
            this.ViajeABMButton1.UseVisualStyleBackColor = true;
            this.ViajeABMButton1.Click += new System.EventHandler(this.ViajeABMButton1_Click);
            // 
            // ViajeABMLabel1
            // 
            this.ViajeABMLabel1.AutoSize = true;
            this.ViajeABMLabel1.Location = new System.Drawing.Point(14, 9);
            this.ViajeABMLabel1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.ViajeABMLabel1.Name = "ViajeABMLabel1";
            this.ViajeABMLabel1.Size = new System.Drawing.Size(30, 13);
            this.ViajeABMLabel1.TabIndex = 49;
            this.ViajeABMLabel1.Text = "Ruta";
            // 
            // ViajeABMLabel4
            // 
            this.ViajeABMLabel4.AutoSize = true;
            this.ViajeABMLabel4.Location = new System.Drawing.Point(9, 135);
            this.ViajeABMLabel4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.ViajeABMLabel4.Name = "ViajeABMLabel4";
            this.ViajeABMLabel4.Size = new System.Drawing.Size(37, 13);
            this.ViajeABMLabel4.TabIndex = 46;
            this.ViajeABMLabel4.Text = "Fecha";
            // 
            // ViajeABMDatePickerDesdeHora
            // 
            this.ViajeABMDatePickerDesdeHora.CustomFormat = "H:mm:ss";
            this.ViajeABMDatePickerDesdeHora.Location = new System.Drawing.Point(230, 151);
            this.ViajeABMDatePickerDesdeHora.Name = "ViajeABMDatePickerDesdeHora";
            this.ViajeABMDatePickerDesdeHora.Size = new System.Drawing.Size(98, 20);
            this.ViajeABMDatePickerDesdeHora.TabIndex = 57;
            this.ViajeABMDatePickerDesdeHora.ValueChanged += new System.EventHandler(this.ViajeABMDatePickerDesdeHora_ValueChanged);
            // 
            // ViajeABMDatePickerDesde
            // 
            this.ViajeABMDatePickerDesde.CustomFormat = "MM-dd-yy";
            this.ViajeABMDatePickerDesde.Location = new System.Drawing.Point(12, 151);
            this.ViajeABMDatePickerDesde.Name = "ViajeABMDatePickerDesde";
            this.ViajeABMDatePickerDesde.Size = new System.Drawing.Size(212, 20);
            this.ViajeABMDatePickerDesde.TabIndex = 56;
            this.ViajeABMDatePickerDesde.ValueChanged += new System.EventHandler(this.ViajeABMDatePickerDesde_ValueChanged);
            // 
            // ViajeABMCheckBox1
            // 
            this.ViajeABMCheckBox1.AutoSize = true;
            this.ViajeABMCheckBox1.Location = new System.Drawing.Point(17, 283);
            this.ViajeABMCheckBox1.Name = "ViajeABMCheckBox1";
            this.ViajeABMCheckBox1.Size = new System.Drawing.Size(68, 17);
            this.ViajeABMCheckBox1.TabIndex = 59;
            this.ViajeABMCheckBox1.Text = "Cancelar";
            this.ViajeABMCheckBox1.UseVisualStyleBackColor = true;
            this.ViajeABMCheckBox1.CheckedChanged += new System.EventHandler(this.ViajeABMCheckBox1_CheckedChanged);
            // 
            // ViajeABMCombo2
            // 
            this.ViajeABMCombo2.FormattingEnabled = true;
            this.ViajeABMCombo2.Location = new System.Drawing.Point(12, 66);
            this.ViajeABMCombo2.Name = "ViajeABMCombo2";
            this.ViajeABMCombo2.Size = new System.Drawing.Size(212, 21);
            this.ViajeABMCombo2.TabIndex = 61;
            this.ViajeABMCombo2.SelectedIndexChanged += new System.EventHandler(this.ViajeABMCombo2_SelectedIndexChanged);
            // 
            // ViajeABMLabel2
            // 
            this.ViajeABMLabel2.AutoSize = true;
            this.ViajeABMLabel2.Location = new System.Drawing.Point(14, 50);
            this.ViajeABMLabel2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.ViajeABMLabel2.Name = "ViajeABMLabel2";
            this.ViajeABMLabel2.Size = new System.Drawing.Size(25, 13);
            this.ViajeABMLabel2.TabIndex = 60;
            this.ViajeABMLabel2.Text = "Bus";
            // 
            // ViajeABMCombo3
            // 
            this.ViajeABMCombo3.FormattingEnabled = true;
            this.ViajeABMCombo3.Location = new System.Drawing.Point(12, 107);
            this.ViajeABMCombo3.Name = "ViajeABMCombo3";
            this.ViajeABMCombo3.Size = new System.Drawing.Size(212, 21);
            this.ViajeABMCombo3.TabIndex = 63;
            this.ViajeABMCombo3.SelectedIndexChanged += new System.EventHandler(this.ViajeABMCombo3_SelectedIndexChanged);
            // 
            // ViajeABMLabel3
            // 
            this.ViajeABMLabel3.AutoSize = true;
            this.ViajeABMLabel3.Location = new System.Drawing.Point(14, 91);
            this.ViajeABMLabel3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.ViajeABMLabel3.Name = "ViajeABMLabel3";
            this.ViajeABMLabel3.Size = new System.Drawing.Size(28, 13);
            this.ViajeABMLabel3.TabIndex = 62;
            this.ViajeABMLabel3.Text = "Tipo";
            // 
            // ViajeABMDatePickerHasta
            // 
            this.ViajeABMDatePickerHasta.CustomFormat = "MM-dd-yy";
            this.ViajeABMDatePickerHasta.Location = new System.Drawing.Point(12, 193);
            this.ViajeABMDatePickerHasta.Name = "ViajeABMDatePickerHasta";
            this.ViajeABMDatePickerHasta.Size = new System.Drawing.Size(212, 20);
            this.ViajeABMDatePickerHasta.TabIndex = 65;
            this.ViajeABMDatePickerHasta.ValueChanged += new System.EventHandler(this.ViajeABMDatePickerHasta_ValueChanged);
            // 
            // ViajeABMLabel5
            // 
            this.ViajeABMLabel5.AutoSize = true;
            this.ViajeABMLabel5.Location = new System.Drawing.Point(9, 177);
            this.ViajeABMLabel5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.ViajeABMLabel5.Name = "ViajeABMLabel5";
            this.ViajeABMLabel5.Size = new System.Drawing.Size(35, 13);
            this.ViajeABMLabel5.TabIndex = 64;
            this.ViajeABMLabel5.Text = "Hasta";
            // 
            // ABMViajes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(340, 312);
            this.Controls.Add(this.ViajeABMDatePickerHasta);
            this.Controls.Add(this.ViajeABMLabel5);
            this.Controls.Add(this.ViajeABMCombo3);
            this.Controls.Add(this.ViajeABMLabel3);
            this.Controls.Add(this.ViajeABMCombo2);
            this.Controls.Add(this.ViajeABMLabel2);
            this.Controls.Add(this.ViajeABMCheckBox1);
            this.Controls.Add(this.ViajeABMDatePickerDesdeHora);
            this.Controls.Add(this.ViajeABMDatePickerDesde);
            this.Controls.Add(this.ViajeABMCombo1);
            this.Controls.Add(this.ViajeABMButton2);
            this.Controls.Add(this.ViajeABMButton1);
            this.Controls.Add(this.ViajeABMLabel1);
            this.Controls.Add(this.ViajeABMLabel4);
            this.Name = "ABMViajes";
            this.Text = "ViajesABM";
            this.Load += new System.EventHandler(this.ViajesABM_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ComboBox ViajeABMCombo1;
        private System.Windows.Forms.Button ViajeABMButton2;
        private System.Windows.Forms.Button ViajeABMButton1;
        private System.Windows.Forms.Label ViajeABMLabel1;
        private System.Windows.Forms.Label ViajeABMLabel4;
        private System.Windows.Forms.DateTimePicker ViajeABMDatePickerDesdeHora;
        private System.Windows.Forms.DateTimePicker ViajeABMDatePickerDesde;
        private System.Windows.Forms.CheckBox ViajeABMCheckBox1;
        private System.Windows.Forms.ComboBox ViajeABMCombo2;
        private System.Windows.Forms.Label ViajeABMLabel2;
        private System.Windows.Forms.ComboBox ViajeABMCombo3;
        private System.Windows.Forms.Label ViajeABMLabel3;
        private System.Windows.Forms.DateTimePicker ViajeABMDatePickerHasta;
        private System.Windows.Forms.Label ViajeABMLabel5;
    }
}