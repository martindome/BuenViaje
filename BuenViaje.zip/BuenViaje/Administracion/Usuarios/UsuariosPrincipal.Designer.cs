﻿namespace BuenViaje.Administracion.Usuarios
{
    partial class UsuariosPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.grillaUsuarios = new System.Windows.Forms.DataGridView();
            this.UsuarioPrincipalBotton1 = new System.Windows.Forms.Button();
            this.UsuarioPrincipalBotton2 = new System.Windows.Forms.Button();
            this.UsuarioPrincipalBotton3 = new System.Windows.Forms.Button();
            this.UsuarioPrincipalBotton4 = new System.Windows.Forms.Button();
            this.splitter1 = new System.Windows.Forms.Splitter();
            this.UsuarioPrinciplaText1 = new System.Windows.Forms.TextBox();
            this.UsuarioPrincipalGroupBox = new System.Windows.Forms.GroupBox();
            this.UsuarioPrincipalBotton6 = new System.Windows.Forms.Button();
            this.UsuarioPrincipalBotton5 = new System.Windows.Forms.Button();
            this.UsuarioPrincipalLabel5 = new System.Windows.Forms.Label();
            this.UsuarioPrinciplaText5 = new System.Windows.Forms.TextBox();
            this.UsuarioPrincipalLabel4 = new System.Windows.Forms.Label();
            this.UsuarioPrinciplaText4 = new System.Windows.Forms.TextBox();
            this.UsuarioPrincipalLabel3 = new System.Windows.Forms.Label();
            this.UsuarioPrinciplaText3 = new System.Windows.Forms.TextBox();
            this.UsuarioPrincipalLabel2 = new System.Windows.Forms.Label();
            this.UsuarioPrinciplaText2 = new System.Windows.Forms.TextBox();
            this.UsuarioPrincipalLabel1 = new System.Windows.Forms.Label();
            this.UsuarioPrincipalBotton7 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.grillaUsuarios)).BeginInit();
            this.UsuarioPrincipalGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // grillaUsuarios
            // 
            this.grillaUsuarios.BackgroundColor = System.Drawing.SystemColors.InactiveCaption;
            this.grillaUsuarios.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Sunken;
            this.grillaUsuarios.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.InactiveCaption;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.grillaUsuarios.DefaultCellStyle = dataGridViewCellStyle1;
            this.grillaUsuarios.GridColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.grillaUsuarios.Location = new System.Drawing.Point(11, 12);
            this.grillaUsuarios.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.grillaUsuarios.Name = "grillaUsuarios";
            this.grillaUsuarios.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            this.grillaUsuarios.RowHeadersWidth = 51;
            this.grillaUsuarios.RowTemplate.Height = 24;
            this.grillaUsuarios.Size = new System.Drawing.Size(579, 289);
            this.grillaUsuarios.TabIndex = 1;
            // 
            // UsuarioPrincipalBotton1
            // 
            this.UsuarioPrincipalBotton1.Location = new System.Drawing.Point(8, 307);
            this.UsuarioPrincipalBotton1.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.UsuarioPrincipalBotton1.Name = "UsuarioPrincipalBotton1";
            this.UsuarioPrincipalBotton1.Size = new System.Drawing.Size(71, 27);
            this.UsuarioPrincipalBotton1.TabIndex = 2;
            this.UsuarioPrincipalBotton1.Text = "Ver";
            this.UsuarioPrincipalBotton1.UseVisualStyleBackColor = true;
            this.UsuarioPrincipalBotton1.Click += new System.EventHandler(this.UsuarioPrincipalBotton1_Click);
            // 
            // UsuarioPrincipalBotton2
            // 
            this.UsuarioPrincipalBotton2.Location = new System.Drawing.Point(83, 307);
            this.UsuarioPrincipalBotton2.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.UsuarioPrincipalBotton2.Name = "UsuarioPrincipalBotton2";
            this.UsuarioPrincipalBotton2.Size = new System.Drawing.Size(71, 27);
            this.UsuarioPrincipalBotton2.TabIndex = 3;
            this.UsuarioPrincipalBotton2.Text = "Alta";
            this.UsuarioPrincipalBotton2.UseVisualStyleBackColor = true;
            this.UsuarioPrincipalBotton2.Click += new System.EventHandler(this.UsuarioPrincipalBotton2_Click);
            // 
            // UsuarioPrincipalBotton3
            // 
            this.UsuarioPrincipalBotton3.Location = new System.Drawing.Point(158, 307);
            this.UsuarioPrincipalBotton3.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.UsuarioPrincipalBotton3.Name = "UsuarioPrincipalBotton3";
            this.UsuarioPrincipalBotton3.Size = new System.Drawing.Size(71, 27);
            this.UsuarioPrincipalBotton3.TabIndex = 4;
            this.UsuarioPrincipalBotton3.Text = "Modificar";
            this.UsuarioPrincipalBotton3.UseVisualStyleBackColor = true;
            this.UsuarioPrincipalBotton3.Click += new System.EventHandler(this.UsuarioPrincipalBotton3_Click);
            // 
            // UsuarioPrincipalBotton4
            // 
            this.UsuarioPrincipalBotton4.Location = new System.Drawing.Point(233, 307);
            this.UsuarioPrincipalBotton4.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.UsuarioPrincipalBotton4.Name = "UsuarioPrincipalBotton4";
            this.UsuarioPrincipalBotton4.Size = new System.Drawing.Size(71, 27);
            this.UsuarioPrincipalBotton4.TabIndex = 5;
            this.UsuarioPrincipalBotton4.Text = "Baja";
            this.UsuarioPrincipalBotton4.UseVisualStyleBackColor = true;
            this.UsuarioPrincipalBotton4.Click += new System.EventHandler(this.UsuarioPrincipalBotton4_Click);
            // 
            // splitter1
            // 
            this.splitter1.Location = new System.Drawing.Point(0, 0);
            this.splitter1.Name = "splitter1";
            this.splitter1.Size = new System.Drawing.Size(3, 346);
            this.splitter1.TabIndex = 9;
            this.splitter1.TabStop = false;
            // 
            // UsuarioPrinciplaText1
            // 
            this.UsuarioPrinciplaText1.Location = new System.Drawing.Point(0, 33);
            this.UsuarioPrinciplaText1.Name = "UsuarioPrinciplaText1";
            this.UsuarioPrinciplaText1.Size = new System.Drawing.Size(240, 20);
            this.UsuarioPrinciplaText1.TabIndex = 7;
            // 
            // UsuarioPrincipalGroupBox
            // 
            this.UsuarioPrincipalGroupBox.Controls.Add(this.UsuarioPrincipalBotton6);
            this.UsuarioPrincipalGroupBox.Controls.Add(this.UsuarioPrincipalBotton5);
            this.UsuarioPrincipalGroupBox.Controls.Add(this.UsuarioPrincipalLabel5);
            this.UsuarioPrincipalGroupBox.Controls.Add(this.UsuarioPrinciplaText5);
            this.UsuarioPrincipalGroupBox.Controls.Add(this.UsuarioPrincipalLabel4);
            this.UsuarioPrincipalGroupBox.Controls.Add(this.UsuarioPrinciplaText4);
            this.UsuarioPrincipalGroupBox.Controls.Add(this.UsuarioPrincipalLabel3);
            this.UsuarioPrincipalGroupBox.Controls.Add(this.UsuarioPrinciplaText3);
            this.UsuarioPrincipalGroupBox.Controls.Add(this.UsuarioPrincipalLabel2);
            this.UsuarioPrincipalGroupBox.Controls.Add(this.UsuarioPrinciplaText2);
            this.UsuarioPrincipalGroupBox.Controls.Add(this.UsuarioPrincipalLabel1);
            this.UsuarioPrincipalGroupBox.Controls.Add(this.UsuarioPrinciplaText1);
            this.UsuarioPrincipalGroupBox.Location = new System.Drawing.Point(595, 12);
            this.UsuarioPrincipalGroupBox.Name = "UsuarioPrincipalGroupBox";
            this.UsuarioPrincipalGroupBox.Size = new System.Drawing.Size(252, 322);
            this.UsuarioPrincipalGroupBox.TabIndex = 10;
            this.UsuarioPrincipalGroupBox.TabStop = false;
            this.UsuarioPrincipalGroupBox.Text = "Filtros";
            // 
            // UsuarioPrincipalBotton6
            // 
            this.UsuarioPrincipalBotton6.Location = new System.Drawing.Point(129, 289);
            this.UsuarioPrincipalBotton6.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.UsuarioPrincipalBotton6.Name = "UsuarioPrincipalBotton6";
            this.UsuarioPrincipalBotton6.Size = new System.Drawing.Size(71, 27);
            this.UsuarioPrincipalBotton6.TabIndex = 19;
            this.UsuarioPrincipalBotton6.Text = "Limpiar";
            this.UsuarioPrincipalBotton6.UseVisualStyleBackColor = true;
            this.UsuarioPrincipalBotton6.Click += new System.EventHandler(this.UsuarioPrincipalBotton6_Click);
            // 
            // UsuarioPrincipalBotton5
            // 
            this.UsuarioPrincipalBotton5.Location = new System.Drawing.Point(30, 289);
            this.UsuarioPrincipalBotton5.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.UsuarioPrincipalBotton5.Name = "UsuarioPrincipalBotton5";
            this.UsuarioPrincipalBotton5.Size = new System.Drawing.Size(71, 27);
            this.UsuarioPrincipalBotton5.TabIndex = 18;
            this.UsuarioPrincipalBotton5.Text = "Aplicar";
            this.UsuarioPrincipalBotton5.UseVisualStyleBackColor = true;
            this.UsuarioPrincipalBotton5.Click += new System.EventHandler(this.UsuarioPrincipalBotton5_Click);
            // 
            // UsuarioPrincipalLabel5
            // 
            this.UsuarioPrincipalLabel5.AutoSize = true;
            this.UsuarioPrincipalLabel5.Location = new System.Drawing.Point(3, 238);
            this.UsuarioPrincipalLabel5.Name = "UsuarioPrincipalLabel5";
            this.UsuarioPrincipalLabel5.Size = new System.Drawing.Size(38, 13);
            this.UsuarioPrincipalLabel5.TabIndex = 17;
            this.UsuarioPrincipalLabel5.Text = "Idioma";
            // 
            // UsuarioPrinciplaText5
            // 
            this.UsuarioPrinciplaText5.Location = new System.Drawing.Point(0, 254);
            this.UsuarioPrinciplaText5.Name = "UsuarioPrinciplaText5";
            this.UsuarioPrinciplaText5.Size = new System.Drawing.Size(240, 20);
            this.UsuarioPrinciplaText5.TabIndex = 16;
            // 
            // UsuarioPrincipalLabel4
            // 
            this.UsuarioPrincipalLabel4.AutoSize = true;
            this.UsuarioPrincipalLabel4.Location = new System.Drawing.Point(0, 181);
            this.UsuarioPrincipalLabel4.Name = "UsuarioPrincipalLabel4";
            this.UsuarioPrincipalLabel4.Size = new System.Drawing.Size(76, 13);
            this.UsuarioPrincipalLabel4.TabIndex = 15;
            this.UsuarioPrincipalLabel4.Text = "Logins Fallidos";
            // 
            // UsuarioPrinciplaText4
            // 
            this.UsuarioPrinciplaText4.Location = new System.Drawing.Point(0, 197);
            this.UsuarioPrinciplaText4.Name = "UsuarioPrinciplaText4";
            this.UsuarioPrinciplaText4.Size = new System.Drawing.Size(240, 20);
            this.UsuarioPrinciplaText4.TabIndex = 14;
            // 
            // UsuarioPrincipalLabel3
            // 
            this.UsuarioPrincipalLabel3.AutoSize = true;
            this.UsuarioPrincipalLabel3.Location = new System.Drawing.Point(0, 125);
            this.UsuarioPrincipalLabel3.Name = "UsuarioPrincipalLabel3";
            this.UsuarioPrincipalLabel3.Size = new System.Drawing.Size(43, 13);
            this.UsuarioPrincipalLabel3.TabIndex = 13;
            this.UsuarioPrincipalLabel3.Text = "Usuario";
            // 
            // UsuarioPrinciplaText3
            // 
            this.UsuarioPrinciplaText3.Location = new System.Drawing.Point(0, 141);
            this.UsuarioPrinciplaText3.Name = "UsuarioPrinciplaText3";
            this.UsuarioPrinciplaText3.Size = new System.Drawing.Size(240, 20);
            this.UsuarioPrinciplaText3.TabIndex = 12;
            // 
            // UsuarioPrincipalLabel2
            // 
            this.UsuarioPrincipalLabel2.AutoSize = true;
            this.UsuarioPrincipalLabel2.Location = new System.Drawing.Point(0, 66);
            this.UsuarioPrincipalLabel2.Name = "UsuarioPrincipalLabel2";
            this.UsuarioPrincipalLabel2.Size = new System.Drawing.Size(44, 13);
            this.UsuarioPrincipalLabel2.TabIndex = 11;
            this.UsuarioPrincipalLabel2.Text = "Apellido";
            // 
            // UsuarioPrinciplaText2
            // 
            this.UsuarioPrinciplaText2.Location = new System.Drawing.Point(0, 82);
            this.UsuarioPrinciplaText2.Name = "UsuarioPrinciplaText2";
            this.UsuarioPrinciplaText2.Size = new System.Drawing.Size(240, 20);
            this.UsuarioPrinciplaText2.TabIndex = 10;
            // 
            // UsuarioPrincipalLabel1
            // 
            this.UsuarioPrincipalLabel1.AutoSize = true;
            this.UsuarioPrincipalLabel1.Location = new System.Drawing.Point(0, 17);
            this.UsuarioPrincipalLabel1.Name = "UsuarioPrincipalLabel1";
            this.UsuarioPrincipalLabel1.Size = new System.Drawing.Size(44, 13);
            this.UsuarioPrincipalLabel1.TabIndex = 9;
            this.UsuarioPrincipalLabel1.Text = "Nombre";
            // 
            // UsuarioPrincipalBotton7
            // 
            this.UsuarioPrincipalBotton7.Location = new System.Drawing.Point(308, 307);
            this.UsuarioPrincipalBotton7.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.UsuarioPrincipalBotton7.Name = "UsuarioPrincipalBotton7";
            this.UsuarioPrincipalBotton7.Size = new System.Drawing.Size(124, 27);
            this.UsuarioPrincipalBotton7.TabIndex = 11;
            this.UsuarioPrincipalBotton7.Text = "Resetear Clave";
            this.UsuarioPrincipalBotton7.UseVisualStyleBackColor = true;
            this.UsuarioPrincipalBotton7.Click += new System.EventHandler(this.UsuarioPrincipalBotton7_Click);
            // 
            // UsuariosPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(859, 346);
            this.Controls.Add(this.UsuarioPrincipalBotton7);
            this.Controls.Add(this.UsuarioPrincipalGroupBox);
            this.Controls.Add(this.splitter1);
            this.Controls.Add(this.UsuarioPrincipalBotton4);
            this.Controls.Add(this.UsuarioPrincipalBotton3);
            this.Controls.Add(this.UsuarioPrincipalBotton2);
            this.Controls.Add(this.UsuarioPrincipalBotton1);
            this.Controls.Add(this.grillaUsuarios);
            this.Name = "UsuariosPrincipal";
            this.Text = "UsuariosPrincipal";
            this.Load += new System.EventHandler(this.UsuariosPrincipal_Load);
            ((System.ComponentModel.ISupportInitialize)(this.grillaUsuarios)).EndInit();
            this.UsuarioPrincipalGroupBox.ResumeLayout(false);
            this.UsuarioPrincipalGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView grillaUsuarios;
        private System.Windows.Forms.Button UsuarioPrincipalBotton1;
        private System.Windows.Forms.Button UsuarioPrincipalBotton2;
        private System.Windows.Forms.Button UsuarioPrincipalBotton3;
        private System.Windows.Forms.Button UsuarioPrincipalBotton4;
        private System.Windows.Forms.Splitter splitter1;
        private System.Windows.Forms.TextBox UsuarioPrinciplaText1;
        private System.Windows.Forms.GroupBox UsuarioPrincipalGroupBox;
        private System.Windows.Forms.Label UsuarioPrincipalLabel5;
        private System.Windows.Forms.TextBox UsuarioPrinciplaText5;
        private System.Windows.Forms.Label UsuarioPrincipalLabel4;
        private System.Windows.Forms.TextBox UsuarioPrinciplaText4;
        private System.Windows.Forms.Label UsuarioPrincipalLabel3;
        private System.Windows.Forms.TextBox UsuarioPrinciplaText3;
        private System.Windows.Forms.Label UsuarioPrincipalLabel2;
        private System.Windows.Forms.TextBox UsuarioPrinciplaText2;
        private System.Windows.Forms.Label UsuarioPrincipalLabel1;
        private System.Windows.Forms.Button UsuarioPrincipalBotton6;
        private System.Windows.Forms.Button UsuarioPrincipalBotton5;
        private System.Windows.Forms.Button UsuarioPrincipalBotton7;
    }
}