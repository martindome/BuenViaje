﻿namespace BuenViaje.Administracion.Permisos
{
    partial class ABMPermisos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.ABMPermisoBotton2 = new System.Windows.Forms.Button();
            this.ABMPermisoBotton1 = new System.Windows.Forms.Button();
            this.ABMPermisoGroupboxPermisos = new System.Windows.Forms.GroupBox();
            this.ABMPermisoGroupboxPatentes = new System.Windows.Forms.GroupBox();
            this.ABMPermisoLabel4 = new System.Windows.Forms.Label();
            this.ABMPermisoLabel3 = new System.Windows.Forms.Label();
            this.ABMPermisoGrillaPatente2 = new System.Windows.Forms.DataGridView();
            this.ABMPermisoBotton4 = new System.Windows.Forms.Button();
            this.ABMPermisoBotton3 = new System.Windows.Forms.Button();
            this.ABMPermisoGrillaPatente1 = new System.Windows.Forms.DataGridView();
            this.ABMPermisoGroupboxUsuario = new System.Windows.Forms.GroupBox();
            this.ABMPermisoTextoDescripcion = new System.Windows.Forms.TextBox();
            this.ABMPermisoTextoNombre = new System.Windows.Forms.TextBox();
            this.ABMPermisoLabel2 = new System.Windows.Forms.Label();
            this.ABMPermisoLabel1 = new System.Windows.Forms.Label();
            this.ABMPermisoGroupboxPermisos.SuspendLayout();
            this.ABMPermisoGroupboxPatentes.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ABMPermisoGrillaPatente2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ABMPermisoGrillaPatente1)).BeginInit();
            this.ABMPermisoGroupboxUsuario.SuspendLayout();
            this.SuspendLayout();
            // 
            // ABMPermisoBotton2
            // 
            this.ABMPermisoBotton2.Location = new System.Drawing.Point(184, 128);
            this.ABMPermisoBotton2.Margin = new System.Windows.Forms.Padding(2);
            this.ABMPermisoBotton2.Name = "ABMPermisoBotton2";
            this.ABMPermisoBotton2.Size = new System.Drawing.Size(66, 21);
            this.ABMPermisoBotton2.TabIndex = 16;
            this.ABMPermisoBotton2.Text = "Cancelar";
            this.ABMPermisoBotton2.UseVisualStyleBackColor = true;
            this.ABMPermisoBotton2.Click += new System.EventHandler(this.ABMPermisoBotton2_Click);
            // 
            // ABMPermisoBotton1
            // 
            this.ABMPermisoBotton1.Location = new System.Drawing.Point(11, 128);
            this.ABMPermisoBotton1.Margin = new System.Windows.Forms.Padding(2);
            this.ABMPermisoBotton1.Name = "ABMPermisoBotton1";
            this.ABMPermisoBotton1.Size = new System.Drawing.Size(66, 21);
            this.ABMPermisoBotton1.TabIndex = 17;
            this.ABMPermisoBotton1.Text = "Aplicar";
            this.ABMPermisoBotton1.UseVisualStyleBackColor = true;
            this.ABMPermisoBotton1.Click += new System.EventHandler(this.ABMPermisoBotton1_Click);
            // 
            // ABMPermisoGroupboxPermisos
            // 
            this.ABMPermisoGroupboxPermisos.Controls.Add(this.ABMPermisoGroupboxPatentes);
            this.ABMPermisoGroupboxPermisos.Location = new System.Drawing.Point(255, 12);
            this.ABMPermisoGroupboxPermisos.Name = "ABMPermisoGroupboxPermisos";
            this.ABMPermisoGroupboxPermisos.Size = new System.Drawing.Size(393, 244);
            this.ABMPermisoGroupboxPermisos.TabIndex = 15;
            this.ABMPermisoGroupboxPermisos.TabStop = false;
            this.ABMPermisoGroupboxPermisos.Text = "Permisos";
            // 
            // ABMPermisoGroupboxPatentes
            // 
            this.ABMPermisoGroupboxPatentes.Controls.Add(this.ABMPermisoLabel4);
            this.ABMPermisoGroupboxPatentes.Controls.Add(this.ABMPermisoLabel3);
            this.ABMPermisoGroupboxPatentes.Controls.Add(this.ABMPermisoGrillaPatente2);
            this.ABMPermisoGroupboxPatentes.Controls.Add(this.ABMPermisoBotton4);
            this.ABMPermisoGroupboxPatentes.Controls.Add(this.ABMPermisoBotton3);
            this.ABMPermisoGroupboxPatentes.Controls.Add(this.ABMPermisoGrillaPatente1);
            this.ABMPermisoGroupboxPatentes.Location = new System.Drawing.Point(5, 19);
            this.ABMPermisoGroupboxPatentes.Margin = new System.Windows.Forms.Padding(2);
            this.ABMPermisoGroupboxPatentes.Name = "ABMPermisoGroupboxPatentes";
            this.ABMPermisoGroupboxPatentes.Padding = new System.Windows.Forms.Padding(2);
            this.ABMPermisoGroupboxPatentes.Size = new System.Drawing.Size(384, 220);
            this.ABMPermisoGroupboxPatentes.TabIndex = 8;
            this.ABMPermisoGroupboxPatentes.TabStop = false;
            this.ABMPermisoGroupboxPatentes.Text = "Patente";
            // 
            // ABMPermisoLabel4
            // 
            this.ABMPermisoLabel4.AutoSize = true;
            this.ABMPermisoLabel4.Location = new System.Drawing.Point(192, 22);
            this.ABMPermisoLabel4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.ABMPermisoLabel4.Name = "ABMPermisoLabel4";
            this.ABMPermisoLabel4.Size = new System.Drawing.Size(44, 13);
            this.ABMPermisoLabel4.TabIndex = 17;
            this.ABMPermisoLabel4.Text = "Nombre";
            // 
            // ABMPermisoLabel3
            // 
            this.ABMPermisoLabel3.AutoSize = true;
            this.ABMPermisoLabel3.Location = new System.Drawing.Point(4, 22);
            this.ABMPermisoLabel3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.ABMPermisoLabel3.Name = "ABMPermisoLabel3";
            this.ABMPermisoLabel3.Size = new System.Drawing.Size(44, 13);
            this.ABMPermisoLabel3.TabIndex = 16;
            this.ABMPermisoLabel3.Text = "Nombre";
            // 
            // ABMPermisoGrillaPatente2
            // 
            this.ABMPermisoGrillaPatente2.BackgroundColor = System.Drawing.SystemColors.InactiveCaption;
            this.ABMPermisoGrillaPatente2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.InactiveCaption;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.ABMPermisoGrillaPatente2.DefaultCellStyle = dataGridViewCellStyle5;
            this.ABMPermisoGrillaPatente2.GridColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ABMPermisoGrillaPatente2.Location = new System.Drawing.Point(192, 37);
            this.ABMPermisoGrillaPatente2.Margin = new System.Windows.Forms.Padding(2);
            this.ABMPermisoGrillaPatente2.Name = "ABMPermisoGrillaPatente2";
            this.ABMPermisoGrillaPatente2.RowHeadersWidth = 82;
            this.ABMPermisoGrillaPatente2.RowTemplate.Height = 33;
            this.ABMPermisoGrillaPatente2.Size = new System.Drawing.Size(184, 139);
            this.ABMPermisoGrillaPatente2.TabIndex = 14;
            // 
            // ABMPermisoBotton4
            // 
            this.ABMPermisoBotton4.Location = new System.Drawing.Point(310, 181);
            this.ABMPermisoBotton4.Margin = new System.Windows.Forms.Padding(2);
            this.ABMPermisoBotton4.Name = "ABMPermisoBotton4";
            this.ABMPermisoBotton4.Size = new System.Drawing.Size(66, 21);
            this.ABMPermisoBotton4.TabIndex = 4;
            this.ABMPermisoBotton4.Text = "Quitar";
            this.ABMPermisoBotton4.UseVisualStyleBackColor = true;
            this.ABMPermisoBotton4.Click += new System.EventHandler(this.ABMPermisoBotton4_Click);
            // 
            // ABMPermisoBotton3
            // 
            this.ABMPermisoBotton3.Location = new System.Drawing.Point(4, 180);
            this.ABMPermisoBotton3.Margin = new System.Windows.Forms.Padding(2);
            this.ABMPermisoBotton3.Name = "ABMPermisoBotton3";
            this.ABMPermisoBotton3.Size = new System.Drawing.Size(66, 21);
            this.ABMPermisoBotton3.TabIndex = 3;
            this.ABMPermisoBotton3.Text = "Agregar";
            this.ABMPermisoBotton3.UseVisualStyleBackColor = true;
            this.ABMPermisoBotton3.Click += new System.EventHandler(this.ABMPermisoBotton3_Click);
            // 
            // ABMPermisoGrillaPatente1
            // 
            this.ABMPermisoGrillaPatente1.BackgroundColor = System.Drawing.SystemColors.InactiveCaption;
            this.ABMPermisoGrillaPatente1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.InactiveCaption;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.ABMPermisoGrillaPatente1.DefaultCellStyle = dataGridViewCellStyle6;
            this.ABMPermisoGrillaPatente1.GridColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ABMPermisoGrillaPatente1.Location = new System.Drawing.Point(4, 37);
            this.ABMPermisoGrillaPatente1.Margin = new System.Windows.Forms.Padding(2);
            this.ABMPermisoGrillaPatente1.Name = "ABMPermisoGrillaPatente1";
            this.ABMPermisoGrillaPatente1.RowHeadersWidth = 82;
            this.ABMPermisoGrillaPatente1.RowTemplate.Height = 33;
            this.ABMPermisoGrillaPatente1.Size = new System.Drawing.Size(184, 139);
            this.ABMPermisoGrillaPatente1.TabIndex = 0;
            // 
            // ABMPermisoGroupboxUsuario
            // 
            this.ABMPermisoGroupboxUsuario.Controls.Add(this.ABMPermisoTextoDescripcion);
            this.ABMPermisoGroupboxUsuario.Controls.Add(this.ABMPermisoTextoNombre);
            this.ABMPermisoGroupboxUsuario.Controls.Add(this.ABMPermisoLabel2);
            this.ABMPermisoGroupboxUsuario.Controls.Add(this.ABMPermisoLabel1);
            this.ABMPermisoGroupboxUsuario.Location = new System.Drawing.Point(11, 12);
            this.ABMPermisoGroupboxUsuario.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.ABMPermisoGroupboxUsuario.Name = "ABMPermisoGroupboxUsuario";
            this.ABMPermisoGroupboxUsuario.Padding = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.ABMPermisoGroupboxUsuario.Size = new System.Drawing.Size(239, 111);
            this.ABMPermisoGroupboxUsuario.TabIndex = 14;
            this.ABMPermisoGroupboxUsuario.TabStop = false;
            this.ABMPermisoGroupboxUsuario.Text = "Usuario";
            // 
            // ABMPermisoTextoDescripcion
            // 
            this.ABMPermisoTextoDescripcion.Location = new System.Drawing.Point(12, 71);
            this.ABMPermisoTextoDescripcion.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.ABMPermisoTextoDescripcion.Name = "ABMPermisoTextoDescripcion";
            this.ABMPermisoTextoDescripcion.Size = new System.Drawing.Size(212, 20);
            this.ABMPermisoTextoDescripcion.TabIndex = 5;
            this.ABMPermisoTextoDescripcion.TextChanged += new System.EventHandler(this.ABMPermisoTextoDescripcion_TextChanged);
            // 
            // ABMPermisoTextoNombre
            // 
            this.ABMPermisoTextoNombre.Location = new System.Drawing.Point(12, 32);
            this.ABMPermisoTextoNombre.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.ABMPermisoTextoNombre.Name = "ABMPermisoTextoNombre";
            this.ABMPermisoTextoNombre.Size = new System.Drawing.Size(212, 20);
            this.ABMPermisoTextoNombre.TabIndex = 4;
            this.ABMPermisoTextoNombre.TextChanged += new System.EventHandler(this.ABMPermisoTextoNombre_TextChanged);
            // 
            // ABMPermisoLabel2
            // 
            this.ABMPermisoLabel2.AutoSize = true;
            this.ABMPermisoLabel2.Location = new System.Drawing.Point(9, 55);
            this.ABMPermisoLabel2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.ABMPermisoLabel2.Name = "ABMPermisoLabel2";
            this.ABMPermisoLabel2.Size = new System.Drawing.Size(63, 13);
            this.ABMPermisoLabel2.TabIndex = 1;
            this.ABMPermisoLabel2.Text = "Descripcion";
            // 
            // ABMPermisoLabel1
            // 
            this.ABMPermisoLabel1.AutoSize = true;
            this.ABMPermisoLabel1.Location = new System.Drawing.Point(9, 16);
            this.ABMPermisoLabel1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.ABMPermisoLabel1.Name = "ABMPermisoLabel1";
            this.ABMPermisoLabel1.Size = new System.Drawing.Size(44, 13);
            this.ABMPermisoLabel1.TabIndex = 0;
            this.ABMPermisoLabel1.Text = "Nombre";
            // 
            // ABMPermisos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(656, 293);
            this.Controls.Add(this.ABMPermisoBotton2);
            this.Controls.Add(this.ABMPermisoBotton1);
            this.Controls.Add(this.ABMPermisoGroupboxPermisos);
            this.Controls.Add(this.ABMPermisoGroupboxUsuario);
            this.Name = "ABMPermisos";
            this.Text = "ABMPermisos";
            this.Load += new System.EventHandler(this.ABMPermisos_Load);
            this.ABMPermisoGroupboxPermisos.ResumeLayout(false);
            this.ABMPermisoGroupboxPatentes.ResumeLayout(false);
            this.ABMPermisoGroupboxPatentes.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ABMPermisoGrillaPatente2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ABMPermisoGrillaPatente1)).EndInit();
            this.ABMPermisoGroupboxUsuario.ResumeLayout(false);
            this.ABMPermisoGroupboxUsuario.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button ABMPermisoBotton2;
        private System.Windows.Forms.Button ABMPermisoBotton1;
        private System.Windows.Forms.GroupBox ABMPermisoGroupboxPermisos;
        private System.Windows.Forms.GroupBox ABMPermisoGroupboxPatentes;
        private System.Windows.Forms.Label ABMPermisoLabel4;
        private System.Windows.Forms.Label ABMPermisoLabel3;
        private System.Windows.Forms.DataGridView ABMPermisoGrillaPatente2;
        private System.Windows.Forms.Button ABMPermisoBotton4;
        private System.Windows.Forms.Button ABMPermisoBotton3;
        private System.Windows.Forms.DataGridView ABMPermisoGrillaPatente1;
        private System.Windows.Forms.GroupBox ABMPermisoGroupboxUsuario;
        private System.Windows.Forms.TextBox ABMPermisoTextoDescripcion;
        private System.Windows.Forms.TextBox ABMPermisoTextoNombre;
        private System.Windows.Forms.Label ABMPermisoLabel2;
        private System.Windows.Forms.Label ABMPermisoLabel1;
    }
}