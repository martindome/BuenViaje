﻿namespace BuenViaje.Administracion.Permisos
{
    partial class PermisosPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.PermisosPrincipalGroupBox = new System.Windows.Forms.GroupBox();
            this.PermisosPrincipalBotton6 = new System.Windows.Forms.Button();
            this.PermisosPrincipalBotton5 = new System.Windows.Forms.Button();
            this.PermisosPrincipalLabel2 = new System.Windows.Forms.Label();
            this.PermisosPrinciplaText2 = new System.Windows.Forms.TextBox();
            this.PermisosPrincipalLabel1 = new System.Windows.Forms.Label();
            this.PermisosPrinciplaText1 = new System.Windows.Forms.TextBox();
            this.PermisosPrincipalBotton4 = new System.Windows.Forms.Button();
            this.PermisosPrincipalBotton3 = new System.Windows.Forms.Button();
            this.PermisosPrincipalBotton2 = new System.Windows.Forms.Button();
            this.PermisosPrincipalBotton1 = new System.Windows.Forms.Button();
            this.grillaFamilias = new System.Windows.Forms.DataGridView();
            this.PermisosPrincipalGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grillaFamilias)).BeginInit();
            this.SuspendLayout();
            // 
            // PermisosPrincipalGroupBox
            // 
            this.PermisosPrincipalGroupBox.Controls.Add(this.PermisosPrincipalBotton6);
            this.PermisosPrincipalGroupBox.Controls.Add(this.PermisosPrincipalBotton5);
            this.PermisosPrincipalGroupBox.Controls.Add(this.PermisosPrincipalLabel2);
            this.PermisosPrincipalGroupBox.Controls.Add(this.PermisosPrinciplaText2);
            this.PermisosPrincipalGroupBox.Controls.Add(this.PermisosPrincipalLabel1);
            this.PermisosPrincipalGroupBox.Controls.Add(this.PermisosPrinciplaText1);
            this.PermisosPrincipalGroupBox.Location = new System.Drawing.Point(537, 12);
            this.PermisosPrincipalGroupBox.Name = "PermisosPrincipalGroupBox";
            this.PermisosPrincipalGroupBox.Size = new System.Drawing.Size(252, 159);
            this.PermisosPrincipalGroupBox.TabIndex = 17;
            this.PermisosPrincipalGroupBox.TabStop = false;
            this.PermisosPrincipalGroupBox.Text = "Filtros";
            // 
            // PermisosPrincipalBotton6
            // 
            this.PermisosPrincipalBotton6.Location = new System.Drawing.Point(169, 108);
            this.PermisosPrincipalBotton6.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.PermisosPrincipalBotton6.Name = "PermisosPrincipalBotton6";
            this.PermisosPrincipalBotton6.Size = new System.Drawing.Size(71, 27);
            this.PermisosPrincipalBotton6.TabIndex = 19;
            this.PermisosPrincipalBotton6.Text = "Limpiar";
            this.PermisosPrincipalBotton6.UseVisualStyleBackColor = true;
            this.PermisosPrincipalBotton6.Click += new System.EventHandler(this.PermisosPrincipalBotton6_Click);
            // 
            // PermisosPrincipalBotton5
            // 
            this.PermisosPrincipalBotton5.Location = new System.Drawing.Point(5, 108);
            this.PermisosPrincipalBotton5.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.PermisosPrincipalBotton5.Name = "PermisosPrincipalBotton5";
            this.PermisosPrincipalBotton5.Size = new System.Drawing.Size(71, 27);
            this.PermisosPrincipalBotton5.TabIndex = 18;
            this.PermisosPrincipalBotton5.Text = "Aplicar";
            this.PermisosPrincipalBotton5.UseVisualStyleBackColor = true;
            this.PermisosPrincipalBotton5.Click += new System.EventHandler(this.PermisosPrincipalBotton5_Click);
            // 
            // PermisosPrincipalLabel2
            // 
            this.PermisosPrincipalLabel2.AutoSize = true;
            this.PermisosPrincipalLabel2.Location = new System.Drawing.Point(0, 66);
            this.PermisosPrincipalLabel2.Name = "PermisosPrincipalLabel2";
            this.PermisosPrincipalLabel2.Size = new System.Drawing.Size(63, 13);
            this.PermisosPrincipalLabel2.TabIndex = 11;
            this.PermisosPrincipalLabel2.Text = "Descripcion";
            // 
            // PermisosPrinciplaText2
            // 
            this.PermisosPrinciplaText2.Location = new System.Drawing.Point(0, 82);
            this.PermisosPrinciplaText2.Name = "PermisosPrinciplaText2";
            this.PermisosPrinciplaText2.Size = new System.Drawing.Size(240, 20);
            this.PermisosPrinciplaText2.TabIndex = 10;
            // 
            // PermisosPrincipalLabel1
            // 
            this.PermisosPrincipalLabel1.AutoSize = true;
            this.PermisosPrincipalLabel1.Location = new System.Drawing.Point(0, 17);
            this.PermisosPrincipalLabel1.Name = "PermisosPrincipalLabel1";
            this.PermisosPrincipalLabel1.Size = new System.Drawing.Size(44, 13);
            this.PermisosPrincipalLabel1.TabIndex = 9;
            this.PermisosPrincipalLabel1.Text = "Nombre";
            // 
            // PermisosPrinciplaText1
            // 
            this.PermisosPrinciplaText1.Location = new System.Drawing.Point(0, 33);
            this.PermisosPrinciplaText1.Name = "PermisosPrinciplaText1";
            this.PermisosPrinciplaText1.Size = new System.Drawing.Size(240, 20);
            this.PermisosPrinciplaText1.TabIndex = 7;
            // 
            // PermisosPrincipalBotton4
            // 
            this.PermisosPrincipalBotton4.Location = new System.Drawing.Point(236, 305);
            this.PermisosPrincipalBotton4.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.PermisosPrincipalBotton4.Name = "PermisosPrincipalBotton4";
            this.PermisosPrincipalBotton4.Size = new System.Drawing.Size(71, 27);
            this.PermisosPrincipalBotton4.TabIndex = 16;
            this.PermisosPrincipalBotton4.Text = "Baja";
            this.PermisosPrincipalBotton4.UseVisualStyleBackColor = true;
            this.PermisosPrincipalBotton4.Click += new System.EventHandler(this.PermisosPrincipalBotton4_Click);
            // 
            // PermisosPrincipalBotton3
            // 
            this.PermisosPrincipalBotton3.Location = new System.Drawing.Point(161, 305);
            this.PermisosPrincipalBotton3.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.PermisosPrincipalBotton3.Name = "PermisosPrincipalBotton3";
            this.PermisosPrincipalBotton3.Size = new System.Drawing.Size(71, 27);
            this.PermisosPrincipalBotton3.TabIndex = 15;
            this.PermisosPrincipalBotton3.Text = "Modificar";
            this.PermisosPrincipalBotton3.UseVisualStyleBackColor = true;
            this.PermisosPrincipalBotton3.Click += new System.EventHandler(this.PermisosPrincipalBotton3_Click);
            // 
            // PermisosPrincipalBotton2
            // 
            this.PermisosPrincipalBotton2.Location = new System.Drawing.Point(86, 305);
            this.PermisosPrincipalBotton2.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.PermisosPrincipalBotton2.Name = "PermisosPrincipalBotton2";
            this.PermisosPrincipalBotton2.Size = new System.Drawing.Size(71, 27);
            this.PermisosPrincipalBotton2.TabIndex = 14;
            this.PermisosPrincipalBotton2.Text = "Alta";
            this.PermisosPrincipalBotton2.UseVisualStyleBackColor = true;
            this.PermisosPrincipalBotton2.Click += new System.EventHandler(this.PermisosPrincipalBotton2_Click);
            // 
            // PermisosPrincipalBotton1
            // 
            this.PermisosPrincipalBotton1.Location = new System.Drawing.Point(11, 305);
            this.PermisosPrincipalBotton1.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.PermisosPrincipalBotton1.Name = "PermisosPrincipalBotton1";
            this.PermisosPrincipalBotton1.Size = new System.Drawing.Size(71, 27);
            this.PermisosPrincipalBotton1.TabIndex = 13;
            this.PermisosPrincipalBotton1.Text = "Ver";
            this.PermisosPrincipalBotton1.UseVisualStyleBackColor = true;
            this.PermisosPrincipalBotton1.Click += new System.EventHandler(this.PermisosPrincipalBotton1_Click);
            // 
            // grillaFamilias
            // 
            this.grillaFamilias.BackgroundColor = System.Drawing.SystemColors.InactiveCaption;
            this.grillaFamilias.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Sunken;
            this.grillaFamilias.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            this.grillaFamilias.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grillaFamilias.Cursor = System.Windows.Forms.Cursors.Default;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.InactiveCaption;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.grillaFamilias.DefaultCellStyle = dataGridViewCellStyle1;
            this.grillaFamilias.GridColor = System.Drawing.SystemColors.ActiveCaption;
            this.grillaFamilias.Location = new System.Drawing.Point(11, 10);
            this.grillaFamilias.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.grillaFamilias.Name = "grillaFamilias";
            this.grillaFamilias.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grillaFamilias.RowHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.grillaFamilias.RowHeadersWidth = 51;
            this.grillaFamilias.RowTemplate.Height = 24;
            this.grillaFamilias.Size = new System.Drawing.Size(521, 289);
            this.grillaFamilias.TabIndex = 12;
            // 
            // PermisosPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(794, 340);
            this.Controls.Add(this.PermisosPrincipalGroupBox);
            this.Controls.Add(this.PermisosPrincipalBotton4);
            this.Controls.Add(this.PermisosPrincipalBotton3);
            this.Controls.Add(this.PermisosPrincipalBotton2);
            this.Controls.Add(this.PermisosPrincipalBotton1);
            this.Controls.Add(this.grillaFamilias);
            this.Name = "PermisosPrincipal";
            this.Text = "PermisosPrincipal";
            this.Load += new System.EventHandler(this.PermisosPrincipal_Load);
            this.PermisosPrincipalGroupBox.ResumeLayout(false);
            this.PermisosPrincipalGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grillaFamilias)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.GroupBox PermisosPrincipalGroupBox;
        private System.Windows.Forms.Button PermisosPrincipalBotton6;
        private System.Windows.Forms.Button PermisosPrincipalBotton5;
        private System.Windows.Forms.Label PermisosPrincipalLabel2;
        private System.Windows.Forms.TextBox PermisosPrinciplaText2;
        private System.Windows.Forms.Label PermisosPrincipalLabel1;
        private System.Windows.Forms.TextBox PermisosPrinciplaText1;
        private System.Windows.Forms.Button PermisosPrincipalBotton4;
        private System.Windows.Forms.Button PermisosPrincipalBotton3;
        private System.Windows.Forms.Button PermisosPrincipalBotton2;
        private System.Windows.Forms.Button PermisosPrincipalBotton1;
        private System.Windows.Forms.DataGridView grillaFamilias;
    }
}